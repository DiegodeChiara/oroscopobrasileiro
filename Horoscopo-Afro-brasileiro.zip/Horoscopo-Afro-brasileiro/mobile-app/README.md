# Universo Místico - Mobile App

A comprehensive React Native mobile application for astrology and spiritual guidance, featuring geolocation services, push notifications, and seamless integration with the Universo Místico web platform.

## 🌟 Features

### Core Functionality
- **Spiritual Profile Management**: Complete zodiac sign calculation and Orixá selection
- **Daily Horoscope**: Personalized astrological predictions based on user profile
- **Interactive Tarot Readings**: Multiple reading types with animated card selection
- **Location-Based Services**: Find nearby spiritual centers, temples, and esoteric stores
- **Push Notifications**: Daily reminders, celestial events, and personalized messages

### Geolocation Integration
- Real-time location tracking for personalized content
- Interactive map with spiritual points of interest
- Automatic calculation of celestial events based on location
- Distance-based filtering of nearby spiritual venues

### Notification System
- Scheduled daily horoscope notifications
- Celestial event alerts (moon phases, eclipses, etc.)
- Personalized spiritual messages
- Visit reminders for nearby spiritual locations

## 🛠 Technical Architecture

### Tech Stack
- **React Native**: Cross-platform mobile development
- **TypeScript**: Type-safe development
- **React Native Paper**: Material Design 3 UI components
- **Expo**: Development and deployment platform
- **React Navigation**: Navigation management
- **Async Storage**: Local data persistence

### Services Integration
- **Expo Location**: GPS and geolocation services
- **Expo Notifications**: Push notification management
- **React Native Maps**: Interactive map functionality
- **Vector Icons**: Comprehensive icon library

### Context Providers
- **AuthContext**: User authentication and profile management
- **LocationContext**: Geolocation state and astrology calculations
- **NotificationContext**: Notification scheduling and history

## 📱 Screen Architecture

### Authentication Flow
- **LoginScreen**: User login and registration
- **LoadingScreen**: App initialization with mystical animations

### Main Application
- **HomeScreen**: Dashboard with daily content and location-based features
- **SpiritualProfileScreen**: Zodiac and Orixá profile configuration
- **TarotScreen**: Interactive tarot card readings with animations
- **MapScreen**: Location-based spiritual venue discovery
- **ProfileScreen**: User account management and app settings

## 🎨 Design System

### Theme Configuration
- **Material Design 3**: Modern, accessible design system
- **Mystical Color Palette**: Purple, indigo, and emerald spiritual colors
- **Custom Spacing**: Consistent 8px grid system
- **Typography**: Inter font family with mystical hierarchy
- **Animations**: Smooth transitions with spiritual aesthetics

### Visual Elements
- **Glassmorphism Effects**: Translucent cards with depth
- **Mystical Icons**: Spiritual and astrological iconography
- **Brazilian Cultural Colors**: Authentic representation
- **Chakra Color System**: Seven-chakra color integration

## 🌍 Localization

### Brazilian Portuguese
- Complete Portuguese language support
- Brazilian cultural context integration
- Afro-Brazilian religious terminology
- Regional spiritual practices inclusion

## 🔧 Installation & Setup

### Prerequisites
```bash
# Install Node.js 18+ and npm
# Install Expo CLI globally
npm install -g expo-cli

# Install EAS CLI for building
npm install -g @expo/eas-cli
```

### Development Setup
```bash
# Navigate to mobile app directory
cd mobile-app

# Install dependencies
npm install

# Start development server
expo start

# Run on iOS simulator
expo start --ios

# Run on Android emulator
expo start --android
```

### Environment Configuration
Create `.env` file in mobile-app directory:
```
EXPO_PROJECT_ID=your-expo-project-id
API_BASE_URL=http://localhost:5000
```

## 📦 Required Dependencies

### Core Dependencies
```json
{
  "expo": "~49.0.0",
  "react": "18.2.0",
  "react-native": "0.72.6",
  "react-native-paper": "^5.0.0",
  "@react-navigation/native": "^6.0.0",
  "@react-navigation/bottom-tabs": "^6.0.0",
  "@react-navigation/stack": "^6.0.0"
}
```

### Expo Modules
```json
{
  "expo-location": "~16.1.0",
  "expo-notifications": "~0.20.0",
  "expo-device": "~5.4.0",
  "expo-status-bar": "~1.6.0",
  "expo-splash-screen": "~0.20.0",
  "expo-font": "~11.4.0"
}
```

### Additional Libraries
```json
{
  "react-native-maps": "1.7.1",
  "react-native-vector-icons": "^10.0.0",
  "@react-native-async-storage/async-storage": "1.18.2",
  "axios": "^1.5.0"
}
```

## 🚀 Build & Deployment

### Development Build
```bash
# Create development build
eas build --profile development --platform all

# Install on device
eas build --profile development --platform ios --local
```

### Production Build
```bash
# Build for app stores
eas build --profile production --platform all

# Submit to stores
eas submit --platform ios
eas submit --platform android
```

## 📧 Notification Setup

### Firebase Configuration
1. Create Firebase project
2. Enable Cloud Messaging
3. Download `google-services.json` (Android) and `GoogleService-Info.plist` (iOS)
4. Configure push notification certificates

### Notification Permissions
The app automatically requests notification permissions on startup and schedules:
- Daily horoscope notifications (8:00 AM)
- Evening spiritual messages (8:00 PM)
- Celestial event alerts
- Custom reminders for spiritual venue visits

## 🗺 Map Integration

### Google Maps Setup
1. Enable Google Maps API in Google Cloud Console
2. Create API key with Maps SDK enabled
3. Configure API key in app.json:
```json
{
  "expo": {
    "android": {
      "config": {
        "googleMaps": {
          "apiKey": "YOUR_GOOGLE_MAPS_API_KEY"
        }
      }
    },
    "ios": {
      "config": {
        "googleMapsApiKey": "YOUR_GOOGLE_MAPS_API_KEY"
      }
    }
  }
}
```

## 🔐 Security & Privacy

### Data Protection
- User data encrypted in local storage
- API communications over HTTPS
- Location data processed locally
- Notification history with privacy controls

### Permissions
- Location: For personalized astrology content
- Notifications: For daily reminders and alerts
- Camera: For future features (QR codes, etc.)

## 🧪 Testing

### Unit Testing
```bash
# Run unit tests
npm test

# Run with coverage
npm run test:coverage
```

### E2E Testing
```bash
# Install Detox
npm install -g detox-cli

# Run E2E tests
detox test
```

## 📊 Analytics Integration

### Expo Analytics
- User engagement tracking
- Feature usage analytics
- Crash reporting
- Performance monitoring

## 🤝 Integration with Web Platform

### API Synchronization
- Shared user authentication
- Profile data synchronization
- Cross-platform notification delivery
- Consistent spiritual content

### Data Flow
```
Mobile App ←→ Express.js API ←→ PostgreSQL Database
     ↓
Push Notifications & Location Services
```

## 🔮 Future Enhancements

### Planned Features
- Astral chart visualization
- Voice-guided meditations
- Social features (spiritual community)
- Premium subscription tiers
- Offline mode capabilities
- Apple Watch companion app

### Technical Improvements
- GraphQL API integration
- Real-time chat support
- Advanced analytics
- Machine learning recommendations
- Blockchain-based premium features

## 📝 Development Notes

### Code Structure
```
mobile-app/
├── src/
│   ├── components/       # Reusable UI components
│   ├── contexts/        # React Context providers
│   ├── screens/         # Main application screens
│   ├── services/        # Business logic services
│   ├── theme/          # Design system configuration
│   ├── types/          # TypeScript type definitions
│   └── utils/          # Helper functions
├── assets/             # Static assets
└── App.tsx            # Root application component
```

### Best Practices
- TypeScript for type safety
- Context API for state management
- Modular component architecture
- Consistent error handling
- Accessibility compliance
- Performance optimization

## 📞 Support

For technical support or feature requests, contact the development team or refer to the main project documentation.

---

*Universo Místico Mobile - Connecting you to the cosmos wherever you are* 🌟