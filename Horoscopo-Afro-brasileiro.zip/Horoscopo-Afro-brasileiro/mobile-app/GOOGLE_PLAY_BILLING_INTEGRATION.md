# Google Play Billing Integration - Universo Místico

## Overview

This document outlines the complete Google Play Billing Library v6+ integration for premium subscriptions in the Universo Místico mobile app, with Brazilian pricing and spiritual content features.

## Subscription Plans

### Premium Mensal (premium_mensal)
- **Price**: R$ 5,90/mês
- **Billing Cycle**: Monthly recurring
- **Google Play Product ID**: `premium_mensal`

### Premium Anual (premium_anual)
- **Price**: R$ 59,90/ano
- **Billing Cycle**: Annual recurring
- **Google Play Product ID**: `premium_anual`
- **Savings**: R$ 11,90 per year (equivalent to R$ 4,99/month)

## Premium Features Unlocked

### Core Premium Benefits
1. **Unlimited Tarot Readings** - Remove daily limits on card consultations
2. **Detailed Horoscopes** - Extended predictions with Orixá influences
3. **Extra Spiritual Messages** - Daily personalized guidance from Orixás
4. **All Orixás Access** - Connect with all 21 Orixás in the tradition
5. **Personalized Notifications** - Custom spiritual reminders and alerts
6. **Exclusive Content** - Weekly premium spiritual content
7. **Priority Support** - 24/7 premium customer assistance
8. **Reading History** - Complete history of all spiritual consultations
9. **Advanced Charts** - Detailed astral chart visualizations

### Feature Gates Implementation
- Free users limited to 3 tarot readings per day
- Basic horoscope vs. detailed premium horoscope
- Access to 3 Orixás (free) vs. all 21 (premium)
- Standard notifications vs. personalized spiritual alerts

## Technical Implementation

### Architecture Components

#### 1. BillingService (`src/services/BillingService.ts`)
```typescript
// Core billing service implementing Google Play Billing Library v6+
class BillingService {
  // Connection management
  private async connectToBillingService(): Promise<void>
  
  // Product management
  private async loadAvailableProducts(): Promise<void>
  
  // Purchase flow
  public async purchaseSubscription(productId: string): Promise<boolean>
  
  // Purchase validation
  private async queryPurchases(): Promise<void>
  public async acknowledgePurchase(purchaseToken: string): Promise<void>
  
  // Subscription management
  public openSubscriptionManagement(): void
  public async cancelSubscription(productId: string): Promise<boolean>
}
```

#### 2. SubscriptionContext (`src/contexts/SubscriptionContext.tsx`)
```typescript
interface SubscriptionContextType {
  isPremium: boolean;
  currentPlan: SubscriptionPlan | null;
  purchaseSubscription: (productId: string) => Promise<boolean>;
  hasPremiumAccess: (feature: string) => boolean;
  openSubscriptionManagement: () => void;
}
```

#### 3. PremiumFeatureGuard (`src/components/PremiumFeatureGuard.tsx`)
```typescript
// Component for blocking premium content
<PremiumFeatureGuard 
  feature="unlimited_tarot_readings"
  title="Leituras Ilimitadas"
  showPreview={true}
>
  <TarotContent />
</PremiumFeatureGuard>
```

#### 4. SubscriptionPlansScreen (`src/screens/SubscriptionPlansScreen.tsx`)
Complete subscription management interface with:
- Plan comparison and selection
- Current subscription status
- Google Play billing integration
- Terms and privacy compliance

### Integration Points

#### App Structure
```typescript
<AuthProvider>
  <LocationProvider>
    <NotificationProvider>
      <SubscriptionProvider>
        <AppNavigator />
      </SubscriptionProvider>
    </NotificationProvider>
  </LocationProvider>
</AuthProvider>
```

#### Premium Feature Checks
```typescript
const { hasPremiumAccess } = useSubscription();

// Check specific feature access
if (hasPremiumAccess('unlimited_tarot_readings')) {
  // Allow unlimited readings
} else {
  // Show premium upgrade prompt
}
```

## Google Play Console Configuration

### 1. Subscription Products Setup
```
Product Details:
- Product ID: premium_mensal
- Name: Premium Mensal - Universo Místico
- Description: Acesso completo aos recursos espirituais
- Price: R$ 5,90
- Billing Period: 1 month
- Free Trial: 7 days (optional)

Product Details:
- Product ID: premium_anual  
- Name: Premium Anual - Universo Místico
- Description: Plano anual com desconto especial
- Price: R$ 59,90
- Billing Period: 1 year
- Free Trial: 7 days (optional)
```

### 2. App Bundle Configuration
```gradle
// android/app/build.gradle
android {
    defaultConfig {
        applicationId "com.universomistico.app"
        versionCode 1
        versionName "1.0.0"
    }
}

dependencies {
    implementation 'com.android.billingclient:billing:6.0.1'
}
```

### 3. Permissions
```xml
<!-- android/app/src/main/AndroidManifest.xml -->
<uses-permission android:name="com.android.vending.BILLING" />
```

## Testing Strategy

### 1. Sandbox Testing
```typescript
// Test account configuration
const TEST_PRODUCT_IDS = [
  'android.test.purchased',  // Successful purchase
  'android.test.canceled',   // Canceled purchase
  'android.test.refunded',   // Refunded purchase
];

// Enable test mode in development
if (__DEV__) {
  billingService.enableTestMode();
}
```

### 2. License Testing
- Configure test accounts in Google Play Console
- Test subscription lifecycle: purchase → active → renewal → cancellation
- Verify premium feature unlocking/locking
- Test offline scenarios and purchase restoration

### 3. Premium Feature Validation
```typescript
// Test scenarios
const testCases = [
  'Free user accessing premium content → blocked',
  'Premium user accessing premium content → allowed',
  'Subscription expired → premium features blocked',
  'Subscription renewed → premium features restored',
];
```

## Production Deployment

### 1. Google Play Store Requirements
- App must be published to Play Store internal testing first
- Subscription products must be activated in Play Console
- Real payment method required for testing subscriptions
- 14-day testing period before public release

### 2. Revenue Verification
```typescript
// Server-side verification (recommended)
const verifyPurchase = async (purchaseToken: string, productId: string) => {
  const response = await googlePlayDeveloperAPI.purchases.subscriptions.get({
    packageName: 'com.universomistico.app',
    subscriptionId: productId,
    token: purchaseToken
  });
  
  return response.data.paymentState === 1; // Valid subscription
};
```

### 3. Backend Integration
```typescript
// Sync subscription status with backend
const syncSubscriptionStatus = async (userId: number, subscriptionData: any) => {
  await apiRequest('/api/subscription/sync', {
    method: 'POST',
    body: {
      userId,
      productId: subscriptionData.productId,
      purchaseToken: subscriptionData.purchaseToken,
      expirationDate: subscriptionData.expiryTimeMillis
    }
  });
};
```

## User Experience Flow

### 1. Discovery Phase
- Free users see premium feature previews with blur effect
- Clear premium badges and upgrade prompts
- "Upgrade to Premium" buttons throughout the app

### 2. Subscription Flow
1. User taps "Upgrade to Premium"
2. Navigate to SubscriptionPlansScreen
3. Compare monthly vs. annual plans
4. Select desired plan
5. Google Play billing sheet appears
6. Complete purchase with Google Pay/card
7. Confirmation and premium features unlocked
8. Welcome to premium experience

### 3. Management Flow
- View current subscription status in profile
- "Manage Subscription" button → Google Play subscriptions
- Cancel/modify through Google Play interface
- Grace period handling for payment issues

## Compliance & Legal

### 1. Brazilian Consumer Protection
- Clear pricing in Brazilian Reais (R$)
- Subscription terms in Portuguese
- Cancellation policy compliance with Brazilian law
- 7-day cooling-off period support

### 2. Google Play Policies
- Accurate subscription descriptions
- Clear billing cycles and renewal terms
- Easy cancellation process
- No misleading premium content promises

### 3. Privacy Compliance
```typescript
// Data collection notice
const privacyNotice = `
Coletamos dados de assinatura para:
- Verificar status premium
- Personalizar conteúdo espiritual
- Enviar notificações relevantes
- Melhorar a experiência do usuário
`;
```

## Monitoring & Analytics

### 1. Subscription Metrics
- Monthly/Annual subscription rates
- Churn rate and retention analysis  
- Premium feature usage statistics
- Revenue per user (ARPU)

### 2. Feature Usage Tracking
```typescript
// Track premium feature engagement
const trackPremiumFeature = (feature: string) => {
  analytics.track('premium_feature_used', {
    feature,
    user_plan: currentPlan?.productId,
    timestamp: Date.now()
  });
};
```

### 3. Conversion Optimization
- A/B testing subscription pricing
- Premium feature gate effectiveness
- Subscription plan preference analysis
- User journey optimization

## Support & Troubleshooting

### Common Issues
1. **Purchase not recognized**: Clear app cache, restore purchases
2. **Subscription not active**: Check Google Play subscriptions
3. **Premium features locked**: Verify internet connection, sync status
4. **Billing errors**: Contact Google Play support

### Customer Support Integration
```typescript
const supportContact = {
  email: 'suporte@universomistico.com',
  whatsapp: '+55 11 9xxxx-xxxx',
  playStore: 'Google Play → Universo Místico → Support'
};
```

## Future Enhancements

### Planned Features
1. **Family Sharing**: Share premium with family members
2. **Gift Subscriptions**: Purchase premium for others
3. **Lifetime Premium**: One-time purchase option
4. **Student Discounts**: Educational pricing tiers
5. **Regional Pricing**: Different prices for different states

### Technical Roadmap
1. **Real-time Sync**: WebSocket subscription status updates
2. **Offline Premium**: Cached premium content for offline use
3. **Advanced Analytics**: Detailed subscription funnel analysis
4. **A/B Testing**: Dynamic pricing experimentation

---

This integration provides a complete, production-ready Google Play Billing system with authentic Brazilian pricing, comprehensive premium features, and robust subscription management for the spiritual astrology platform.