/**
 * Authentication Context for mobile app
 * Manages user authentication state and operations
 */

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

export interface User {
  id: number;
  email: string;
  name: string;
  birthDate?: string;
  birthTime?: string;
  birthLocation?: string;
  zodiacSign?: string;
  customOrixa?: string;
  premiumStatus?: boolean;
  createdAt?: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: any) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (updates: Partial<User>) => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const API_BASE_URL = 'http://localhost:5000'; // Replace with your server URL

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize auth state on app start
  useEffect(() => {
    initializeAuth();
  }, []);

  const initializeAuth = async () => {
    try {
      const token = await AsyncStorage.getItem('@UniversoMistico:authToken');
      const userData = await AsyncStorage.getItem('@UniversoMistico:userData');

      if (token && userData) {
        setUser(JSON.parse(userData));
        // Set axios default header
        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      }
    } catch (error) {
      console.error('Auth initialization failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (email: string, password: string): Promise<void> => {
    try {
      setIsLoading(true);
      const response = await axios.post(`${API_BASE_URL}/api/auth/login`, {
        email,
        password,
      });

      const { user: userData, token } = response.data;

      // Store auth data
      await AsyncStorage.setItem('@UniversoMistico:authToken', token);
      await AsyncStorage.setItem('@UniversoMistico:userData', JSON.stringify(userData));

      // Set axios default header
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;

      setUser(userData);
    } catch (error) {
      throw new Error('Login failed. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData: any): Promise<void> => {
    try {
      setIsLoading(true);
      const response = await axios.post(`${API_BASE_URL}/api/auth/register`, userData);

      const { user: newUser, token } = response.data;

      // Store auth data
      await AsyncStorage.setItem('@UniversoMistico:authToken', token);
      await AsyncStorage.setItem('@UniversoMistico:userData', JSON.stringify(newUser));

      // Set axios default header
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;

      setUser(newUser);
    } catch (error) {
      throw new Error('Registration failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async (): Promise<void> => {
    try {
      setIsLoading(true);

      // Clear stored data
      await AsyncStorage.removeItem('@UniversoMistico:authToken');
      await AsyncStorage.removeItem('@UniversoMistico:userData');

      // Clear axios default header
      delete axios.defaults.headers.common['Authorization'];

      setUser(null);
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateProfile = async (updates: Partial<User>): Promise<void> => {
    if (!user) throw new Error('User not authenticated');

    try {
      setIsLoading(true);
      const response = await axios.patch(`${API_BASE_URL}/api/auth/profile`, updates);

      const updatedUser = response.data;

      // Update stored user data
      await AsyncStorage.setItem('@UniversoMistico:userData', JSON.stringify(updatedUser));

      setUser(updatedUser);
    } catch (error) {
      throw new Error('Profile update failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const refreshUser = async (): Promise<void> => {
    if (!user) return;

    try {
      const response = await axios.get(`${API_BASE_URL}/api/auth/me`);
      const userData = response.data;

      // Update stored user data
      await AsyncStorage.setItem('@UniversoMistico:userData', JSON.stringify(userData));

      setUser(userData);
    } catch (error) {
      console.error('Failed to refresh user:', error);
      // If refresh fails, user might need to re-authenticate
      await logout();
    }
  };

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    register,
    logout,
    updateProfile,
    refreshUser,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}