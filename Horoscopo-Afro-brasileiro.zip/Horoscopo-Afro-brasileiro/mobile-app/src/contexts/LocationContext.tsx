/**
 * Location Context for mobile app
 * Manages geolocation state and astrology location features
 */

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { LocationService, LocationData, AstrologyLocationData } from '../services/LocationService';

interface LocationContextType {
  currentLocation: LocationData | null;
  astrologyData: AstrologyLocationData | null;
  isLocationEnabled: boolean;
  isLoading: boolean;
  error: string | null;
  getCurrentLocation: () => Promise<LocationData | null>;
  getAstrologyData: () => Promise<AstrologyLocationData | null>;
  startTracking: () => Promise<boolean>;
  stopTracking: () => void;
  findNearbyPoints: (radius?: number) => Promise<any[]>;
}

const LocationContext = createContext<LocationContextType | undefined>(undefined);

interface LocationProviderProps {
  children: ReactNode;
}

export function LocationProvider({ children }: LocationProviderProps) {
  const [currentLocation, setCurrentLocation] = useState<LocationData | null>(null);
  const [astrologyData, setAstrologyData] = useState<AstrologyLocationData | null>(null);
  const [isLocationEnabled, setIsLocationEnabled] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    initializeLocation();
  }, []);

  const initializeLocation = async () => {
    try {
      setIsLoading(true);
      setError(null);

      const enabled = await LocationService.isLocationEnabled();
      setIsLocationEnabled(enabled);

      if (enabled) {
        const lastKnown = LocationService.getLastKnownLocation();
        if (lastKnown) {
          setCurrentLocation(lastKnown);
        }
      }
    } catch (err) {
      setError('Failed to initialize location services');
      console.error('Location initialization error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const getCurrentLocation = async (): Promise<LocationData | null> => {
    try {
      setIsLoading(true);
      setError(null);

      const location = await LocationService.getCurrentLocation();
      if (location) {
        setCurrentLocation(location);
        return location;
      } else {
        setError('Unable to get current location');
        return null;
      }
    } catch (err) {
      setError('Failed to get location. Please check permissions.');
      console.error('Get location error:', err);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const getAstrologyData = async (): Promise<AstrologyLocationData | null> => {
    try {
      setIsLoading(true);
      setError(null);

      const data = await LocationService.getAstrologyLocationData();
      if (data) {
        setAstrologyData(data);
        setCurrentLocation(data);
        return data;
      } else {
        setError('Unable to get astrology location data');
        return null;
      }
    } catch (err) {
      setError('Failed to get astrology data');
      console.error('Astrology data error:', err);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const startTracking = async (): Promise<boolean> => {
    try {
      setError(null);

      const success = await LocationService.startTracking((location) => {
        setCurrentLocation(location);
      });

      if (!success) {
        setError('Failed to start location tracking');
      }

      return success;
    } catch (err) {
      setError('Failed to start tracking');
      console.error('Start tracking error:', err);
      return false;
    }
  };

  const stopTracking = (): void => {
    LocationService.stopTracking();
  };

  const findNearbyPoints = async (radius: number = 10): Promise<any[]> => {
    try {
      setError(null);
      return await LocationService.findNearbyAstrologyPoints(radius);
    } catch (err) {
      setError('Failed to find nearby points');
      console.error('Find nearby points error:', err);
      return [];
    }
  };

  const value: LocationContextType = {
    currentLocation,
    astrologyData,
    isLocationEnabled,
    isLoading,
    error,
    getCurrentLocation,
    getAstrologyData,
    startTracking,
    stopTracking,
    findNearbyPoints,
  };

  return (
    <LocationContext.Provider value={value}>
      {children}
    </LocationContext.Provider>
  );
}

export function useLocation(): LocationContextType {
  const context = useContext(LocationContext);
  if (context === undefined) {
    throw new Error('useLocation must be used within a LocationProvider');
  }
  return context;
}