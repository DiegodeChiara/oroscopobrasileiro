/**
 * Notification Context for mobile app
 * Manages push notifications and astrology notifications
 */

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { NotificationService, NotificationData } from '../services/NotificationService';

interface NotificationContextType {
  isInitialized: boolean;
  pushToken: string | null;
  notificationHistory: any[];
  scheduledNotifications: any[];
  sendLocalNotification: (notification: NotificationData) => Promise<void>;
  scheduleNotification: (notification: NotificationData) => Promise<void>;
  scheduleCelestialNotification: (eventName: string, eventTime: Date, description: string) => Promise<void>;
  sendTarotNotification: (message: string) => Promise<void>;
  cancelNotification: (identifier: string) => Promise<void>;
  getNotificationHistory: () => Promise<any[]>;
  refreshScheduledNotifications: () => Promise<void>;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

interface NotificationProviderProps {
  children: ReactNode;
}

export function NotificationProvider({ children }: NotificationProviderProps) {
  const [isInitialized, setIsInitialized] = useState(false);
  const [pushToken, setPushToken] = useState<string | null>(null);
  const [notificationHistory, setNotificationHistory] = useState<any[]>([]);
  const [scheduledNotifications, setScheduledNotifications] = useState<any[]>([]);

  useEffect(() => {
    initializeNotifications();
    return () => {
      NotificationService.cleanup();
    };
  }, []);

  const initializeNotifications = async () => {
    try {
      const success = await NotificationService.initialize();
      setIsInitialized(success);

      if (success) {
        const token = NotificationService.getPushToken();
        setPushToken(token);

        // Load notification history
        const history = await NotificationService.getNotificationHistory();
        setNotificationHistory(history);

        // Load scheduled notifications
        await refreshScheduledNotifications();
      }
    } catch (error) {
      console.error('Failed to initialize notifications:', error);
      setIsInitialized(false);
    }
  };

  const sendLocalNotification = async (notification: NotificationData): Promise<void> => {
    try {
      await NotificationService.sendLocalNotification(notification);
      
      // Refresh history
      const history = await NotificationService.getNotificationHistory();
      setNotificationHistory(history);
    } catch (error) {
      console.error('Failed to send local notification:', error);
      throw error;
    }
  };

  const scheduleNotification = async (notification: NotificationData): Promise<void> => {
    try {
      await NotificationService.scheduleNotification(notification);
      
      // Refresh scheduled notifications
      await refreshScheduledNotifications();
    } catch (error) {
      console.error('Failed to schedule notification:', error);
      throw error;
    }
  };

  const scheduleCelestialNotification = async (
    eventName: string,
    eventTime: Date,
    description: string
  ): Promise<void> => {
    try {
      await NotificationService.scheduleCelestialNotification(eventName, eventTime, description);
      
      // Refresh scheduled notifications
      await refreshScheduledNotifications();
    } catch (error) {
      console.error('Failed to schedule celestial notification:', error);
      throw error;
    }
  };

  const sendTarotNotification = async (message: string): Promise<void> => {
    try {
      await NotificationService.sendTarotNotification(message);
      
      // Refresh history
      const history = await NotificationService.getNotificationHistory();
      setNotificationHistory(history);
    } catch (error) {
      console.error('Failed to send tarot notification:', error);
      throw error;
    }
  };

  const cancelNotification = async (identifier: string): Promise<void> => {
    try {
      await NotificationService.cancelNotification(identifier);
      
      // Refresh scheduled notifications
      await refreshScheduledNotifications();
    } catch (error) {
      console.error('Failed to cancel notification:', error);
      throw error;
    }
  };

  const getNotificationHistory = async (): Promise<any[]> => {
    try {
      const history = await NotificationService.getNotificationHistory();
      setNotificationHistory(history);
      return history;
    } catch (error) {
      console.error('Failed to get notification history:', error);
      return [];
    }
  };

  const refreshScheduledNotifications = async (): Promise<void> => {
    try {
      const scheduled = await NotificationService.getScheduledNotifications();
      setScheduledNotifications(scheduled);
    } catch (error) {
      console.error('Failed to refresh scheduled notifications:', error);
    }
  };

  const value: NotificationContextType = {
    isInitialized,
    pushToken,
    notificationHistory,
    scheduledNotifications,
    sendLocalNotification,
    scheduleNotification,
    scheduleCelestialNotification,
    sendTarotNotification,
    cancelNotification,
    getNotificationHistory,
    refreshScheduledNotifications,
  };

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotification(): NotificationContextType {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotification must be used within a NotificationProvider');
  }
  return context;
}