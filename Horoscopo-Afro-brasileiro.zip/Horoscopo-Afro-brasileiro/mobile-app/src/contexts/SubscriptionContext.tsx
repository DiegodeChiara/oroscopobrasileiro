/**
 * Subscription Context for Premium Billing Management
 * Manages Google Play Billing state and premium features access
 */

import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { Alert } from 'react-native';
import billingService, { BillingState, SubscriptionPlan, SUBSCRIPTION_PLANS } from '../services/BillingService';

interface SubscriptionContextType {
  // Billing state
  billingState: BillingState;
  isLoading: boolean;
  
  // Premium status
  isPremium: boolean;
  currentPlan: SubscriptionPlan | null;
  
  // Available plans
  availablePlans: SubscriptionPlan[];
  
  // Actions
  purchaseSubscription: (productId: string) => Promise<boolean>;
  openSubscriptionManagement: () => void;
  cancelSubscription: () => Promise<boolean>;
  refreshSubscriptionStatus: () => Promise<void>;
  
  // Premium feature checks
  hasPremiumAccess: (feature: string) => boolean;
  getPremiumMessage: () => string;
}

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

interface SubscriptionProviderProps {
  children: ReactNode;
}

export function SubscriptionProvider({ children }: SubscriptionProviderProps) {
  const [billingState, setBillingState] = useState<BillingState>(billingService.getState());
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // Listen to billing state changes
    const handleStateChange = (newState: BillingState) => {
      setBillingState(newState);
    };

    billingService.addStateListener(handleStateChange);

    // Initial state update
    setBillingState(billingService.getState());

    return () => {
      billingService.removeStateListener(handleStateChange);
    };
  }, []);

  const purchaseSubscription = async (productId: string): Promise<boolean> => {
    try {
      setIsLoading(true);
      
      const plan = SUBSCRIPTION_PLANS.find(p => p.productId === productId);
      if (!plan) {
        throw new Error('Plano não encontrado');
      }

      // Show confirmation dialog
      return new Promise((resolve) => {
        Alert.alert(
          'Confirmar Assinatura',
          `Deseja assinar o plano ${plan.title} por ${plan.price}?`,
          [
            {
              text: 'Cancelar',
              style: 'cancel',
              onPress: () => {
                setIsLoading(false);
                resolve(false);
              }
            },
            {
              text: 'Assinar',
              onPress: async () => {
                try {
                  const success = await billingService.purchaseSubscription(productId);
                  
                  if (success) {
                    Alert.alert(
                      'Assinatura Ativada!',
                      `Bem-vindo ao ${plan.title}! Agora você tem acesso a todos os recursos premium.`,
                      [{ text: 'OK' }]
                    );
                  } else {
                    Alert.alert(
                      'Assinatura Cancelada',
                      'A assinatura foi cancelada ou não pôde ser processada.',
                      [{ text: 'OK' }]
                    );
                  }
                  
                  setIsLoading(false);
                  resolve(success);
                } catch (error) {
                  console.error('Purchase error:', error);
                  Alert.alert(
                    'Erro na Assinatura',
                    'Não foi possível processar sua assinatura. Tente novamente.',
                    [{ text: 'OK' }]
                  );
                  setIsLoading(false);
                  resolve(false);
                }
              }
            }
          ]
        );
      });
    } catch (error) {
      console.error('Purchase subscription error:', error);
      setIsLoading(false);
      Alert.alert('Erro', 'Não foi possível iniciar a assinatura.');
      return false;
    }
  };

  const openSubscriptionManagement = () => {
    billingService.openSubscriptionManagement();
  };

  const cancelSubscription = async (): Promise<boolean> => {
    try {
      if (!billingState.currentPlan) {
        Alert.alert('Erro', 'Nenhuma assinatura ativa encontrada.');
        return false;
      }

      return new Promise((resolve) => {
        Alert.alert(
          'Cancelar Assinatura',
          'Tem certeza que deseja cancelar sua assinatura premium? Você perderá acesso aos recursos exclusivos.',
          [
            {
              text: 'Manter Assinatura',
              style: 'cancel',
              onPress: () => resolve(false)
            },
            {
              text: 'Cancelar Assinatura',
              style: 'destructive',
              onPress: async () => {
                try {
                  const success = await billingService.cancelSubscription(billingState.currentPlan!);
                  
                  if (success) {
                    Alert.alert(
                      'Assinatura Cancelada',
                      'Sua assinatura foi cancelada. Você ainda terá acesso aos recursos premium até o final do período atual.',
                      [{ text: 'OK' }]
                    );
                  }
                  
                  resolve(success);
                } catch (error) {
                  console.error('Cancel subscription error:', error);
                  Alert.alert('Erro', 'Não foi possível cancelar a assinatura.');
                  resolve(false);
                }
              }
            }
          ]
        );
      });
    } catch (error) {
      console.error('Cancel subscription error:', error);
      Alert.alert('Erro', 'Não foi possível cancelar a assinatura.');
      return false;
    }
  };

  const refreshSubscriptionStatus = async (): Promise<void> => {
    try {
      setIsLoading(true);
      // In real implementation, this would refresh from Google Play
      // For now, we'll just update the current state
      await new Promise(resolve => setTimeout(resolve, 1000));
      setIsLoading(false);
    } catch (error) {
      console.error('Refresh subscription error:', error);
      setIsLoading(false);
    }
  };

  const hasPremiumAccess = (feature: string): boolean => {
    if (!billingState.isPremium) {
      return false;
    }

    // Define premium features
    const premiumFeatures = [
      'unlimited_tarot_readings',
      'detailed_horoscopes',
      'extra_spiritual_messages',
      'all_orixas_access',
      'personalized_notifications',
      'exclusive_content',
      'priority_support',
      'reading_history',
      'advanced_charts'
    ];

    return premiumFeatures.includes(feature);
  };

  const getPremiumMessage = (): string => {
    const messages = [
      'Desbloqueie todo o poder espiritual com o Premium!',
      'Acesse horóscopos detalhados e leituras ilimitadas.',
      'Conecte-se com todos os Orixás e receba orientação exclusiva.',
      'Evolua sua jornada espiritual com conteúdo premium.',
      'Descubra insights profundos sobre seu destino.'
    ];

    return messages[Math.floor(Math.random() * messages.length)];
  };

  const currentPlan = billingState.currentPlan 
    ? SUBSCRIPTION_PLANS.find(plan => plan.productId === billingState.currentPlan) || null
    : null;

  const value: SubscriptionContextType = {
    billingState,
    isLoading,
    isPremium: billingState.isPremium,
    currentPlan,
    availablePlans: SUBSCRIPTION_PLANS,
    purchaseSubscription,
    openSubscriptionManagement,
    cancelSubscription,
    refreshSubscriptionStatus,
    hasPremiumAccess,
    getPremiumMessage
  };

  return (
    <SubscriptionContext.Provider value={value}>
      {children}
    </SubscriptionContext.Provider>
  );
}

export function useSubscription(): SubscriptionContextType {
  const context = useContext(SubscriptionContext);
  if (context === undefined) {
    throw new Error('useSubscription must be used within a SubscriptionProvider');
  }
  return context;
}

// Premium feature guard hook
export function usePremiumFeature(feature: string): {
  hasAccess: boolean;
  requestAccess: () => void;
  premiumMessage: string;
} {
  const { hasPremiumAccess, getPremiumMessage } = useSubscription();
  
  const hasAccess = hasPremiumAccess(feature);
  const premiumMessage = getPremiumMessage();

  const requestAccess = () => {
    Alert.alert(
      'Recurso Premium',
      `${premiumMessage}\n\nEste recurso está disponível apenas para assinantes premium.`,
      [
        { text: 'Cancelar', style: 'cancel' },
        { 
          text: 'Ver Planos', 
          onPress: () => {
            // Navigation to subscription plans would go here
            console.log('Navigate to subscription plans');
          }
        }
      ]
    );
  };

  return {
    hasAccess,
    requestAccess,
    premiumMessage
  };
}