/**
 * Premium Feature Guard Component
 * Blocks premium content for non-subscribers and shows upgrade prompts
 */

import React, { ReactNode } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import {
  Card,
  Title,
  Paragraph,
  Button,
  Chip,
  Surface,
} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useSubscription } from '../contexts/SubscriptionContext';
import { mysticalTheme } from '../theme/theme';

interface PremiumFeatureGuardProps {
  children: ReactNode;
  feature: string;
  title?: string;
  description?: string;
  onUpgradePress?: () => void;
  showPreview?: boolean;
  blurLevel?: 'light' | 'medium' | 'heavy';
}

export default function PremiumFeatureGuard({
  children,
  feature,
  title = 'Recurso Premium',
  description,
  onUpgradePress,
  showPreview = false,
  blurLevel = 'medium'
}: PremiumFeatureGuardProps) {
  const { hasPremiumAccess, getPremiumMessage } = useSubscription();

  const hasAccess = hasPremiumAccess(feature);

  if (hasAccess) {
    return <>{children}</>;
  }

  const premiumMessage = description || getPremiumMessage();

  if (showPreview) {
    return (
      <View style={styles.container}>
        <View style={[
          styles.previewContainer,
          blurLevel === 'light' && styles.lightBlur,
          blurLevel === 'medium' && styles.mediumBlur,
          blurLevel === 'heavy' && styles.heavyBlur
        ]}>
          {children}
        </View>
        <View style={styles.overlay}>
          <PremiumPrompt
            title={title}
            description={premiumMessage}
            onUpgradePress={onUpgradePress}
          />
        </View>
      </View>
    );
  }

  return (
    <PremiumPrompt
      title={title}
      description={premiumMessage}
      onUpgradePress={onUpgradePress}
    />
  );
}

interface PremiumPromptProps {
  title: string;
  description: string;
  onUpgradePress?: () => void;
}

function PremiumPrompt({ title, description, onUpgradePress }: PremiumPromptProps) {
  const handleUpgradePress = () => {
    if (onUpgradePress) {
      onUpgradePress();
    } else {
      // Default navigation to subscription plans
      console.log('Navigate to subscription plans');
    }
  };

  return (
    <Card style={styles.premiumCard}>
      <Card.Content style={styles.premiumContent}>
        <View style={styles.premiumHeader}>
          <Surface style={styles.iconContainer}>
            <Icon name="crown" size={32} color={mysticalTheme.colors.tertiary} />
          </Surface>
          <Chip style={styles.premiumChip} textStyle={styles.chipText}>
            Premium
          </Chip>
        </View>
        
        <Title style={styles.premiumTitle}>{title}</Title>
        <Paragraph style={styles.premiumDescription}>
          {description}
        </Paragraph>
        
        <View style={styles.benefitsContainer}>
          <View style={styles.benefitItem}>
            <Icon name="check-circle" size={16} color={mysticalTheme.colors.tertiary} />
            <Text style={styles.benefitText}>Acesso ilimitado</Text>
          </View>
          <View style={styles.benefitItem}>
            <Icon name="check-circle" size={16} color={mysticalTheme.colors.tertiary} />
            <Text style={styles.benefitText}>Conteúdo exclusivo</Text>
          </View>
          <View style={styles.benefitItem}>
            <Icon name="check-circle" size={16} color={mysticalTheme.colors.tertiary} />
            <Text style={styles.benefitText}>Suporte prioritário</Text>
          </View>
        </View>
        
        <Button
          mode="contained"
          onPress={handleUpgradePress}
          style={styles.upgradeButton}
          icon="star"
        >
          Upgrade para Premium
        </Button>
        
        <TouchableOpacity style={styles.priceInfo}>
          <Text style={styles.priceText}>A partir de R$ 5,90/mês</Text>
        </TouchableOpacity>
      </Card.Content>
    </Card>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'relative',
  },
  previewContainer: {
    position: 'relative',
  },
  lightBlur: {
    opacity: 0.8,
  },
  mediumBlur: {
    opacity: 0.5,
  },
  heavyBlur: {
    opacity: 0.3,
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
  },
  premiumCard: {
    margin: 16,
    borderRadius: 16,
    elevation: 4,
    backgroundColor: mysticalTheme.colors.surface,
    borderColor: mysticalTheme.colors.tertiary,
    borderWidth: 1,
  },
  premiumContent: {
    padding: 24,
    alignItems: 'center',
  },
  premiumHeader: {
    alignItems: 'center',
    marginBottom: 16,
  },
  iconContainer: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: mysticalTheme.colors.tertiaryContainer,
    marginBottom: 8,
  },
  premiumChip: {
    backgroundColor: mysticalTheme.colors.tertiary,
  },
  chipText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  premiumTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: mysticalTheme.colors.onSurface,
    textAlign: 'center',
    marginBottom: 8,
  },
  premiumDescription: {
    fontSize: 14,
    color: mysticalTheme.colors.onSurfaceVariant,
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 20,
  },
  benefitsContainer: {
    alignSelf: 'stretch',
    marginBottom: 24,
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    justifyContent: 'center',
  },
  benefitText: {
    marginLeft: 8,
    fontSize: 14,
    color: mysticalTheme.colors.onSurface,
  },
  upgradeButton: {
    backgroundColor: mysticalTheme.colors.tertiary,
    paddingHorizontal: 24,
    paddingVertical: 4,
    marginBottom: 12,
  },
  priceInfo: {
    padding: 8,
  },
  priceText: {
    fontSize: 12,
    color: mysticalTheme.colors.onSurfaceVariant,
    textAlign: 'center',
    fontStyle: 'italic',
  },
});

// Premium feature wrapper hook
export function usePremiumGuard(feature: string) {
  const { hasPremiumAccess } = useSubscription();
  
  const checkAccess = (callback: () => void) => {
    if (hasPremiumAccess(feature)) {
      callback();
    } else {
      console.log(`Premium feature ${feature} blocked - redirecting to upgrade`);
    }
  };

  return {
    hasAccess: hasPremiumAccess(feature),
    checkAccess
  };
}