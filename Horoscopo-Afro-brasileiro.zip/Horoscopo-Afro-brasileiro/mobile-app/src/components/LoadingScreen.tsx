/**
 * Loading Screen Component
 * Displays a mystical loading animation while the app initializes
 */

import React from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import { ActivityIndicator } from 'react-native-paper';
import { mysticalTheme } from '../theme/theme';

const { width, height } = Dimensions.get('window');

export default function LoadingScreen() {
  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.logo}>🔮</Text>
        <Text style={styles.title}>Universo Místico</Text>
        <Text style={styles.subtitle}>Conectando você ao cosmos...</Text>
        <ActivityIndicator 
          size="large" 
          animating={true} 
          color={mysticalTheme.colors.primary}
          style={styles.spinner}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: mysticalTheme.colors.primaryContainer,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    fontSize: 80,
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: mysticalTheme.colors.primary,
    marginBottom: 10,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: mysticalTheme.colors.onSurface,
    marginBottom: 40,
    textAlign: 'center',
  },
  spinner: {
    marginTop: 20,
  },
});