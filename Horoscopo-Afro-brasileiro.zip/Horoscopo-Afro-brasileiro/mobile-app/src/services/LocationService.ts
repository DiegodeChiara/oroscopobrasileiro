/**
 * Location Service for geolocation functionality
 * Handles location permissions, tracking, and astrology-based location features
 */

import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface LocationData {
  latitude: number;
  longitude: number;
  address?: string;
  city?: string;
  country?: string;
  timestamp: number;
}

export interface AstrologyLocationData extends LocationData {
  timezone: string;
  sunrise: Date;
  sunset: Date;
  moonPhase: string;
  celestialEvents: string[];
}

class LocationServiceClass {
  private currentLocation: LocationData | null = null;
  private watchSubscription: Location.LocationSubscription | null = null;
  private isTracking = false;

  /**
   * Initialize location service and request permissions
   */
  async initialize(): Promise<boolean> {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      
      if (status !== 'granted') {
        console.warn('Location permission denied');
        return false;
      }

      // Load last known location
      await this.loadStoredLocation();
      
      return true;
    } catch (error) {
      console.error('Failed to initialize location service:', error);
      return false;
    }
  }

  /**
   * Get current location
   */
  async getCurrentLocation(): Promise<LocationData | null> {
    try {
      const { status } = await Location.getForegroundPermissionsAsync();
      
      if (status !== 'granted') {
        throw new Error('Location permission not granted');
      }

      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
        timeInterval: 10000,
        distanceInterval: 100,
      });

      const locationData: LocationData = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
        timestamp: Date.now(),
      };

      // Get address information
      try {
        const reverseGeocode = await Location.reverseGeocodeAsync({
          latitude: locationData.latitude,
          longitude: locationData.longitude,
        });

        if (reverseGeocode.length > 0) {
          const address = reverseGeocode[0];
          locationData.address = `${address.street || ''} ${address.streetNumber || ''}`.trim();
          locationData.city = address.city || address.subregion || '';
          locationData.country = address.country || '';
        }
      } catch (geocodeError) {
        console.warn('Failed to get address:', geocodeError);
      }

      this.currentLocation = locationData;
      await this.storeLocation(locationData);
      
      return locationData;
    } catch (error) {
      console.error('Failed to get current location:', error);
      return null;
    }
  }

  /**
   * Start location tracking for continuous updates
   */
  async startTracking(onLocationUpdate: (location: LocationData) => void): Promise<boolean> {
    try {
      if (this.isTracking) {
        return true;
      }

      const { status } = await Location.getForegroundPermissionsAsync();
      
      if (status !== 'granted') {
        throw new Error('Location permission not granted');
      }

      this.watchSubscription = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.High,
          timeInterval: 30000, // Update every 30 seconds
          distanceInterval: 50, // Update when moved 50 meters
        },
        async (location) => {
          const locationData: LocationData = {
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
            timestamp: Date.now(),
          };

          this.currentLocation = locationData;
          await this.storeLocation(locationData);
          onLocationUpdate(locationData);
        }
      );

      this.isTracking = true;
      return true;
    } catch (error) {
      console.error('Failed to start location tracking:', error);
      return false;
    }
  }

  /**
   * Stop location tracking
   */
  stopTracking(): void {
    if (this.watchSubscription) {
      this.watchSubscription.remove();
      this.watchSubscription = null;
    }
    this.isTracking = false;
  }

  /**
   * Get astrology-specific location data
   */
  async getAstrologyLocationData(): Promise<AstrologyLocationData | null> {
    const location = await this.getCurrentLocation();
    
    if (!location) {
      return null;
    }

    try {
      // Calculate timezone
      const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
      
      // Calculate sunrise/sunset (simplified calculation)
      const now = new Date();
      const sunrise = new Date(now);
      sunrise.setHours(6, 0, 0, 0); // Simplified - in real app, use proper solar calculation
      
      const sunset = new Date(now);
      sunset.setHours(18, 0, 0, 0); // Simplified - in real app, use proper solar calculation

      // Calculate moon phase (simplified)
      const moonPhase = this.calculateMoonPhase(now);

      // Get celestial events (simplified)
      const celestialEvents = this.getCelestialEvents(now, location);

      return {
        ...location,
        timezone,
        sunrise,
        sunset,
        moonPhase,
        celestialEvents,
      };
    } catch (error) {
      console.error('Failed to get astrology location data:', error);
      return null;
    }
  }

  /**
   * Check if location services are available
   */
  async isLocationEnabled(): Promise<boolean> {
    return await Location.hasServicesEnabledAsync();
  }

  /**
   * Get last known location
   */
  getLastKnownLocation(): LocationData | null {
    return this.currentLocation;
  }

  /**
   * Calculate distance between two points
   */
  calculateDistance(
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number
  ): number {
    const R = 6371; // Earth's radius in kilometers
    const dLat = this.toRadians(lat2 - lat1);
    const dLon = this.toRadians(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRadians(lat1)) *
        Math.cos(this.toRadians(lat2)) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  /**
   * Find nearby astrology points of interest
   */
  async findNearbyAstrologyPoints(radius: number = 10): Promise<any[]> {
    const location = await this.getCurrentLocation();
    
    if (!location) {
      return [];
    }

    // Simulated points of interest for astrology
    const astrologyPoints = [
      {
        id: 1,
        name: 'Centro Espiritual Luz Divina',
        type: 'spiritual_center',
        latitude: location.latitude + 0.01,
        longitude: location.longitude + 0.01,
        description: 'Centro de estudos esotéricos e consultas espirituais',
        services: ['Consulta com médiuns', 'Leitura de tarô', 'Benzimento'],
      },
      {
        id: 2,
        name: 'Templo de Umbanda São Jorge',
        type: 'temple',
        latitude: location.latitude - 0.005,
        longitude: location.longitude + 0.015,
        description: 'Terreiro tradicional de Umbanda',
        services: ['Giras', 'Consultas com Orixás', 'Trabalhos espirituais'],
      },
      {
        id: 3,
        name: 'Loja Esotérica Cristais & Magia',
        type: 'store',
        latitude: location.latitude + 0.008,
        longitude: location.longitude - 0.012,
        description: 'Loja especializada em produtos esotéricos',
        services: ['Cristais', 'Incensos', 'Livros esotéricos', 'Amuletos'],
      },
    ];

    return astrologyPoints.filter(point => {
      const distance = this.calculateDistance(
        location.latitude,
        location.longitude,
        point.latitude,
        point.longitude
      );
      return distance <= radius;
    });
  }

  private async storeLocation(location: LocationData): Promise<void> {
    try {
      await AsyncStorage.setItem(
        '@UniversoMistico:lastLocation',
        JSON.stringify(location)
      );
    } catch (error) {
      console.error('Failed to store location:', error);
    }
  }

  private async loadStoredLocation(): Promise<void> {
    try {
      const stored = await AsyncStorage.getItem('@UniversoMistico:lastLocation');
      if (stored) {
        this.currentLocation = JSON.parse(stored);
      }
    } catch (error) {
      console.error('Failed to load stored location:', error);
    }
  }

  private toRadians(degrees: number): number {
    return degrees * (Math.PI / 180);
  }

  private calculateMoonPhase(date: Date): string {
    // Simplified moon phase calculation
    let year = date.getFullYear();
    let month = date.getMonth() + 1;
    const day = date.getDate();
    
    let c = 0;
    let e = 0;
    let jd = 0;
    let b = 0;
    
    if (month < 3) {
      year--;
      month += 12;
    }
    
    month++;
    c = 365.25 * year;
    e = 30.6 * month;
    jd = c + e + day - 694039.09;
    jd /= 29.5305882;
    b = parseInt(jd.toString());
    jd -= b;
    b = Math.round(jd * 8);
    
    if (b >= 8) b = 0;
    
    const phases = [
      'Lua Nova',
      'Crescente',
      'Quarto Crescente',
      'Crescente Gibosa',
      'Lua Cheia',
      'Minguante Gibosa',
      'Quarto Minguante',
      'Minguante'
    ];
    
    return phases[b];
  }

  private getCelestialEvents(date: Date, location: LocationData): string[] {
    // Simplified celestial events
    const events: string[] = [];
    const month = date.getMonth() + 1;
    const day = date.getDate();
    
    // Add some seasonal events
    if (month === 3 && day >= 20) events.push('Equinócio de Outono');
    if (month === 6 && day >= 21) events.push('Solstício de Inverno');
    if (month === 9 && day >= 22) events.push('Equinócio de Primavera');
    if (month === 12 && day >= 21) events.push('Solstício de Verão');
    
    // Add weekly events based on day
    const dayOfWeek = date.getDay();
    if (dayOfWeek === 0) events.push('Energia Solar Dominical');
    if (dayOfWeek === 1) events.push('Influência Lunar da Segunda');
    
    return events;
  }
}

export const LocationService = new LocationServiceClass();