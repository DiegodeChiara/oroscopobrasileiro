/**
 * Notification Service for push notifications
 * Handles notification permissions, scheduling, and astrology-based notifications
 */

import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface NotificationData {
  id: string;
  title: string;
  body: string;
  data?: any;
  scheduledTime?: Date;
  type: 'horoscope' | 'tarot' | 'spiritual' | 'reminder' | 'celestial';
}

export interface ScheduledNotification extends NotificationData {
  identifier: string;
  trigger: Notifications.NotificationTriggerInput;
}

// Configure notification behavior
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

class NotificationServiceClass {
  private expoPushToken: string | null = null;
  private notificationListener: Notifications.Subscription | null = null;
  private responseListener: Notifications.Subscription | null = null;

  /**
   * Initialize notification service and request permissions
   */
  async initialize(): Promise<boolean> {
    try {
      if (!Device.isDevice) {
        console.warn('Push notifications only work on physical devices');
        return false;
      }

      // Request permissions
      const { status: existingStatus } = await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;

      if (existingStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }

      if (finalStatus !== 'granted') {
        console.warn('Notification permission denied');
        return false;
      }

      // Get push token
      this.expoPushToken = await this.registerForPushNotificationsAsync();

      // Set up notification listeners
      this.setupNotificationListeners();

      // Schedule daily astrology notifications
      await this.scheduleDailyNotifications();

      return true;
    } catch (error) {
      console.error('Failed to initialize notification service:', error);
      return false;
    }
  }

  /**
   * Register for push notifications and get token
   */
  private async registerForPushNotificationsAsync(): Promise<string> {
    let token = '';

    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('default', {
        name: 'Universo Místico',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#8b5cf6',
        sound: 'notification.wav',
      });
    }

    const { data } = await Notifications.getExpoPushTokenAsync({
      projectId: 'your-expo-project-id', // Replace with actual project ID
    });
    token = data;

    return token;
  }

  /**
   * Set up notification event listeners
   */
  private setupNotificationListeners(): void {
    // Handle notifications received while app is running
    this.notificationListener = Notifications.addNotificationReceivedListener(notification => {
      console.log('Notification received:', notification);
      this.handleNotificationReceived(notification);
    });

    // Handle notification responses (when user taps notification)
    this.responseListener = Notifications.addNotificationResponseReceivedListener(response => {
      console.log('Notification response:', response);
      this.handleNotificationResponse(response);
    });
  }

  /**
   * Handle notification received while app is running
   */
  private handleNotificationReceived(notification: Notifications.Notification): void {
    const { data } = notification.request.content;
    
    // Store notification in local storage for history
    this.storeNotificationHistory(notification);
    
    // Handle specific notification types
    switch (data?.type) {
      case 'horoscope':
        // Navigate to horoscope or show in-app alert
        break;
      case 'tarot':
        // Navigate to tarot section
        break;
      case 'spiritual':
        // Navigate to spiritual profile
        break;
      case 'celestial':
        // Show celestial event details
        break;
      default:
        break;
    }
  }

  /**
   * Handle notification response (when user taps notification)
   */
  private handleNotificationResponse(response: Notifications.NotificationResponse): void {
    const { data } = response.notification.request.content;
    
    // Handle navigation based on notification type
    switch (data?.type) {
      case 'horoscope':
        // Navigate to home/horoscope
        break;
      case 'tarot':
        // Navigate to tarot screen
        break;
      case 'spiritual':
        // Navigate to spiritual profile
        break;
      case 'celestial':
        // Navigate to map with celestial events
        break;
      default:
        // Navigate to home
        break;
    }
  }

  /**
   * Send immediate local notification
   */
  async sendLocalNotification(notification: NotificationData): Promise<string> {
    try {
      const identifier = await Notifications.scheduleNotificationAsync({
        content: {
          title: notification.title,
          body: notification.body,
          data: notification.data,
          sound: 'notification.wav',
        },
        trigger: null, // Send immediately
      });

      return identifier;
    } catch (error) {
      console.error('Failed to send local notification:', error);
      throw error;
    }
  }

  /**
   * Schedule notification for later
   */
  async scheduleNotification(notification: NotificationData): Promise<string> {
    try {
      if (!notification.scheduledTime) {
        throw new Error('Scheduled time is required for scheduled notifications');
      }

      const identifier = await Notifications.scheduleNotificationAsync({
        content: {
          title: notification.title,
          body: notification.body,
          data: notification.data,
          sound: 'notification.wav',
        },
        trigger: {
          date: notification.scheduledTime,
        },
      });

      // Store scheduled notification
      await this.storeScheduledNotification({
        ...notification,
        identifier,
        trigger: { date: notification.scheduledTime },
      });

      return identifier;
    } catch (error) {
      console.error('Failed to schedule notification:', error);
      throw error;
    }
  }

  /**
   * Schedule daily astrology notifications
   */
  async scheduleDailyNotifications(): Promise<void> {
    try {
      // Cancel existing daily notifications
      await this.cancelNotificationsByType('horoscope');
      await this.cancelNotificationsByType('spiritual');

      // Schedule daily horoscope notification (8 AM)
      await Notifications.scheduleNotificationAsync({
        content: {
          title: '🌟 Seu Horóscopo Diário',
          body: 'Descubra o que os astros reservam para você hoje!',
          data: { type: 'horoscope' },
          sound: 'notification.wav',
        },
        trigger: {
          hour: 8,
          minute: 0,
          repeats: true,
        },
      });

      // Schedule evening spiritual message (8 PM)
      await Notifications.scheduleNotificationAsync({
        content: {
          title: '🔮 Mensagem Espiritual',
          body: 'Uma mensagem especial do seu Orixá protetor te aguarda.',
          data: { type: 'spiritual' },
          sound: 'notification.wav',
        },
        trigger: {
          hour: 20,
          minute: 0,
          repeats: true,
        },
      });

      console.log('Daily notifications scheduled successfully');
    } catch (error) {
      console.error('Failed to schedule daily notifications:', error);
    }
  }

  /**
   * Schedule celestial event notifications
   */
  async scheduleCelestialNotification(
    eventName: string,
    eventTime: Date,
    description: string
  ): Promise<string> {
    const notification: NotificationData = {
      id: `celestial_${Date.now()}`,
      title: `🌙 Evento Celestial: ${eventName}`,
      body: description,
      scheduledTime: eventTime,
      type: 'celestial',
      data: {
        eventName,
        eventTime: eventTime.toISOString(),
      },
    };

    return await this.scheduleNotification(notification);
  }

  /**
   * Send personalized tarot notification
   */
  async sendTarotNotification(message: string): Promise<void> {
    await this.sendLocalNotification({
      id: `tarot_${Date.now()}`,
      title: '🃏 Mensagem do Tarô',
      body: message,
      type: 'tarot',
    });
  }

  /**
   * Cancel notification by identifier
   */
  async cancelNotification(identifier: string): Promise<void> {
    try {
      await Notifications.cancelScheduledNotificationAsync(identifier);
      await this.removeStoredNotification(identifier);
    } catch (error) {
      console.error('Failed to cancel notification:', error);
    }
  }

  /**
   * Cancel all notifications of a specific type
   */
  async cancelNotificationsByType(type: string): Promise<void> {
    try {
      const allNotifications = await Notifications.getAllScheduledNotificationsAsync();
      
      for (const notification of allNotifications) {
        if (notification.content.data?.type === type) {
          await Notifications.cancelScheduledNotificationAsync(notification.identifier);
        }
      }
    } catch (error) {
      console.error('Failed to cancel notifications by type:', error);
    }
  }

  /**
   * Get all scheduled notifications
   */
  async getScheduledNotifications(): Promise<Notifications.NotificationRequest[]> {
    try {
      return await Notifications.getAllScheduledNotificationsAsync();
    } catch (error) {
      console.error('Failed to get scheduled notifications:', error);
      return [];
    }
  }

  /**
   * Get push token for server communication
   */
  getPushToken(): string | null {
    return this.expoPushToken;
  }

  /**
   * Store notification in history
   */
  private async storeNotificationHistory(notification: Notifications.Notification): Promise<void> {
    try {
      const history = await this.getNotificationHistory();
      const newEntry = {
        id: notification.request.identifier,
        title: notification.request.content.title,
        body: notification.request.content.body,
        data: notification.request.content.data,
        receivedAt: new Date().toISOString(),
      };

      history.unshift(newEntry);
      
      // Keep only last 50 notifications
      const trimmedHistory = history.slice(0, 50);
      
      await AsyncStorage.setItem(
        '@UniversoMistico:notificationHistory',
        JSON.stringify(trimmedHistory)
      );
    } catch (error) {
      console.error('Failed to store notification history:', error);
    }
  }

  /**
   * Get notification history
   */
  async getNotificationHistory(): Promise<any[]> {
    try {
      const stored = await AsyncStorage.getItem('@UniversoMistico:notificationHistory');
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Failed to get notification history:', error);
      return [];
    }
  }

  /**
   * Store scheduled notification
   */
  private async storeScheduledNotification(notification: ScheduledNotification): Promise<void> {
    try {
      const stored = await AsyncStorage.getItem('@UniversoMistico:scheduledNotifications');
      const notifications = stored ? JSON.parse(stored) : [];
      
      notifications.push(notification);
      
      await AsyncStorage.setItem(
        '@UniversoMistico:scheduledNotifications',
        JSON.stringify(notifications)
      );
    } catch (error) {
      console.error('Failed to store scheduled notification:', error);
    }
  }

  /**
   * Remove stored notification
   */
  private async removeStoredNotification(identifier: string): Promise<void> {
    try {
      const stored = await AsyncStorage.getItem('@UniversoMistico:scheduledNotifications');
      const notifications = stored ? JSON.parse(stored) : [];
      
      const filtered = notifications.filter((n: ScheduledNotification) => n.identifier !== identifier);
      
      await AsyncStorage.setItem(
        '@UniversoMistico:scheduledNotifications',
        JSON.stringify(filtered)
      );
    } catch (error) {
      console.error('Failed to remove stored notification:', error);
    }
  }

  /**
   * Cleanup listeners
   */
  cleanup(): void {
    if (this.notificationListener) {
      this.notificationListener.remove();
    }
    if (this.responseListener) {
      this.responseListener.remove();
    }
  }
}

export const NotificationService = new NotificationServiceClass();