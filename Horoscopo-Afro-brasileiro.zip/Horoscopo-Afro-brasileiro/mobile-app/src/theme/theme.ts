/**
 * Theme configuration for Universo Místico mobile app
 * Material Design 3 theme with mystical color palette
 */

import { MD3LightTheme, configureFonts } from 'react-native-paper';

const fontConfig = {
  fontFamily: 'Inter-Regular',
};

const fonts = configureFonts({
  config: {
    ...fontConfig,
    displayLarge: {
      ...fontConfig,
      fontFamily: 'Inter-Bold',
      fontSize: 57,
      fontWeight: '400',
      letterSpacing: 0,
      lineHeight: 64,
    },
    displayMedium: {
      ...fontConfig,
      fontFamily: 'Inter-Bold',
      fontSize: 45,
      fontWeight: '400',
      letterSpacing: 0,
      lineHeight: 52,
    },
    displaySmall: {
      ...fontConfig,
      fontFamily: 'Inter-Bold',
      fontSize: 36,
      fontWeight: '400',
      letterSpacing: 0,
      lineHeight: 44,
    },
    headlineLarge: {
      ...fontConfig,
      fontFamily: 'Inter-SemiBold',
      fontSize: 32,
      fontWeight: '400',
      letterSpacing: 0,
      lineHeight: 40,
    },
    headlineMedium: {
      ...fontConfig,
      fontFamily: 'Inter-SemiBold',
      fontSize: 28,
      fontWeight: '400',
      letterSpacing: 0,
      lineHeight: 36,
    },
    headlineSmall: {
      ...fontConfig,
      fontFamily: 'Inter-SemiBold',
      fontSize: 24,
      fontWeight: '400',
      letterSpacing: 0,
      lineHeight: 32,
    },
    titleLarge: {
      ...fontConfig,
      fontFamily: 'Inter-Medium',
      fontSize: 22,
      fontWeight: '400',
      letterSpacing: 0,
      lineHeight: 28,
    },
    titleMedium: {
      ...fontConfig,
      fontFamily: 'Inter-Medium',
      fontSize: 16,
      fontWeight: '500',
      letterSpacing: 0.15,
      lineHeight: 24,
    },
    titleSmall: {
      ...fontConfig,
      fontFamily: 'Inter-Medium',
      fontSize: 14,
      fontWeight: '500',
      letterSpacing: 0.1,
      lineHeight: 20,
    },
    labelLarge: {
      ...fontConfig,
      fontFamily: 'Inter-Medium',
      fontSize: 14,
      fontWeight: '500',
      letterSpacing: 0.1,
      lineHeight: 20,
    },
    labelMedium: {
      ...fontConfig,
      fontFamily: 'Inter-Medium',
      fontSize: 12,
      fontWeight: '500',
      letterSpacing: 0.5,
      lineHeight: 16,
    },
    labelSmall: {
      ...fontConfig,
      fontFamily: 'Inter-Medium',
      fontSize: 11,
      fontWeight: '500',
      letterSpacing: 0.5,
      lineHeight: 16,
    },
    bodyLarge: {
      ...fontConfig,
      fontFamily: 'Inter-Regular',
      fontSize: 16,
      fontWeight: '400',
      letterSpacing: 0.15,
      lineHeight: 24,
    },
    bodyMedium: {
      ...fontConfig,
      fontFamily: 'Inter-Regular',
      fontSize: 14,
      fontWeight: '400',
      letterSpacing: 0.25,
      lineHeight: 20,
    },
    bodySmall: {
      ...fontConfig,
      fontFamily: 'Inter-Regular',
      fontSize: 12,
      fontWeight: '400',
      letterSpacing: 0.4,
      lineHeight: 16,
    },
  },
});

export const mysticalTheme = {
  ...MD3LightTheme,
  fonts,
  colors: {
    ...MD3LightTheme.colors,
    // Primary colors - Purple mystic
    primary: '#8b5cf6',
    onPrimary: '#ffffff',
    primaryContainer: '#f3f0ff',
    onPrimaryContainer: '#2e1065',
    
    // Secondary colors - Indigo celestial
    secondary: '#6366f1',
    onSecondary: '#ffffff',
    secondaryContainer: '#e0e7ff',
    onSecondaryContainer: '#1e1b4b',
    
    // Tertiary colors - Emerald nature
    tertiary: '#10b981',
    onTertiary: '#ffffff',
    tertiaryContainer: '#d1fae5',
    onTertiaryContainer: '#065f46',
    
    // Error colors
    error: '#ef4444',
    onError: '#ffffff',
    errorContainer: '#fef2f2',
    onErrorContainer: '#991b1b',
    
    // Background colors
    background: '#fefbff',
    onBackground: '#1c1b1f',
    
    // Surface colors
    surface: '#ffffff',
    onSurface: '#1c1b1f',
    surfaceVariant: '#f3f0ff',
    onSurfaceVariant: '#49454f',
    
    // Outline colors
    outline: '#79747e',
    outlineVariant: '#cac4d0',
    
    // Inverse colors
    inverseSurface: '#313033',
    inverseOnSurface: '#f4eff4',
    inversePrimary: '#d0bcff',
    
    // Additional mystical colors
    gold: '#f59e0b',
    goldContainer: '#fef3c7',
    onGold: '#92400e',
    
    silver: '#9ca3af',
    silverContainer: '#f3f4f6',
    onSilver: '#374151',
    
    moonlight: '#e5e7eb',
    starlight: '#fbbf24',
    
    // Semantic colors for astrology
    fire: '#f97316', // Aries, Leo, Sagittarius
    earth: '#84cc16', // Taurus, Virgo, Capricorn
    air: '#06b6d4', // Gemini, Libra, Aquarius
    water: '#3b82f6', // Cancer, Scorpio, Pisces
    
    // Chakra colors
    chakraRed: '#dc2626',
    chakraOrange: '#ea580c',
    chakraYellow: '#ca8a04',
    chakraGreen: '#16a34a',
    chakraBlue: '#2563eb',
    chakraIndigo: '#4338ca',
    chakraViolet: '#7c3aed',
  },
  
  // Custom spacing
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
    xxl: 48,
  },
  
  // Custom shadows
  shadows: {
    mystical: {
      shadowColor: '#8b5cf6',
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.15,
      shadowRadius: 12,
      elevation: 8,
    },
    celestial: {
      shadowColor: '#6366f1',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 8,
      elevation: 4,
    },
    soft: {
      shadowColor: '#000000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.05,
      shadowRadius: 4,
      elevation: 2,
    },
  },
  
  // Custom border radius
  borderRadius: {
    xs: 4,
    sm: 8,
    md: 12,
    lg: 16,
    xl: 24,
    full: 9999,
  },
  
  // Animation durations
  animation: {
    fast: 200,
    normal: 300,
    slow: 500,
    slower: 800,
  },
};