/**
 * Home Screen for Universo Místico Mobile App
 * Main dashboard with location-based features and daily content
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  Alert,
  Dimensions,
} from 'react-native';
import {
  Card,
  Title,
  Paragraph,
  Button,
  Chip,
  FAB,
  Portal,
  Dialog,
  ActivityIndicator,
} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useAuth } from '../contexts/AuthContext';
import { useLocation } from '../contexts/LocationContext';
import { useNotification } from '../contexts/NotificationContext';
import { mysticalTheme } from '../theme/theme';

const { width } = Dimensions.get('window');

interface DailyContent {
  horoscope: string;
  spiritualMessage: string;
  moonPhase: string;
  celestialEvents: string[];
}

export default function HomeScreen() {
  const { user } = useAuth();
  const { 
    currentLocation, 
    astrologyData, 
    getCurrentLocation, 
    getAstrologyData,
    findNearbyPoints,
    isLoading: locationLoading 
  } = useLocation();
  const { sendLocalNotification } = useNotification();

  const [refreshing, setRefreshing] = useState(false);
  const [dailyContent, setDailyContent] = useState<DailyContent | null>(null);
  const [nearbyPoints, setNearbyPoints] = useState<any[]>([]);
  const [showLocationDialog, setShowLocationDialog] = useState(false);
  const [loadingContent, setLoadingContent] = useState(true);

  useEffect(() => {
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    try {
      setLoadingContent(true);
      
      // Load location data
      await getCurrentLocation();
      await getAstrologyData();
      
      // Load daily content
      await loadDailyContent();
      
      // Find nearby spiritual points
      const points = await findNearbyPoints(15);
      setNearbyPoints(points);
      
    } catch (error) {
      console.error('Failed to load initial data:', error);
    } finally {
      setLoadingContent(false);
    }
  };

  const loadDailyContent = async () => {
    try {
      // Simulate loading daily content based on user data and location
      const content: DailyContent = {
        horoscope: generateDailyHoroscope(),
        spiritualMessage: generateSpiritualMessage(),
        moonPhase: astrologyData?.moonPhase || 'Lua Crescente',
        celestialEvents: astrologyData?.celestialEvents || ['Energia Solar Dominical'],
      };
      
      setDailyContent(content);
    } catch (error) {
      console.error('Failed to load daily content:', error);
    }
  };

  const generateDailyHoroscope = (): string => {
    const horoscopes = [
      'Hoje é um dia especial para reflexão e conexão espiritual. As energias cósmicas estão alinhadas para trazer clareza aos seus caminhos.',
      'Os astros indicam um período de transformação positiva. Mantenha-se aberto às oportunidades que o universo apresentará.',
      'Sua intuição está aguçada hoje. Confie nos sinais que o cosmos está enviando e siga sua sabedoria interior.',
      'Um dia propício para fortalecer vínculos espirituais e buscar equilíbrio em todas as áreas da vida.',
    ];
    
    return horoscopes[Math.floor(Math.random() * horoscopes.length)];
  };

  const generateSpiritualMessage = (): string => {
    const messages = [
      'Que a luz dos orixás ilumine seu caminho e traga proteção em cada passo que você der.',
      'O universo conspira a seu favor. Mantenha a fé e confie no processo de evolução espiritual.',
      'Suas energias estão em sintonia com as forças cósmicas. Use este momento para manifestar seus desejos.',
      'A sabedoria ancestral sussurra aos seus ouvidos. Escute com o coração e encontre as respostas que busca.',
    ];
    
    return messages[Math.floor(Math.random() * messages.length)];
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadInitialData();
    setRefreshing(false);
  };

  const handleLocationPress = () => {
    if (!currentLocation) {
      setShowLocationDialog(true);
    } else {
      // Show location details
      Alert.alert(
        'Sua Localização',
        `${currentLocation.address || 'Localização atual'}\n${currentLocation.city || ''}, ${currentLocation.country || ''}`,
        [{ text: 'OK' }]
      );
    }
  };

  const requestLocationAccess = async () => {
    try {
      setShowLocationDialog(false);
      const location = await getCurrentLocation();
      
      if (location) {
        await sendLocalNotification({
          id: 'location_success',
          title: '📍 Localização Ativada',
          body: 'Agora você receberá previsões personalizadas baseadas na sua região!',
          type: 'reminder',
        });
      }
    } catch (error) {
      Alert.alert(
        'Erro de Localização',
        'Não foi possível acessar sua localização. Verifique as permissões do app.',
        [{ text: 'OK' }]
      );
    }
  };

  const formatGreeting = (): string => {
    const hour = new Date().getHours();
    const name = user?.name || 'Amigo espiritual';
    
    if (hour < 12) return `Bom dia, ${name}`;
    if (hour < 18) return `Boa tarde, ${name}`;
    return `Boa noite, ${name}`;
  };

  if (loadingContent) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={mysticalTheme.colors.primary} />
        <Text style={styles.loadingText}>Carregando energias cósmicas...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.greeting}>{formatGreeting()}</Text>
          <View style={styles.locationContainer}>
            <Icon name="map-marker" size={16} color={mysticalTheme.colors.primary} />
            <Text 
              style={styles.locationText}
              onPress={handleLocationPress}
            >
              {currentLocation?.city || 'Toque para ativar localização'}
            </Text>
          </View>
        </View>

        {/* Daily Horoscope */}
        <Card style={styles.card}>
          <Card.Content>
            <View style={styles.cardHeader}>
              <Icon name="star-circle" size={24} color={mysticalTheme.colors.primary} />
              <Title style={styles.cardTitle}>Horóscopo do Dia</Title>
            </View>
            <Paragraph style={styles.horoscopeText}>
              {dailyContent?.horoscope}
            </Paragraph>
            <Chip 
              icon="zodiac-leo" 
              style={styles.zodiacChip}
              textStyle={styles.chipText}
            >
              {user?.zodiacSign || 'Seu Signo'}
            </Chip>
          </Card.Content>
        </Card>

        {/* Spiritual Message */}
        <Card style={styles.card}>
          <Card.Content>
            <View style={styles.cardHeader}>
              <Icon name="meditation" size={24} color={mysticalTheme.colors.secondary} />
              <Title style={styles.cardTitle}>Mensagem Espiritual</Title>
            </View>
            <Paragraph style={styles.spiritualText}>
              {dailyContent?.spiritualMessage}
            </Paragraph>
          </Card.Content>
        </Card>

        {/* Celestial Info */}
        <Card style={styles.card}>
          <Card.Content>
            <View style={styles.cardHeader}>
              <Icon name="moon-waning-crescent" size={24} color={mysticalTheme.colors.tertiary} />
              <Title style={styles.cardTitle}>Informações Celestiais</Title>
            </View>
            <View style={styles.celestialInfo}>
              <Chip style={styles.moonChip} textStyle={styles.chipText}>
                🌙 {dailyContent?.moonPhase}
              </Chip>
              {dailyContent?.celestialEvents.map((event, index) => (
                <Chip key={index} style={styles.eventChip} textStyle={styles.chipText}>
                  ✨ {event}
                </Chip>
              ))}
            </View>
          </Card.Content>
        </Card>

        {/* Nearby Spiritual Points */}
        {nearbyPoints.length > 0 && (
          <Card style={styles.card}>
            <Card.Content>
              <View style={styles.cardHeader}>
                <Icon name="map-search" size={24} color={mysticalTheme.colors.primary} />
                <Title style={styles.cardTitle}>Pontos Espirituais Próximos</Title>
              </View>
              {nearbyPoints.slice(0, 3).map((point, index) => (
                <View key={index} style={styles.nearbyPoint}>
                  <Text style={styles.pointName}>{point.name}</Text>
                  <Text style={styles.pointDescription}>{point.description}</Text>
                  <View style={styles.pointServices}>
                    {point.services.slice(0, 2).map((service: string, idx: number) => (
                      <Chip key={idx} style={styles.serviceChip} textStyle={styles.smallChipText}>
                        {service}
                      </Chip>
                    ))}
                  </View>
                </View>
              ))}
              <Button 
                mode="outlined" 
                onPress={() => {/* Navigate to map */}}
                style={styles.viewAllButton}
              >
                Ver Todos no Mapa
              </Button>
            </Card.Content>
          </Card>
        )}

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <Button
            mode="contained"
            icon="cards"
            onPress={() => {/* Navigate to tarot */}}
            style={styles.actionButton}
          >
            Consulta de Tarô
          </Button>
          <Button
            mode="outlined"
            icon="account-star"
            onPress={() => {/* Navigate to spiritual profile */}}
            style={styles.actionButton}
          >
            Perfil Espiritual
          </Button>
        </View>
      </ScrollView>

      {/* Floating Action Button */}
      <FAB
        style={styles.fab}
        icon="plus"
        onPress={() => {
          sendLocalNotification({
            id: 'daily_reminder',
            title: '🌟 Lembrete Espiritual',
            body: 'Hora de uma pausa para conectar-se com sua espiritualidade!',
            type: 'reminder',
          });
        }}
      />

      {/* Location Permission Dialog */}
      <Portal>
        <Dialog visible={showLocationDialog} onDismiss={() => setShowLocationDialog(false)}>
          <Dialog.Title>Ativar Localização</Dialog.Title>
          <Dialog.Content>
            <Paragraph>
              Para receber previsões astrológicas personalizadas baseadas na sua região, 
              precisamos acessar sua localização.
            </Paragraph>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setShowLocationDialog(false)}>Cancelar</Button>
            <Button mode="contained" onPress={requestLocationAccess}>Ativar</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: mysticalTheme.colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: mysticalTheme.colors.background,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: mysticalTheme.colors.onSurface,
  },
  scrollView: {
    flex: 1,
  },
  header: {
    padding: 20,
    backgroundColor: mysticalTheme.colors.primaryContainer,
  },
  greeting: {
    fontSize: 24,
    fontWeight: 'bold',
    color: mysticalTheme.colors.primary,
    marginBottom: 8,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  locationText: {
    marginLeft: 4,
    fontSize: 14,
    color: mysticalTheme.colors.onSurface,
  },
  card: {
    margin: 16,
    elevation: 4,
    borderRadius: 12,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  cardTitle: {
    marginLeft: 8,
    fontSize: 18,
    fontWeight: '600',
  },
  horoscopeText: {
    fontSize: 16,
    lineHeight: 24,
    marginBottom: 12,
    color: mysticalTheme.colors.onSurface,
  },
  spiritualText: {
    fontSize: 16,
    lineHeight: 24,
    fontStyle: 'italic',
    color: mysticalTheme.colors.onSurface,
  },
  zodiacChip: {
    alignSelf: 'flex-start',
    backgroundColor: mysticalTheme.colors.primaryContainer,
  },
  chipText: {
    fontSize: 12,
  },
  smallChipText: {
    fontSize: 10,
  },
  celestialInfo: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  moonChip: {
    backgroundColor: mysticalTheme.colors.tertiaryContainer,
  },
  eventChip: {
    backgroundColor: mysticalTheme.colors.secondaryContainer,
  },
  nearbyPoint: {
    marginBottom: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: mysticalTheme.colors.outline,
  },
  pointName: {
    fontSize: 16,
    fontWeight: '600',
    color: mysticalTheme.colors.onSurface,
    marginBottom: 4,
  },
  pointDescription: {
    fontSize: 14,
    color: mysticalTheme.colors.onSurfaceVariant,
    marginBottom: 8,
  },
  pointServices: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 4,
  },
  serviceChip: {
    backgroundColor: mysticalTheme.colors.surfaceVariant,
  },
  viewAllButton: {
    marginTop: 8,
  },
  quickActions: {
    padding: 16,
    gap: 12,
  },
  actionButton: {
    marginBottom: 8,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 80,
    backgroundColor: mysticalTheme.colors.primary,
  },
});