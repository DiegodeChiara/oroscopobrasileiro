/**
 * Map Screen with geolocation and spiritual points of interest
 * Displays nearby spiritual centers, temples, and astrology-related locations
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Alert,
  Dimensions,
} from 'react-native';
import MapView, { Marker, Callout, Circle, PROVIDER_GOOGLE } from 'react-native-maps';
import {
  Card,
  Title,
  Paragraph,
  Button,
  Chip,
  FAB,
  Portal,
  Modal,
  ActivityIndicator,
} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useLocation } from '../contexts/LocationContext';
import { useNotification } from '../contexts/NotificationContext';
import { mysticalTheme } from '../theme/theme';

const { width, height } = Dimensions.get('window');

interface SpiritualPoint {
  id: number;
  name: string;
  type: 'spiritual_center' | 'temple' | 'store';
  latitude: number;
  longitude: number;
  description: string;
  services: string[];
  rating?: number;
  distance?: number;
}

export default function MapScreen() {
  const { 
    currentLocation, 
    getCurrentLocation, 
    findNearbyPoints,
    isLoading: locationLoading 
  } = useLocation();
  const { scheduleCelestialNotification } = useNotification();

  const mapRef = useRef<MapView>(null);
  const [spiritualPoints, setSpiritualPoints] = useState<SpiritualPoint[]>([]);
  const [selectedPoint, setSelectedPoint] = useState<SpiritualPoint | null>(null);
  const [showPointModal, setShowPointModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [searchRadius, setSearchRadius] = useState(10);

  useEffect(() => {
    initializeMap();
  }, []);

  const initializeMap = async () => {
    try {
      setLoading(true);
      
      // Get current location if not available
      if (!currentLocation) {
        await getCurrentLocation();
      }

      // Load nearby spiritual points
      await loadNearbyPoints();
      
      // Center map on user location
      if (currentLocation && mapRef.current) {
        mapRef.current.animateToRegion({
          latitude: currentLocation.latitude,
          longitude: currentLocation.longitude,
          latitudeDelta: 0.02,
          longitudeDelta: 0.02,
        }, 1000);
      }
    } catch (error) {
      console.error('Failed to initialize map:', error);
      Alert.alert(
        'Erro no Mapa',
        'Não foi possível carregar o mapa. Verifique sua conexão e permissões de localização.',
        [{ text: 'OK' }]
      );
    } finally {
      setLoading(false);
    }
  };

  const loadNearbyPoints = async () => {
    try {
      const points = await findNearbyPoints(searchRadius);
      setSpiritualPoints(points);
    } catch (error) {
      console.error('Failed to load nearby points:', error);
    }
  };

  const handleMarkerPress = (point: SpiritualPoint) => {
    setSelectedPoint(point);
    setShowPointModal(true);
  };

  const getMarkerIcon = (type: string) => {
    switch (type) {
      case 'spiritual_center':
        return 'meditation';
      case 'temple':
        return 'home-heart';
      case 'store':
        return 'store';
      default:
        return 'map-marker';
    }
  };

  const getMarkerColor = (type: string) => {
    switch (type) {
      case 'spiritual_center':
        return mysticalTheme.colors.primary;
      case 'temple':
        return mysticalTheme.colors.secondary;
      case 'store':
        return mysticalTheme.colors.tertiary;
      default:
        return mysticalTheme.colors.outline;
    }
  };

  const handleDirections = (point: SpiritualPoint) => {
    // In a real app, integrate with maps app for directions
    Alert.alert(
      'Direções',
      `Abrir direções para ${point.name}?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        { 
          text: 'Abrir', 
          onPress: () => {
            // Open external maps app
            console.log(`Opening directions to ${point.name}`);
          }
        }
      ]
    );
  };

  const scheduleVisitReminder = async (point: SpiritualPoint) => {
    try {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(10, 0, 0, 0);

      await scheduleCelestialNotification(
        `Visita a ${point.name}`,
        tomorrow,
        `Lembrete para visitar ${point.name} - ${point.description}`
      );

      Alert.alert(
        'Lembrete Agendado',
        `Você receberá uma notificação amanhã às 10h para visitar ${point.name}.`,
        [{ text: 'OK' }]
      );
      
      setShowPointModal(false);
    } catch (error) {
      Alert.alert('Erro', 'Não foi possível agendar o lembrete.');
    }
  };

  const expandSearchRadius = async () => {
    const newRadius = searchRadius + 5;
    setSearchRadius(newRadius);
    setLoading(true);
    
    try {
      const points = await findNearbyPoints(newRadius);
      setSpiritualPoints(points);
    } catch (error) {
      console.error('Failed to expand search:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!currentLocation) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={mysticalTheme.colors.primary} />
        <Text style={styles.loadingText}>Obtendo sua localização...</Text>
        <Button 
          mode="contained" 
          onPress={getCurrentLocation}
          style={styles.retryButton}
        >
          Tentar Novamente
        </Button>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        provider={PROVIDER_GOOGLE}
        style={styles.map}
        initialRegion={{
          latitude: currentLocation.latitude,
          longitude: currentLocation.longitude,
          latitudeDelta: 0.02,
          longitudeDelta: 0.02,
        }}
        showsUserLocation={true}
        showsMyLocationButton={true}
        loadingEnabled={loading}
      >
        {/* Search radius circle */}
        <Circle
          center={{
            latitude: currentLocation.latitude,
            longitude: currentLocation.longitude,
          }}
          radius={searchRadius * 1000} // Convert km to meters
          strokeColor={mysticalTheme.colors.primary}
          strokeWidth={2}
          fillColor={`${mysticalTheme.colors.primaryContainer}40`}
        />

        {/* Spiritual points markers */}
        {spiritualPoints.map((point) => (
          <Marker
            key={point.id}
            coordinate={{
              latitude: point.latitude,
              longitude: point.longitude,
            }}
            onPress={() => handleMarkerPress(point)}
          >
            <View style={[styles.markerContainer, { backgroundColor: getMarkerColor(point.type) }]}>
              <Icon 
                name={getMarkerIcon(point.type)} 
                size={20} 
                color="white" 
              />
            </View>
            <Callout tooltip>
              <View style={styles.callout}>
                <Text style={styles.calloutTitle}>{point.name}</Text>
                <Text style={styles.calloutDescription}>{point.description}</Text>
              </View>
            </Callout>
          </Marker>
        ))}
      </MapView>

      {/* Search radius info */}
      <View style={styles.radiusInfo}>
        <Chip 
          icon="radius" 
          style={styles.radiusChip}
          textStyle={styles.chipText}
        >
          Raio: {searchRadius}km
        </Chip>
        <Text style={styles.pointsCount}>
          {spiritualPoints.length} pontos encontrados
        </Text>
      </View>

      {/* Expand search FAB */}
      <FAB
        style={styles.expandFab}
        icon="magnify-plus-outline"
        onPress={expandSearchRadius}
        disabled={loading}
      />

      {/* Point details modal */}
      <Portal>
        <Modal
          visible={showPointModal}
          onDismiss={() => setShowPointModal(false)}
          contentContainerStyle={styles.modalContainer}
        >
          {selectedPoint && (
            <Card style={styles.modalCard}>
              <Card.Content>
                <View style={styles.modalHeader}>
                  <Icon 
                    name={getMarkerIcon(selectedPoint.type)} 
                    size={32} 
                    color={getMarkerColor(selectedPoint.type)} 
                  />
                  <View style={styles.modalTitleContainer}>
                    <Title style={styles.modalTitle}>{selectedPoint.name}</Title>
                    <Paragraph style={styles.modalType}>
                      {selectedPoint.type === 'spiritual_center' && 'Centro Espiritual'}
                      {selectedPoint.type === 'temple' && 'Templo'}
                      {selectedPoint.type === 'store' && 'Loja Esotérica'}
                    </Paragraph>
                  </View>
                </View>

                <Paragraph style={styles.modalDescription}>
                  {selectedPoint.description}
                </Paragraph>

                <View style={styles.servicesContainer}>
                  <Text style={styles.servicesTitle}>Serviços:</Text>
                  <View style={styles.servicesChips}>
                    {selectedPoint.services.map((service, index) => (
                      <Chip 
                        key={index} 
                        style={styles.serviceChip}
                        textStyle={styles.serviceChipText}
                      >
                        {service}
                      </Chip>
                    ))}
                  </View>
                </View>

                <View style={styles.modalActions}>
                  <Button
                    mode="outlined"
                    icon="directions"
                    onPress={() => handleDirections(selectedPoint)}
                    style={styles.modalButton}
                  >
                    Direções
                  </Button>
                  <Button
                    mode="contained"
                    icon="bell-plus"
                    onPress={() => scheduleVisitReminder(selectedPoint)}
                    style={styles.modalButton}
                  >
                    Lembrete
                  </Button>
                </View>
              </Card.Content>
            </Card>
          )}
        </Modal>
      </Portal>

      {loading && (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator size="large" color={mysticalTheme.colors.primary} />
          <Text style={styles.loadingOverlayText}>Buscando pontos espirituais...</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: mysticalTheme.colors.background,
    padding: 20,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: mysticalTheme.colors.onSurface,
    textAlign: 'center',
  },
  retryButton: {
    marginTop: 20,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  markerContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  callout: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 12,
    minWidth: 150,
    maxWidth: 200,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  calloutTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: mysticalTheme.colors.onSurface,
    marginBottom: 4,
  },
  calloutDescription: {
    fontSize: 12,
    color: mysticalTheme.colors.onSurfaceVariant,
  },
  radiusInfo: {
    position: 'absolute',
    top: 16,
    left: 16,
    right: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  radiusChip: {
    backgroundColor: mysticalTheme.colors.surface,
  },
  chipText: {
    fontSize: 12,
  },
  pointsCount: {
    fontSize: 12,
    color: mysticalTheme.colors.onSurface,
    backgroundColor: mysticalTheme.colors.surface,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  expandFab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 80,
    backgroundColor: mysticalTheme.colors.secondary,
  },
  modalContainer: {
    margin: 20,
  },
  modalCard: {
    borderRadius: 16,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalTitleContainer: {
    marginLeft: 12,
    flex: 1,
  },
  modalTitle: {
    fontSize: 20,
    marginBottom: 4,
  },
  modalType: {
    fontSize: 14,
    color: mysticalTheme.colors.onSurfaceVariant,
  },
  modalDescription: {
    fontSize: 16,
    lineHeight: 24,
    marginBottom: 16,
  },
  servicesContainer: {
    marginBottom: 20,
  },
  servicesTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: mysticalTheme.colors.onSurface,
    marginBottom: 8,
  },
  servicesChips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  serviceChip: {
    backgroundColor: mysticalTheme.colors.primaryContainer,
  },
  serviceChipText: {
    fontSize: 12,
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    gap: 12,
  },
  modalButton: {
    flex: 1,
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingOverlayText: {
    marginTop: 12,
    fontSize: 16,
    color: mysticalTheme.colors.onSurface,
  },
});