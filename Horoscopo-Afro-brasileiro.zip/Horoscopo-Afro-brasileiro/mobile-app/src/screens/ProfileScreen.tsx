/**
 * Profile Screen for mobile app
 * User account management and app settings
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Alert,
} from 'react-native';
import {
  Card,
  Title,
  Paragraph,
  Button,
  List,
  Switch,
  Divider,
  Avatar,
  Chip,
} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useAuth } from '../contexts/AuthContext';
import { useNotification } from '../contexts/NotificationContext';
import { mysticalTheme } from '../theme/theme';

export default function ProfileScreen({ navigation }: any) {
  const { user, logout, isLoading } = useAuth();
  const { isInitialized, pushToken, notificationHistory } = useNotification();
  
  const [notificationsEnabled, setNotificationsEnabled] = useState(isInitialized);
  const [locationEnabled, setLocationEnabled] = useState(true);
  const [dailyReminders, setDailyReminders] = useState(true);

  const handleLogout = () => {
    Alert.alert(
      'Sair',
      'Tem certeza que deseja sair da sua conta?',
      [
        { text: 'Cancelar', style: 'cancel' },
        { 
          text: 'Sair', 
          style: 'destructive',
          onPress: logout 
        }
      ]
    );
  };

  const getInitials = (name: string): string => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .substring(0, 2)
      .toUpperCase();
  };

  const formatJoinDate = (dateString?: string): string => {
    if (!dateString) return 'Recente';
    
    const date = new Date(dateString);
    const months = [
      'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
      'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
    ];
    
    return `${months[date.getMonth()]} ${date.getFullYear()}`;
  };

  return (
    <ScrollView style={styles.container}>
      {/* User Info */}
      <Card style={styles.card}>
        <Card.Content style={styles.userInfo}>
          <Avatar.Text 
            size={80} 
            label={getInitials(user?.name || 'U')}
            style={styles.avatar}
          />
          <View style={styles.userDetails}>
            <Title style={styles.userName}>{user?.name || 'Usuário'}</Title>
            <Paragraph style={styles.userEmail}>{user?.email}</Paragraph>
            <Paragraph style={styles.joinDate}>
              Membro desde {formatJoinDate(user?.createdAt)}
            </Paragraph>
          </View>
        </Card.Content>
      </Card>

      {/* Spiritual Info */}
      <Card style={styles.card}>
        <Card.Content>
          <Title style={styles.cardTitle}>Perfil Espiritual</Title>
          <View style={styles.spiritualInfo}>
            {user?.zodiacSign && (
              <Chip 
                icon="star-circle" 
                style={styles.infoChip}
                textStyle={styles.chipText}
              >
                {user.zodiacSign}
              </Chip>
            )}
            {user?.customOrixa && (
              <Chip 
                icon="meditation" 
                style={styles.infoChip}
                textStyle={styles.chipText}
              >
                {user.customOrixa}
              </Chip>
            )}
            {user?.premiumStatus && (
              <Chip 
                icon="star" 
                style={styles.premiumChip}
                textStyle={styles.chipText}
              >
                Premium
              </Chip>
            )}
          </View>
          <Button
            mode="outlined"
            onPress={() => navigation.navigate('SpiritualProfile')}
            style={styles.editButton}
            icon="pencil"
          >
            Editar Perfil Espiritual
          </Button>
        </Card.Content>
      </Card>

      {/* App Settings */}
      <Card style={styles.card}>
        <Card.Content>
          <Title style={styles.cardTitle}>Configurações</Title>
          
          <List.Item
            title="Notificações"
            description="Receber lembretes e atualizações"
            left={props => <List.Icon {...props} icon="bell" />}
            right={() => (
              <Switch
                value={notificationsEnabled}
                onValueChange={setNotificationsEnabled}
              />
            )}
          />
          
          <Divider />
          
          <List.Item
            title="Localização"
            description="Permitir acesso à localização"
            left={props => <List.Icon {...props} icon="map-marker" />}
            right={() => (
              <Switch
                value={locationEnabled}
                onValueChange={setLocationEnabled}
              />
            )}
          />
          
          <Divider />
          
          <List.Item
            title="Lembretes Diários"
            description="Horóscopo e mensagens espirituais"
            left={props => <List.Icon {...props} icon="calendar" />}
            right={() => (
              <Switch
                value={dailyReminders}
                onValueChange={setDailyReminders}
              />
            )}
          />
        </Card.Content>
      </Card>

      {/* Statistics */}
      <Card style={styles.card}>
        <Card.Content>
          <Title style={styles.cardTitle}>Suas Estatísticas</Title>
          <View style={styles.stats}>
            <View style={styles.statItem}>
              <Icon name="cards" size={24} color={mysticalTheme.colors.primary} />
              <Text style={styles.statNumber}>12</Text>
              <Text style={styles.statLabel}>Consultas de Tarô</Text>
            </View>
            <View style={styles.statItem}>
              <Icon name="star-circle" size={24} color={mysticalTheme.colors.secondary} />
              <Text style={styles.statNumber}>45</Text>
              <Text style={styles.statLabel}>Horóscopos Lidos</Text>
            </View>
            <View style={styles.statItem}>
              <Icon name="bell" size={24} color={mysticalTheme.colors.tertiary} />
              <Text style={styles.statNumber}>{notificationHistory.length}</Text>
              <Text style={styles.statLabel}>Notificações</Text>
            </View>
          </View>
        </Card.Content>
      </Card>

      {/* App Info */}
      <Card style={styles.card}>
        <Card.Content>
          <Title style={styles.cardTitle}>Sobre o App</Title>
          
          <List.Item
            title="Política de Privacidade"
            left={props => <List.Icon {...props} icon="shield-check" />}
            right={props => <List.Icon {...props} icon="chevron-right" />}
            onPress={() => Alert.alert('Info', 'Política de Privacidade')}
          />
          
          <Divider />
          
          <List.Item
            title="Termos de Uso"
            left={props => <List.Icon {...props} icon="file-document" />}
            right={props => <List.Icon {...props} icon="chevron-right" />}
            onPress={() => Alert.alert('Info', 'Termos de Uso')}
          />
          
          <Divider />
          
          <List.Item
            title="Suporte"
            left={props => <List.Icon {...props} icon="help-circle" />}
            right={props => <List.Icon {...props} icon="chevron-right" />}
            onPress={() => Alert.alert('Suporte', 'Entre em contato conosco')}
          />
          
          <Divider />
          
          <List.Item
            title="Versão"
            description="1.0.0"
            left={props => <List.Icon {...props} icon="information" />}
          />
        </Card.Content>
      </Card>

      {/* Logout Button */}
      <Button
        mode="outlined"
        onPress={handleLogout}
        style={styles.logoutButton}
        textColor={mysticalTheme.colors.error}
        icon="logout"
        loading={isLoading}
      >
        Sair da Conta
      </Button>

      <View style={styles.bottomSpacing} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: mysticalTheme.colors.background,
  },
  card: {
    margin: 16,
    borderRadius: 12,
    elevation: 2,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    backgroundColor: mysticalTheme.colors.primary,
    marginRight: 16,
  },
  userDetails: {
    flex: 1,
  },
  userName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: mysticalTheme.colors.onSurface,
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 14,
    color: mysticalTheme.colors.onSurfaceVariant,
    marginBottom: 4,
  },
  joinDate: {
    fontSize: 12,
    color: mysticalTheme.colors.onSurfaceVariant,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
    color: mysticalTheme.colors.onSurface,
  },
  spiritualInfo: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 16,
  },
  infoChip: {
    backgroundColor: mysticalTheme.colors.primaryContainer,
  },
  premiumChip: {
    backgroundColor: mysticalTheme.colors.tertiary,
  },
  chipText: {
    fontSize: 12,
    color: 'white',
  },
  editButton: {
    alignSelf: 'flex-start',
  },
  stats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: mysticalTheme.colors.onSurface,
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: mysticalTheme.colors.onSurfaceVariant,
    textAlign: 'center',
    marginTop: 4,
  },
  logoutButton: {
    margin: 16,
    borderColor: mysticalTheme.colors.error,
  },
  bottomSpacing: {
    height: 80,
  },
});