/**
 * Spiritual Profile Screen for mobile app
 * Mobile version of the spiritual profile functionality
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Alert,
} from 'react-native';
import {
  Card,
  Title,
  Paragraph,
  Button,
  Chip,
  TextInput,
  RadioButton,
  ActivityIndicator,
} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useAuth } from '../contexts/AuthContext';
import { mysticalTheme } from '../theme/theme';

const ZODIAC_SIGNS = [
  'Áries', 'Touro', 'Gêmeos', 'Câncer', 'Leão', 'Virgem',
  'Libra', 'Escorpião', 'Sagitário', 'Capricórnio', 'Aquário', 'Peixes'
];

const ORIXAS = [
  'Exú', 'Iemanjá', 'Oxalá', 'Iansã', 'Xangô', 'Oxóssi', 'Ogum'
];

export default function SpiritualProfileScreen() {
  const { user, updateProfile, isLoading } = useAuth();
  const [profileData, setProfileData] = useState({
    birthDate: '',
    birthTime: '',
    birthLocation: '',
    zodiacSign: '',
    customOrixa: '',
  });
  const [orixaSelectionMode, setOrixaSelectionMode] = useState<'automatic' | 'manual'>('automatic');
  const [calculatedZodiac, setCalculatedZodiac] = useState('');
  const [calculatedOrixa, setCalculatedOrixa] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (user) {
      setProfileData({
        birthDate: user.birthDate || '',
        birthTime: user.birthTime || '',
        birthLocation: user.birthLocation || '',
        zodiacSign: user.zodiacSign || '',
        customOrixa: user.customOrixa || '',
      });
    }
  }, [user]);

  const calculateZodiacSign = (birthDate: string): string => {
    if (!birthDate) return '';
    
    const date = new Date(birthDate);
    const month = date.getMonth() + 1;
    const day = date.getDate();

    if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) return 'Áries';
    if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) return 'Touro';
    if ((month === 5 && day >= 21) || (month === 6 && day <= 20)) return 'Gêmeos';
    if ((month === 6 && day >= 21) || (month === 7 && day <= 22)) return 'Câncer';
    if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) return 'Leão';
    if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) return 'Virgem';
    if ((month === 9 && day >= 23) || (month === 10 && day <= 22)) return 'Libra';
    if ((month === 10 && day >= 23) || (month === 11 && day <= 21)) return 'Escorpião';
    if ((month === 11 && day >= 22) || (month === 12 && day <= 21)) return 'Sagitário';
    if ((month === 12 && day >= 22) || (month === 1 && day <= 19)) return 'Capricórnio';
    if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) return 'Aquário';
    if ((month === 2 && day >= 19) || (month === 3 && day <= 20)) return 'Peixes';
    
    return '';
  };

  const getOrixaByZodiac = (zodiacSign: string): string => {
    const orixaMapping: { [key: string]: string } = {
      'Áries': 'Ogum',
      'Touro': 'Oxóssi',
      'Gêmeos': 'Exú',
      'Câncer': 'Iemanjá',
      'Leão': 'Xangô',
      'Virgem': 'Oxóssi',
      'Libra': 'Oxalá',
      'Escorpião': 'Iansã',
      'Sagitário': 'Xangô',
      'Capricórnio': 'Ogum',
      'Aquário': 'Iemanjá',
      'Peixes': 'Oxalá',
    };
    
    return orixaMapping[zodiacSign] || '';
  };

  const handleBirthDateChange = (date: string) => {
    setProfileData({ ...profileData, birthDate: date });
    
    if (date) {
      const zodiac = calculateZodiacSign(date);
      setCalculatedZodiac(zodiac);
      
      if (orixaSelectionMode === 'automatic') {
        const orixa = getOrixaByZodiac(zodiac);
        setCalculatedOrixa(orixa);
      }
    }
  };

  const handleSaveProfile = async () => {
    if (!profileData.birthDate) {
      Alert.alert('Erro', 'Por favor, preencha sua data de nascimento.');
      return;
    }

    try {
      setSaving(true);
      
      const updates = {
        ...profileData,
        zodiacSign: calculatedZodiac,
        customOrixa: orixaSelectionMode === 'automatic' ? calculatedOrixa : profileData.customOrixa,
      };

      await updateProfile(updates);
      
      Alert.alert(
        'Sucesso',
        'Seu perfil espiritual foi atualizado com sucesso!',
        [{ text: 'OK' }]
      );
    } catch (error) {
      Alert.alert('Erro', 'Não foi possível salvar seu perfil.');
    } finally {
      setSaving(false);
    }
  };

  const getOrixaDescription = (orixa: string): string => {
    const descriptions: { [key: string]: string } = {
      'Exú': 'Guardião dos caminhos e da comunicação',
      'Iemanjá': 'Rainha do mar e mãe universal',
      'Oxalá': 'Pai supremo da criação e da paz',
      'Iansã': 'Senhora dos ventos e das tempestades',
      'Xangô': 'Rei do fogo e da justiça',
      'Oxóssi': 'Caçador divino da floresta',
      'Ogum': 'Guerreiro protetor dos caminhos',
    };
    
    return descriptions[orixa] || '';
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Icon name="account-star" size={48} color={mysticalTheme.colors.primary} />
        <Title style={styles.title}>Perfil Espiritual</Title>
        <Paragraph style={styles.subtitle}>
          Configure suas informações astrológicas e espirituais
        </Paragraph>
      </View>

      {/* Birth Information */}
      <Card style={styles.card}>
        <Card.Content>
          <Title style={styles.cardTitle}>Informações de Nascimento</Title>
          
          <TextInput
            label="Data de nascimento"
            value={profileData.birthDate}
            onChangeText={handleBirthDateChange}
            style={styles.input}
            mode="outlined"
            placeholder="DD/MM/AAAA"
            left={<TextInput.Icon icon="calendar" />}
          />
          
          <TextInput
            label="Horário de nascimento (opcional)"
            value={profileData.birthTime}
            onChangeText={(text) => setProfileData({ ...profileData, birthTime: text })}
            style={styles.input}
            mode="outlined"
            placeholder="HH:MM"
            left={<TextInput.Icon icon="clock" />}
          />
          
          <TextInput
            label="Local de nascimento"
            value={profileData.birthLocation}
            onChangeText={(text) => setProfileData({ ...profileData, birthLocation: text })}
            style={styles.input}
            mode="outlined"
            placeholder="Cidade, Estado"
            left={<TextInput.Icon icon="map-marker" />}
          />
        </Card.Content>
      </Card>

      {/* Zodiac Sign */}
      {calculatedZodiac && (
        <Card style={styles.card}>
          <Card.Content>
            <Title style={styles.cardTitle}>Seu Signo</Title>
            <View style={styles.zodiacContainer}>
              <Chip 
                icon="star-circle" 
                style={styles.zodiacChip}
                textStyle={styles.chipText}
              >
                {calculatedZodiac}
              </Chip>
              <Paragraph style={styles.zodiacDescription}>
                Calculado automaticamente baseado na sua data de nascimento
              </Paragraph>
            </View>
          </Card.Content>
        </Card>
      )}

      {/* Orixá Selection */}
      <Card style={styles.card}>
        <Card.Content>
          <Title style={styles.cardTitle}>Seu Orixá Protetor</Title>
          
          <View style={styles.radioGroup}>
            <View style={styles.radioOption}>
              <RadioButton
                value="automatic"
                status={orixaSelectionMode === 'automatic' ? 'checked' : 'unchecked'}
                onPress={() => setOrixaSelectionMode('automatic')}
              />
              <Text style={styles.radioLabel}>Seleção automática por signo</Text>
            </View>
            
            <View style={styles.radioOption}>
              <RadioButton
                value="manual"
                status={orixaSelectionMode === 'manual' ? 'checked' : 'unchecked'}
                onPress={() => setOrixaSelectionMode('manual')}
              />
              <Text style={styles.radioLabel}>Escolher manualmente</Text>
            </View>
          </View>

          {orixaSelectionMode === 'automatic' && calculatedOrixa && (
            <View style={styles.orixaResult}>
              <Chip 
                icon="meditation" 
                style={styles.orixaChip}
                textStyle={styles.chipText}
              >
                {calculatedOrixa}
              </Chip>
              <Paragraph style={styles.orixaDescription}>
                {getOrixaDescription(calculatedOrixa)}
              </Paragraph>
            </View>
          )}

          {orixaSelectionMode === 'manual' && (
            <View style={styles.orixaSelection}>
              <Text style={styles.selectionLabel}>Escolha seu Orixá:</Text>
              <View style={styles.orixaChips}>
                {ORIXAS.map((orixa) => (
                  <Chip
                    key={orixa}
                    selected={profileData.customOrixa === orixa}
                    onPress={() => setProfileData({ ...profileData, customOrixa: orixa })}
                    style={[
                      styles.selectableChip,
                      profileData.customOrixa === orixa && styles.selectedChip
                    ]}
                    textStyle={styles.chipText}
                  >
                    {orixa}
                  </Chip>
                ))}
              </View>
              
              {profileData.customOrixa && (
                <Paragraph style={styles.selectedOrixaDescription}>
                  {getOrixaDescription(profileData.customOrixa)}
                </Paragraph>
              )}
            </View>
          )}
        </Card.Content>
      </Card>

      {/* Save Button */}
      <Button
        mode="contained"
        onPress={handleSaveProfile}
        style={styles.saveButton}
        disabled={saving || !profileData.birthDate}
        loading={saving}
      >
        Salvar Perfil Espiritual
      </Button>

      <View style={styles.bottomSpacing} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: mysticalTheme.colors.background,
  },
  header: {
    alignItems: 'center',
    padding: 24,
    backgroundColor: mysticalTheme.colors.primaryContainer,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: mysticalTheme.colors.primary,
    marginTop: 12,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: mysticalTheme.colors.onSurfaceVariant,
    textAlign: 'center',
  },
  card: {
    margin: 16,
    borderRadius: 12,
    elevation: 2,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
    color: mysticalTheme.colors.onSurface,
  },
  input: {
    marginBottom: 16,
  },
  zodiacContainer: {
    alignItems: 'center',
  },
  zodiacChip: {
    backgroundColor: mysticalTheme.colors.primaryContainer,
    marginBottom: 12,
  },
  zodiacDescription: {
    fontSize: 14,
    color: mysticalTheme.colors.onSurfaceVariant,
    textAlign: 'center',
  },
  radioGroup: {
    marginBottom: 16,
  },
  radioOption: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  radioLabel: {
    marginLeft: 8,
    fontSize: 16,
    color: mysticalTheme.colors.onSurface,
  },
  orixaResult: {
    alignItems: 'center',
    marginTop: 16,
  },
  orixaChip: {
    backgroundColor: mysticalTheme.colors.secondaryContainer,
    marginBottom: 12,
  },
  orixaDescription: {
    fontSize: 14,
    color: mysticalTheme.colors.onSurfaceVariant,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  orixaSelection: {
    marginTop: 16,
  },
  selectionLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: mysticalTheme.colors.onSurface,
    marginBottom: 12,
  },
  orixaChips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 16,
  },
  selectableChip: {
    backgroundColor: mysticalTheme.colors.surfaceVariant,
  },
  selectedChip: {
    backgroundColor: mysticalTheme.colors.secondaryContainer,
  },
  selectedOrixaDescription: {
    fontSize: 14,
    color: mysticalTheme.colors.onSurfaceVariant,
    fontStyle: 'italic',
    textAlign: 'center',
  },
  chipText: {
    fontSize: 12,
  },
  saveButton: {
    margin: 16,
    paddingVertical: 4,
  },
  bottomSpacing: {
    height: 80,
  },
});