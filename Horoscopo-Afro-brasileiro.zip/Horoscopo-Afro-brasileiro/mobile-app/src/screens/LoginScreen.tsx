/**
 * Login Screen for mobile app authentication
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import {
  TextInput,
  Button,
  Card,
  Title,
  Paragraph,
  Divider,
  ActivityIndicator,
} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useAuth } from '../contexts/AuthContext';
import { mysticalTheme } from '../theme/theme';

export default function LoginScreen({ navigation }: any) {
  const { login, register, isLoading } = useAuth();
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    confirmPassword: '',
  });

  const handleLogin = async () => {
    if (!formData.email || !formData.password) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos.');
      return;
    }

    try {
      await login(formData.email, formData.password);
    } catch (error) {
      Alert.alert('Erro de Login', 'Email ou senha incorretos.');
    }
  };

  const handleRegister = async () => {
    if (!formData.email || !formData.password || !formData.name) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos.');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      Alert.alert('Erro', 'As senhas não coincidem.');
      return;
    }

    try {
      await register({
        email: formData.email,
        password: formData.password,
        name: formData.name,
      });
    } catch (error) {
      Alert.alert('Erro de Cadastro', 'Não foi possível criar sua conta.');
    }
  };

  const toggleMode = () => {
    setIsRegisterMode(!isRegisterMode);
    setFormData({
      email: '',
      password: '',
      name: '',
      confirmPassword: '',
    });
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.header}>
          <Text style={styles.logo}>🔮</Text>
          <Title style={styles.title}>Universo Místico</Title>
          <Paragraph style={styles.subtitle}>
            {isRegisterMode 
              ? 'Crie sua conta e conecte-se ao cosmos'
              : 'Entre e explore seu universo espiritual'
            }
          </Paragraph>
        </View>

        <Card style={styles.card}>
          <Card.Content style={styles.cardContent}>
            {isRegisterMode && (
              <TextInput
                label="Nome completo"
                value={formData.name}
                onChangeText={(text) => setFormData({ ...formData, name: text })}
                style={styles.input}
                mode="outlined"
                left={<TextInput.Icon icon="account" />}
                disabled={isLoading}
              />
            )}

            <TextInput
              label="Email"
              value={formData.email}
              onChangeText={(text) => setFormData({ ...formData, email: text })}
              style={styles.input}
              mode="outlined"
              keyboardType="email-address"
              autoCapitalize="none"
              left={<TextInput.Icon icon="email" />}
              disabled={isLoading}
            />

            <TextInput
              label="Senha"
              value={formData.password}
              onChangeText={(text) => setFormData({ ...formData, password: text })}
              style={styles.input}
              mode="outlined"
              secureTextEntry
              left={<TextInput.Icon icon="lock" />}
              disabled={isLoading}
            />

            {isRegisterMode && (
              <TextInput
                label="Confirmar senha"
                value={formData.confirmPassword}
                onChangeText={(text) => setFormData({ ...formData, confirmPassword: text })}
                style={styles.input}
                mode="outlined"
                secureTextEntry
                left={<TextInput.Icon icon="lock-check" />}
                disabled={isLoading}
              />
            )}

            <Button
              mode="contained"
              onPress={isRegisterMode ? handleRegister : handleLogin}
              style={styles.submitButton}
              disabled={isLoading}
              loading={isLoading}
            >
              {isRegisterMode ? 'Criar Conta' : 'Entrar'}
            </Button>

            <Divider style={styles.divider} />

            <Button
              mode="text"
              onPress={toggleMode}
              style={styles.toggleButton}
              disabled={isLoading}
            >
              {isRegisterMode 
                ? 'Já tem uma conta? Fazer login'
                : 'Não tem uma conta? Cadastre-se'
              }
            </Button>
          </Card.Content>
        </Card>

        <View style={styles.features}>
          <Text style={styles.featuresTitle}>Descubra seu universo:</Text>
          <View style={styles.feature}>
            <Icon name="star-circle" size={20} color={mysticalTheme.colors.primary} />
            <Text style={styles.featureText}>Horóscopo personalizado diário</Text>
          </View>
          <View style={styles.feature}>
            <Icon name="cards" size={20} color={mysticalTheme.colors.secondary} />
            <Text style={styles.featureText}>Consultas de tarô ilimitadas</Text>
          </View>
          <View style={styles.feature}>
            <Icon name="map-marker" size={20} color={mysticalTheme.colors.tertiary} />
            <Text style={styles.featureText}>Pontos espirituais próximos</Text>
          </View>
          <View style={styles.feature}>
            <Icon name="bell" size={20} color={mysticalTheme.colors.primary} />
            <Text style={styles.featureText}>Notificações celestiais</Text>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: mysticalTheme.colors.background,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 32,
  },
  logo: {
    fontSize: 60,
    marginBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: mysticalTheme.colors.primary,
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: mysticalTheme.colors.onSurfaceVariant,
    textAlign: 'center',
    marginHorizontal: 20,
  },
  card: {
    borderRadius: 16,
    elevation: 4,
    marginBottom: 24,
  },
  cardContent: {
    padding: 24,
  },
  input: {
    marginBottom: 16,
  },
  submitButton: {
    marginTop: 8,
    marginBottom: 16,
    paddingVertical: 4,
  },
  divider: {
    marginVertical: 16,
  },
  toggleButton: {
    marginTop: 8,
  },
  features: {
    backgroundColor: mysticalTheme.colors.surfaceVariant,
    borderRadius: 12,
    padding: 20,
  },
  featuresTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: mysticalTheme.colors.onSurface,
    marginBottom: 16,
    textAlign: 'center',
  },
  feature: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  featureText: {
    marginLeft: 12,
    fontSize: 14,
    color: mysticalTheme.colors.onSurface,
  },
});