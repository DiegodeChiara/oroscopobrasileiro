/**
 * Tarot Screen for mobile app
 * Interactive tarot card readings with animations
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Animated,
  TouchableOpacity,
  Dimensions,
  Alert,
} from 'react-native';
import {
  Card,
  Title,
  Paragraph,
  Button,
  Chip,
  ActivityIndicator,
  Modal,
  Portal,
} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useAuth } from '../contexts/AuthContext';
import { useNotification } from '../contexts/NotificationContext';
import { mysticalTheme } from '../theme/theme';

const { width, height } = Dimensions.get('window');
const CARD_WIDTH = width * 0.25;
const CARD_HEIGHT = CARD_WIDTH * 1.6;

interface TarotCard {
  id: number;
  name: string;
  suit: string;
  meaning: string;
  reversed: boolean;
  image: string;
}

const TAROT_CARDS: TarotCard[] = [
  { id: 1, name: 'O Louco', suit: 'Arcanos Maiores', meaning: 'Novos começos, espontaneidade, inocência', reversed: false, image: '🃏' },
  { id: 2, name: 'O Mago', suit: 'Arcanos Maiores', meaning: 'Manifestação, poder pessoal, ação', reversed: false, image: '🎩' },
  { id: 3, name: 'A Sacerdotisa', suit: 'Arcanos Maiores', meaning: 'Intuição, mistério, sabedoria interior', reversed: false, image: '🔮' },
  { id: 4, name: 'A Imperatriz', suit: 'Arcanos Maiores', meaning: 'Fertilidade, criatividade, abundância', reversed: false, image: '👑' },
  { id: 5, name: 'O Imperador', suit: 'Arcanos Maiores', meaning: 'Autoridade, estrutura, controle', reversed: false, image: '⚔️' },
  { id: 6, name: 'O Hierofante', suit: 'Arcanos Maiores', meaning: 'Tradição, conformidade, moralidade', reversed: false, image: '🏛️' },
  { id: 7, name: 'Os Amantes', suit: 'Arcanos Maiores', meaning: 'Amor, harmonia, relacionamentos', reversed: false, image: '💕' },
  { id: 8, name: 'O Carro', suit: 'Arcanos Maiores', meaning: 'Controle, determinação, direção', reversed: false, image: '🏇' },
  { id: 9, name: 'A Força', suit: 'Arcanos Maiores', meaning: 'Força interior, coragem, paciência', reversed: false, image: '🦁' },
  { id: 10, name: 'O Ermitão', suit: 'Arcanos Maiores', meaning: 'Introspecção, busca interior, orientação', reversed: false, image: '🕯️' },
];

export default function TarotScreen() {
  const { user } = useAuth();
  const { sendTarotNotification } = useNotification();
  
  const [selectedCards, setSelectedCards] = useState<TarotCard[]>([]);
  const [availableCards, setAvailableCards] = useState<TarotCard[]>([]);
  const [reading, setReading] = useState<string>('');
  const [isDrawing, setIsDrawing] = useState(false);
  const [showReading, setShowReading] = useState(false);
  const [cardAnimations, setCardAnimations] = useState<Animated.Value[]>([]);
  const [readingType, setReadingType] = useState<'single' | 'three' | 'celtic'>('three');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    initializeCards();
  }, []);

  const initializeCards = () => {
    const shuffledCards = [...TAROT_CARDS]
      .sort(() => Math.random() - 0.5)
      .map(card => ({
        ...card,
        reversed: Math.random() > 0.7, // 30% chance of reversed
      }));
    
    setAvailableCards(shuffledCards);
    setCardAnimations(shuffledCards.map(() => new Animated.Value(0)));
  };

  const drawCards = async () => {
    if (isDrawing) return;
    
    setIsDrawing(true);
    setIsLoading(true);
    setSelectedCards([]);
    setReading('');
    setShowReading(false);

    const numberOfCards = readingType === 'single' ? 1 : readingType === 'three' ? 3 : 5;
    const drawnCards = availableCards.slice(0, numberOfCards);
    
    // Animate cards being drawn
    for (let i = 0; i < numberOfCards; i++) {
      setTimeout(() => {
        Animated.spring(cardAnimations[i], {
          toValue: 1,
          tension: 100,
          friction: 8,
          useNativeDriver: true,
        }).start();
        
        setSelectedCards(prev => [...prev, drawnCards[i]]);
      }, i * 500);
    }

    // Generate reading after all cards are drawn
    setTimeout(() => {
      generateReading(drawnCards);
      setIsDrawing(false);
      setIsLoading(false);
    }, numberOfCards * 500 + 1000);
  };

  const generateReading = (cards: TarotCard[]) => {
    let interpretation = '';
    
    if (readingType === 'single') {
      const card = cards[0];
      interpretation = `${card.name} ${card.reversed ? '(Invertida)' : ''}\n\n`;
      interpretation += `${card.meaning}\n\n`;
      interpretation += card.reversed 
        ? 'Em posição invertida, esta carta sugere obstáculos ou a necessidade de olhar para dentro de si mesmo.'
        : 'Esta carta indica um momento favorável para seguir em frente com confiança.';
    } else if (readingType === 'three') {
      interpretation = 'Leitura de Três Cartas - Passado, Presente e Futuro:\n\n';
      cards.forEach((card, index) => {
        const position = ['Passado', 'Presente', 'Futuro'][index];
        interpretation += `${position}: ${card.name} ${card.reversed ? '(Invertida)' : ''}\n`;
        interpretation += `${card.meaning}\n\n`;
      });
      interpretation += 'As cartas revelam uma jornada de transformação e crescimento espiritual.';
    } else {
      interpretation = 'Leitura Celta - Situação Complexa:\n\n';
      const positions = ['Situação Atual', 'Desafio', 'Passado Distante', 'Futuro Possível', 'Coroa'];
      cards.forEach((card, index) => {
        interpretation += `${positions[index]}: ${card.name} ${card.reversed ? '(Invertida)' : ''}\n`;
        interpretation += `${card.meaning}\n\n`;
      });
    }

    setReading(interpretation);
    setShowReading(true);

    // Send notification about the reading
    sendTarotNotification(`Sua consulta de tarô foi concluída! ${cards.length} carta(s) revelaram insights importantes.`);
  };

  const resetReading = () => {
    setSelectedCards([]);
    setReading('');
    setShowReading(false);
    setCardAnimations(cardAnimations.map(() => new Animated.Value(0)));
    initializeCards();
  };

  const renderCard = (card: TarotCard, index: number) => {
    const animatedStyle = {
      transform: [
        {
          scale: cardAnimations[index]?.interpolate({
            inputRange: [0, 1],
            outputRange: [0.8, 1],
          }) || 1,
        },
        {
          rotateY: card.reversed 
            ? cardAnimations[index]?.interpolate({
                inputRange: [0, 1],
                outputRange: ['0deg', '180deg'],
              }) || '0deg'
            : '0deg',
        },
      ],
      opacity: cardAnimations[index] || 1,
    };

    return (
      <Animated.View key={card.id} style={[styles.cardContainer, animatedStyle]}>
        <Card style={[styles.tarotCard, card.reversed && styles.reversedCard]}>
          <Card.Content style={styles.cardContent}>
            <Text style={styles.cardImage}>{card.image}</Text>
            <Text style={styles.cardName}>{card.name}</Text>
            <Text style={styles.cardSuit}>{card.suit}</Text>
            {card.reversed && (
              <Chip style={styles.reversedChip} textStyle={styles.chipText}>
                Invertida
              </Chip>
            )}
          </Card.Content>
        </Card>
      </Animated.View>
    );
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Icon name="cards" size={48} color={mysticalTheme.colors.primary} />
        <Title style={styles.title}>Consulta de Tarô</Title>
        <Paragraph style={styles.subtitle}>
          Deixe as cartas revelarem os mistérios do seu caminho
        </Paragraph>
      </View>

      {/* Reading Type Selection */}
      <Card style={styles.card}>
        <Card.Content>
          <Title style={styles.cardTitle}>Tipo de Leitura</Title>
          <View style={styles.readingTypes}>
            <TouchableOpacity
              style={[styles.typeButton, readingType === 'single' && styles.selectedType]}
              onPress={() => setReadingType('single')}
              disabled={isDrawing}
            >
              <Text style={styles.typeText}>Uma Carta</Text>
              <Text style={styles.typeDescription}>Resposta rápida</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.typeButton, readingType === 'three' && styles.selectedType]}
              onPress={() => setReadingType('three')}
              disabled={isDrawing}
            >
              <Text style={styles.typeText}>Três Cartas</Text>
              <Text style={styles.typeDescription}>Passado, presente, futuro</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.typeButton, readingType === 'celtic' && styles.selectedType]}
              onPress={() => setReadingType('celtic')}
              disabled={isDrawing}
            >
              <Text style={styles.typeText}>Cruz Celta</Text>
              <Text style={styles.typeDescription}>Leitura completa</Text>
            </TouchableOpacity>
          </View>
        </Card.Content>
      </Card>

      {/* Draw Cards Button */}
      <Button
        mode="contained"
        onPress={drawCards}
        style={styles.drawButton}
        disabled={isDrawing}
        loading={isLoading}
      >
        {isDrawing ? 'Revelando as cartas...' : 'Sortear Cartas'}
      </Button>

      {/* Selected Cards */}
      {selectedCards.length > 0 && (
        <View style={styles.cardsSection}>
          <Title style={styles.sectionTitle}>Suas Cartas</Title>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.cardsScroll}>
            {selectedCards.map((card, index) => renderCard(card, index))}
          </ScrollView>
        </View>
      )}

      {/* Reading Results */}
      {showReading && (
        <Card style={styles.card}>
          <Card.Content>
            <Title style={styles.cardTitle}>Interpretação</Title>
            <Paragraph style={styles.reading}>{reading}</Paragraph>
            
            <View style={styles.readingActions}>
              <Button
                mode="outlined"
                onPress={resetReading}
                style={styles.actionButton}
                icon="refresh"
              >
                Nova Consulta
              </Button>
              <Button
                mode="contained"
                onPress={() => Alert.alert('Salvo', 'Leitura salva no seu histórico!')}
                style={styles.actionButton}
                icon="content-save"
              >
                Salvar
              </Button>
            </View>
          </Card.Content>
        </Card>
      )}

      {/* Daily Card */}
      <Card style={styles.card}>
        <Card.Content>
          <View style={styles.dailyCardHeader}>
            <Icon name="calendar-today" size={24} color={mysticalTheme.colors.secondary} />
            <Title style={styles.cardTitle}>Carta do Dia</Title>
          </View>
          <Paragraph style={styles.dailyCardText}>
            Receba uma carta especial todo dia para guiar suas energias
          </Paragraph>
          <Button
            mode="outlined"
            onPress={() => {
              const dailyCard = availableCards[0];
              Alert.alert(
                'Carta do Dia',
                `${dailyCard.name}\n\n${dailyCard.meaning}`,
                [{ text: 'OK' }]
              );
            }}
            style={styles.dailyButton}
          >
            Revelar Carta do Dia
          </Button>
        </Card.Content>
      </Card>

      <View style={styles.bottomSpacing} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: mysticalTheme.colors.background,
  },
  header: {
    alignItems: 'center',
    padding: 24,
    backgroundColor: mysticalTheme.colors.primaryContainer,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: mysticalTheme.colors.primary,
    marginTop: 12,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: mysticalTheme.colors.onSurfaceVariant,
    textAlign: 'center',
  },
  card: {
    margin: 16,
    borderRadius: 12,
    elevation: 2,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
    color: mysticalTheme.colors.onSurface,
  },
  readingTypes: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 8,
  },
  typeButton: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    backgroundColor: mysticalTheme.colors.surfaceVariant,
    alignItems: 'center',
  },
  selectedType: {
    backgroundColor: mysticalTheme.colors.primaryContainer,
  },
  typeText: {
    fontSize: 14,
    fontWeight: '600',
    color: mysticalTheme.colors.onSurface,
  },
  typeDescription: {
    fontSize: 12,
    color: mysticalTheme.colors.onSurfaceVariant,
    marginTop: 4,
    textAlign: 'center',
  },
  drawButton: {
    margin: 16,
    paddingVertical: 4,
  },
  cardsSection: {
    marginVertical: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: mysticalTheme.colors.onSurface,
    marginHorizontal: 16,
    marginBottom: 12,
  },
  cardsScroll: {
    paddingHorizontal: 16,
  },
  cardContainer: {
    marginRight: 12,
  },
  tarotCard: {
    width: CARD_WIDTH,
    height: CARD_HEIGHT,
    borderRadius: 8,
    elevation: 4,
  },
  reversedCard: {
    backgroundColor: mysticalTheme.colors.errorContainer,
  },
  cardContent: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 8,
  },
  cardImage: {
    fontSize: 32,
    marginBottom: 8,
  },
  cardName: {
    fontSize: 12,
    fontWeight: 'bold',
    textAlign: 'center',
    color: mysticalTheme.colors.onSurface,
    marginBottom: 4,
  },
  cardSuit: {
    fontSize: 10,
    color: mysticalTheme.colors.onSurfaceVariant,
    textAlign: 'center',
  },
  reversedChip: {
    marginTop: 8,
    backgroundColor: mysticalTheme.colors.error,
  },
  chipText: {
    fontSize: 10,
    color: 'white',
  },
  reading: {
    fontSize: 16,
    lineHeight: 24,
    color: mysticalTheme.colors.onSurface,
    marginBottom: 20,
  },
  readingActions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    gap: 12,
  },
  actionButton: {
    flex: 1,
  },
  dailyCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  dailyCardText: {
    fontSize: 14,
    color: mysticalTheme.colors.onSurfaceVariant,
    marginBottom: 16,
  },
  dailyButton: {
    alignSelf: 'flex-start',
  },
  bottomSpacing: {
    height: 80,
  },
});