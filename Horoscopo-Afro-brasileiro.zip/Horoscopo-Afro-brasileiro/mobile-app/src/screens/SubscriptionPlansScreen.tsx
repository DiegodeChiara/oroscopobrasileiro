/**
 * Subscription Plans Screen
 * Premium subscription management with Google Play Billing integration
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import {
  Card,
  Title,
  Paragraph,
  Button,
  Chip,
  List,
  Badge,
  ActivityIndicator,
  Surface,
} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useSubscription } from '../contexts/SubscriptionContext';
import { mysticalTheme } from '../theme/theme';
import { SubscriptionPlan } from '../services/BillingService';

const { width } = Dimensions.get('window');

interface PlanCardProps {
  plan: SubscriptionPlan;
  isCurrentPlan: boolean;
  onSelect: () => void;
  isLoading: boolean;
}

function PlanCard({ plan, isCurrentPlan, onSelect, isLoading }: PlanCardProps) {
  const isPopular = plan.productId === 'premium_anual';
  
  return (
    <TouchableOpacity onPress={onSelect} disabled={isCurrentPlan || isLoading}>
      <Card style={[
        styles.planCard,
        isCurrentPlan && styles.currentPlanCard,
        isPopular && styles.popularPlanCard
      ]}>
        {isPopular && (
          <View style={styles.popularBadge}>
            <Badge style={styles.popularBadgeText}>Mais Popular</Badge>
          </View>
        )}
        
        <Card.Content style={styles.planContent}>
          <View style={styles.planHeader}>
            <Title style={[
              styles.planTitle,
              isCurrentPlan && styles.currentPlanTitle
            ]}>
              {plan.title}
            </Title>
            {plan.duration === 'yearly' && (
              <Chip style={styles.discountChip} textStyle={styles.discountText}>
                Economize R$ 11,90
              </Chip>
            )}
          </View>
          
          <View style={styles.priceContainer}>
            <Text style={[
              styles.priceText,
              isCurrentPlan && styles.currentPlanPrice
            ]}>
              {plan.price}
            </Text>
            <Text style={styles.priceDescription}>
              {plan.duration === 'monthly' ? 'por mês' : 'por ano'}
            </Text>
            {plan.duration === 'yearly' && (
              <Text style={styles.monthlyEquivalent}>
                equivale a R$ 4,99/mês
              </Text>
            )}
          </View>
          
          <Paragraph style={styles.planDescription}>
            {plan.description}
          </Paragraph>
          
          <View style={styles.benefitsList}>
            {plan.benefits.map((benefit, index) => (
              <View key={index} style={styles.benefitItem}>
                <Icon 
                  name="check-circle" 
                  size={16} 
                  color={isCurrentPlan ? mysticalTheme.colors.primary : mysticalTheme.colors.secondary} 
                />
                <Text style={[
                  styles.benefitText,
                  isCurrentPlan && styles.currentPlanBenefit
                ]}>
                  {benefit}
                </Text>
              </View>
            ))}
          </View>
          
          {isCurrentPlan ? (
            <Button
              mode="outlined"
              disabled
              style={styles.currentPlanButton}
              icon="check"
            >
              Plano Atual
            </Button>
          ) : (
            <Button
              mode="contained"
              onPress={onSelect}
              style={[
                styles.subscribeButton,
                isPopular && styles.popularSubscribeButton
              ]}
              loading={isLoading}
              disabled={isLoading}
            >
              {isLoading ? 'Processando...' : 'Assinar Agora'}
            </Button>
          )}
        </Card.Content>
      </Card>
    </TouchableOpacity>
  );
}

export default function SubscriptionPlansScreen({ navigation }: any) {
  const {
    isPremium,
    currentPlan,
    availablePlans,
    purchaseSubscription,
    openSubscriptionManagement,
    isLoading,
    refreshSubscriptionStatus
  } = useSubscription();
  
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);

  useEffect(() => {
    // Refresh subscription status when screen loads
    refreshSubscriptionStatus();
  }, []);

  const handlePlanSelection = async (productId: string) => {
    try {
      setSelectedPlan(productId);
      const success = await purchaseSubscription(productId);
      
      if (success) {
        // Navigate back or to success screen
        navigation.goBack();
      }
    } catch (error) {
      console.error('Subscription error:', error);
    } finally {
      setSelectedPlan(null);
    }
  };

  const handleManageSubscription = () => {
    openSubscriptionManagement();
  };

  return (
    <ScrollView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Icon name="star-circle" size={48} color={mysticalTheme.colors.primary} />
        <Title style={styles.headerTitle}>Universo Místico Premium</Title>
        <Paragraph style={styles.headerSubtitle}>
          Desbloqueie todo o poder espiritual e conecte-se profundamente com o cosmos
        </Paragraph>
      </View>

      {/* Current Status */}
      {isPremium && currentPlan && (
        <Card style={styles.statusCard}>
          <Card.Content style={styles.statusContent}>
            <View style={styles.statusHeader}>
              <Icon name="crown" size={24} color={mysticalTheme.colors.tertiary} />
              <Title style={styles.statusTitle}>Status Premium Ativo</Title>
            </View>
            <Paragraph style={styles.statusText}>
              Você está aproveitando todos os benefícios do {currentPlan.title}
            </Paragraph>
            <Button
              mode="outlined"
              onPress={handleManageSubscription}
              style={styles.manageButton}
              icon="settings"
            >
              Gerenciar Assinatura
            </Button>
          </Card.Content>
        </Card>
      )}

      {/* Free Plan Benefits */}
      {!isPremium && (
        <Card style={styles.freePlanCard}>
          <Card.Content>
            <Title style={styles.freePlanTitle}>Plano Gratuito</Title>
            <Paragraph style={styles.freePlanText}>
              Você está usando a versão gratuita com recursos limitados
            </Paragraph>
            <View style={styles.freeBenefits}>
              <View style={styles.benefitItem}>
                <Icon name="check" size={16} color={mysticalTheme.colors.onSurfaceVariant} />
                <Text style={styles.freeBenefitText}>Horóscopo básico diário</Text>
              </View>
              <View style={styles.benefitItem}>
                <Icon name="check" size={16} color={mysticalTheme.colors.onSurfaceVariant} />
                <Text style={styles.freeBenefitText}>3 consultas de tarô por dia</Text>
              </View>
              <View style={styles.benefitItem}>
                <Icon name="check" size={16} color={mysticalTheme.colors.onSurfaceVariant} />
                <Text style={styles.freeBenefitText}>Acesso a 3 Orixás</Text>
              </View>
            </View>
          </Card.Content>
        </Card>
      )}

      {/* Subscription Plans */}
      <View style={styles.plansSection}>
        <Title style={styles.sectionTitle}>Escolha Seu Plano Premium</Title>
        <Paragraph style={styles.sectionSubtitle}>
          Acesse recursos exclusivos e aprofunde sua jornada espiritual
        </Paragraph>
        
        {availablePlans.map((plan) => (
          <PlanCard
            key={plan.productId}
            plan={plan}
            isCurrentPlan={isPremium && currentPlan?.productId === plan.productId}
            onSelect={() => handlePlanSelection(plan.productId)}
            isLoading={isLoading && selectedPlan === plan.productId}
          />
        ))}
      </View>

      {/* Premium Features Showcase */}
      <Card style={styles.featuresCard}>
        <Card.Content>
          <Title style={styles.featuresTitle}>Recursos Premium Exclusivos</Title>
          
          <List.Item
            title="Horóscopos Detalhados"
            description="Previsões completas com influências dos Orixás"
            left={props => <List.Icon {...props} icon="star-circle" />}
            titleStyle={styles.featureTitle}
            descriptionStyle={styles.featureDescription}
          />
          
          <List.Item
            title="Mensagens Espirituais Extras"
            description="Orientações diárias personalizadas dos seus Orixás"
            left={props => <List.Icon {...props} icon="meditation" />}
            titleStyle={styles.featureTitle}
            descriptionStyle={styles.featureDescription}
          />
          
          <List.Item
            title="Leituras de Tarô Ilimitadas"
            description="Consultas sem limites com interpretações profundas"
            left={props => <List.Icon {...props} icon="cards" />}
            titleStyle={styles.featureTitle}
            descriptionStyle={styles.featureDescription}
          />
          
          <List.Item
            title="Acesso a Todos os Orixás"
            description="Conecte-se com os 21 Orixás da tradição"
            left={props => <List.Icon {...props} icon="account-group" />}
            titleStyle={styles.featureTitle}
            descriptionStyle={styles.featureDescription}
          />
          
          <List.Item
            title="Notificações Personalizadas"
            description="Alertas baseados nos seus interesses espirituais"
            left={props => <List.Icon {...props} icon="bell" />}
            titleStyle={styles.featureTitle}
            descriptionStyle={styles.featureDescription}
          />
        </Card.Content>
      </Card>

      {/* Terms and Privacy */}
      <View style={styles.termsSection}>
        <Paragraph style={styles.termsText}>
          Ao assinar, você concorda com nossos Termos de Uso e Política de Privacidade. 
          A assinatura será renovada automaticamente através da sua conta Google Play.
        </Paragraph>
        <Paragraph style={styles.termsText}>
          Você pode cancelar a qualquer momento nas configurações da sua conta Google Play.
        </Paragraph>
      </View>

      <View style={styles.bottomSpacing} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: mysticalTheme.colors.background,
  },
  header: {
    alignItems: 'center',
    padding: 24,
    backgroundColor: mysticalTheme.colors.primaryContainer,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: mysticalTheme.colors.primary,
    marginTop: 12,
    marginBottom: 8,
    textAlign: 'center',
  },
  headerSubtitle: {
    fontSize: 16,
    color: mysticalTheme.colors.onSurfaceVariant,
    textAlign: 'center',
    marginHorizontal: 20,
  },
  statusCard: {
    margin: 16,
    borderRadius: 12,
    backgroundColor: mysticalTheme.colors.tertiaryContainer,
  },
  statusContent: {
    padding: 20,
  },
  statusHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  statusTitle: {
    marginLeft: 8,
    color: mysticalTheme.colors.onTertiaryContainer,
  },
  statusText: {
    color: mysticalTheme.colors.onTertiaryContainer,
    marginBottom: 16,
  },
  manageButton: {
    alignSelf: 'flex-start',
  },
  freePlanCard: {
    margin: 16,
    borderRadius: 12,
    backgroundColor: mysticalTheme.colors.surfaceVariant,
  },
  freePlanTitle: {
    color: mysticalTheme.colors.onSurface,
    marginBottom: 8,
  },
  freePlanText: {
    color: mysticalTheme.colors.onSurfaceVariant,
    marginBottom: 16,
  },
  freeBenefits: {
    gap: 8,
  },
  freeBenefitText: {
    marginLeft: 8,
    color: mysticalTheme.colors.onSurfaceVariant,
    fontSize: 14,
  },
  plansSection: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: mysticalTheme.colors.onSurface,
    textAlign: 'center',
    marginBottom: 8,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: mysticalTheme.colors.onSurfaceVariant,
    textAlign: 'center',
    marginBottom: 24,
  },
  planCard: {
    marginBottom: 16,
    borderRadius: 12,
    elevation: 2,
  },
  currentPlanCard: {
    backgroundColor: mysticalTheme.colors.primaryContainer,
    borderColor: mysticalTheme.colors.primary,
    borderWidth: 2,
  },
  popularPlanCard: {
    backgroundColor: mysticalTheme.colors.secondaryContainer,
    borderColor: mysticalTheme.colors.secondary,
    borderWidth: 2,
    elevation: 4,
  },
  popularBadge: {
    position: 'absolute',
    top: -8,
    right: 16,
    zIndex: 1,
  },
  popularBadgeText: {
    backgroundColor: mysticalTheme.colors.tertiary,
    color: 'white',
    fontSize: 12,
  },
  planContent: {
    padding: 20,
  },
  planHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  planTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: mysticalTheme.colors.onSurface,
  },
  currentPlanTitle: {
    color: mysticalTheme.colors.primary,
  },
  discountChip: {
    backgroundColor: mysticalTheme.colors.tertiary,
  },
  discountText: {
    color: 'white',
    fontSize: 10,
  },
  priceContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  priceText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: mysticalTheme.colors.primary,
  },
  currentPlanPrice: {
    color: mysticalTheme.colors.secondary,
  },
  priceDescription: {
    fontSize: 14,
    color: mysticalTheme.colors.onSurfaceVariant,
  },
  monthlyEquivalent: {
    fontSize: 12,
    color: mysticalTheme.colors.tertiary,
    fontStyle: 'italic',
  },
  planDescription: {
    fontSize: 14,
    color: mysticalTheme.colors.onSurfaceVariant,
    textAlign: 'center',
    marginBottom: 20,
  },
  benefitsList: {
    marginBottom: 20,
    gap: 8,
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  benefitText: {
    marginLeft: 8,
    fontSize: 14,
    color: mysticalTheme.colors.onSurface,
  },
  currentPlanBenefit: {
    color: mysticalTheme.colors.primary,
  },
  subscribeButton: {
    paddingVertical: 4,
  },
  popularSubscribeButton: {
    backgroundColor: mysticalTheme.colors.secondary,
  },
  currentPlanButton: {
    borderColor: mysticalTheme.colors.primary,
  },
  featuresCard: {
    margin: 16,
    borderRadius: 12,
  },
  featuresTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: mysticalTheme.colors.onSurface,
    marginBottom: 16,
    textAlign: 'center',
  },
  featureTitle: {
    color: mysticalTheme.colors.onSurface,
    fontSize: 16,
    fontWeight: '600',
  },
  featureDescription: {
    color: mysticalTheme.colors.onSurfaceVariant,
    fontSize: 14,
  },
  termsSection: {
    padding: 16,
    paddingTop: 0,
  },
  termsText: {
    fontSize: 12,
    color: mysticalTheme.colors.onSurfaceVariant,
    textAlign: 'center',
    marginBottom: 8,
    lineHeight: 16,
  },
  bottomSpacing: {
    height: 80,
  },
});