/**
 * Main App Component for Universo Místico Mobile
 * React Native app with geolocation and push notifications
 */

import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { StatusBar } from 'expo-status-bar';
import { Provider as PaperProvider } from 'react-native-paper';
import * as SplashScreen from 'expo-splash-screen';
import * as Font from 'expo-font';

// Services
import { LocationService } from './src/services/LocationService';
import { NotificationService } from './src/services/NotificationService';

// Screens
import HomeScreen from './src/screens/HomeScreen';
import SpiritualProfileScreen from './src/screens/SpiritualProfileScreen';
import TarotScreen from './src/screens/TarotScreen';
import MapScreen from './src/screens/MapScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import LoginScreen from './src/screens/LoginScreen';
import SubscriptionPlansScreen from './src/screens/SubscriptionPlansScreen';

// Components
import { AuthProvider, useAuth } from './src/contexts/AuthContext';
import { LocationProvider } from './src/contexts/LocationContext';
import { NotificationProvider } from './src/contexts/NotificationContext';
import { SubscriptionProvider } from './src/contexts/SubscriptionContext';
import LoadingScreen from './src/components/LoadingScreen';

// Icons
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

// Theme
import { mysticalTheme } from './src/theme/theme';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

// Keep splash screen visible while loading
SplashScreen.preventAutoHideAsync();

/**
 * Main Tab Navigator for authenticated users
 */
function MainTabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: string;

          if (route.name === 'Home') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === 'Spiritual') {
            iconName = focused ? 'crown' : 'crown-outline';
          } else if (route.name === 'Tarot') {
            iconName = focused ? 'cards' : 'cards-outline';
          } else if (route.name === 'Map') {
            iconName = focused ? 'map' : 'map-outline';
          } else if (route.name === 'Profile') {
            iconName = focused ? 'account' : 'account-outline';
          } else {
            iconName = 'help-circle-outline';
          }

          return <Icon name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: mysticalTheme.colors.primary,
        tabBarInactiveTintColor: mysticalTheme.colors.outline,
        tabBarStyle: {
          backgroundColor: mysticalTheme.colors.surface,
          borderTopColor: mysticalTheme.colors.outline,
          borderTopWidth: 1,
          paddingBottom: 5,
          paddingTop: 5,
          height: 60,
        },
        tabBarLabelStyle: {
          fontSize: 12,
          fontWeight: '500',
        },
        headerStyle: {
          backgroundColor: mysticalTheme.colors.primary,
        },
        headerTintColor: mysticalTheme.colors.onPrimary,
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      })}
    >
      <Tab.Screen 
        name="Home" 
        component={HomeScreen} 
        options={{ 
          title: 'Início',
          headerTitle: 'Universo Místico'
        }} 
      />
      <Tab.Screen 
        name="Spiritual" 
        component={SpiritualProfileScreen} 
        options={{ 
          title: 'Espiritual',
          headerTitle: 'Perfil Espiritual'
        }} 
      />
      <Tab.Screen 
        name="Tarot" 
        component={TarotScreen} 
        options={{ 
          title: 'Tarô',
          headerTitle: 'Leitura de Tarô'
        }} 
      />
      <Tab.Screen 
        name="Map" 
        component={MapScreen} 
        options={{ 
          title: 'Mapa',
          headerTitle: 'Mapa Astral'
        }} 
      />
      <Tab.Screen 
        name="Profile" 
        component={ProfileScreen} 
        options={{ 
          title: 'Perfil',
          headerTitle: 'Meu Perfil'
        }} 
      />
    </Tab.Navigator>
  );
}

/**
 * Auth Stack Navigator for non-authenticated users
 */
function AuthStackNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Login" component={LoginScreen} />
    </Stack.Navigator>
  );
}

/**
 * Main App Navigator
 */
function AppNavigator() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <NavigationContainer>
      {isAuthenticated ? <MainTabNavigator /> : <AuthStackNavigator />}
    </NavigationContainer>
  );
}

/**
 * Main App Component
 */
export default function App() {
  const [appIsReady, setAppIsReady] = useState(false);

  useEffect(() => {
    async function prepare() {
      try {
        // Pre-load fonts
        await Font.loadAsync({
          'Inter-Regular': require('./assets/fonts/Inter-Regular.ttf'),
          'Inter-Medium': require('./assets/fonts/Inter-Medium.ttf'),
          'Inter-SemiBold': require('./assets/fonts/Inter-SemiBold.ttf'),
          'Inter-Bold': require('./assets/fonts/Inter-Bold.ttf'),
        });

        // Initialize services
        await LocationService.initialize();
        await NotificationService.initialize();

        // Artificial delay to show splash screen (remove in production)
        await new Promise(resolve => setTimeout(resolve, 2000));
      } catch (e) {
        console.warn('Error during app initialization:', e);
      } finally {
        setAppIsReady(true);
      }
    }

    prepare();
  }, []);

  useEffect(() => {
    if (appIsReady) {
      SplashScreen.hideAsync();
    }
  }, [appIsReady]);

  if (!appIsReady) {
    return <LoadingScreen />;
  }

  return (
    <PaperProvider theme={mysticalTheme}>
      <AuthProvider>
        <LocationProvider>
          <NotificationProvider>
            <StatusBar style="light" backgroundColor={mysticalTheme.colors.primary} />
            <AppNavigator />
          </NotificationProvider>
        </LocationProvider>
      </AuthProvider>
    </PaperProvider>
  );
}