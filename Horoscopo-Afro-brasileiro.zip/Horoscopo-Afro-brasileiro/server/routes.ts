import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertUserSchema, insertAstralChartSchema, insertHoroscopeSchema, insertTarotReadingSchema, insertUserInteractionSchema } from "@shared/schema";

// Simple authentication middleware for Firebase tokens
const authenticateUser = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'No token provided' });
    }

    // For now, we'll extract user ID from token or session
    // This will be replaced with proper Firebase token verification
    const userId = req.session?.userId || (req as any).user?.id;
    if (!userId) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    req.user = { id: userId };
    next();
  } catch (error) {
    console.error('Auth error:', error);
    res.status(401).json({ message: 'Unauthorized' });
  }
};

const getZodiacSign = (birthDate: Date): string => {
  const month = birthDate.getMonth() + 1;
  const day = birthDate.getDate();

  if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) return "Áries";
  if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) return "Touro";
  if ((month === 5 && day >= 21) || (month === 6 && day <= 20)) return "Gêmeos";
  if ((month === 6 && day >= 21) || (month === 7 && day <= 22)) return "Câncer";
  if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) return "Leão";
  if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) return "Virgem";
  if ((month === 9 && day >= 23) || (month === 10 && day <= 22)) return "Libra";
  if ((month === 10 && day >= 23) || (month === 11 && day <= 21)) return "Escorpião";
  if ((month === 11 && day >= 22) || (month === 12 && day <= 21)) return "Sagitário";
  if ((month === 12 && day >= 22) || (month === 1 && day <= 19)) return "Capricórnio";
  if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) return "Aquário";
  return "Peixes";
};

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Public routes (no auth required)
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // User routes
  app.post('/api/users', async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.json(existingUser);
      }

      // Calculate zodiac sign if birth date is provided
      if (userData.birthDate) {
        userData.zodiacSign = getZodiacSign(new Date(userData.birthDate));
      }

      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(400).json({ message: "Failed to create user" });
    }
  });

  app.get('/api/users/:id', authenticateUser, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.put('/api/users/:id', authenticateUser, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const updates = req.body;

      // Calculate zodiac sign if birth date is being updated
      if (updates.birthDate) {
        updates.zodiacSign = getZodiacSign(new Date(updates.birthDate));
      }

      const user = await storage.updateUser(userId, updates);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json(user);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  // Astral Charts routes
  app.get('/api/astral-charts/:userId', authenticateUser, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const chart = await storage.getAstralChart(userId);
      res.json(chart);
    } catch (error) {
      console.error("Error fetching astral chart:", error);
      res.status(500).json({ message: "Failed to fetch astral chart" });
    }
  });

  app.post('/api/astral-charts', authenticateUser, async (req: Request, res: Response) => {
    try {
      const chartData = insertAstralChartSchema.parse(req.body);
      const chart = await storage.createAstralChart(chartData);
      res.status(201).json(chart);
    } catch (error) {
      console.error("Error creating astral chart:", error);
      res.status(400).json({ message: "Failed to create astral chart" });
    }
  });

  // Horoscope routes
  app.get('/api/horoscope/daily', authenticateUser, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).user.id;
      const today = new Date();
      
      const horoscope = await storage.getUserHoroscope(userId, today);
      
      if (!horoscope) {
        // Generate a simple daily horoscope if none exists
        const user = await storage.getUser(userId);
        if (user?.zodiacSign) {
          const newHoroscope = await storage.createHoroscope({
            userId: userId,
            zodiacSign: user.zodiacSign,
            date: today,
            content: `Hoje é um dia especial para ${user.zodiacSign}. As energias cósmicas estão alinhadas para trazer novas oportunidades.`,
            loveRating: Math.floor(Math.random() * 5) + 1,
            workRating: Math.floor(Math.random() * 5) + 1,
            healthRating: Math.floor(Math.random() * 5) + 1,
          });
          return res.json(newHoroscope);
        }
      }
      
      res.json(horoscope);
    } catch (error) {
      console.error("Error fetching daily horoscope:", error);
      res.status(500).json({ message: "Failed to fetch daily horoscope" });
    }
  });

  app.get('/api/horoscope/history/:userId', authenticateUser, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const limit = parseInt(req.query.limit as string) || 10;
      
      const history = await storage.getHoroscopeHistory(userId, limit);
      res.json(history);
    } catch (error) {
      console.error("Error fetching horoscope history:", error);
      res.status(500).json({ message: "Failed to fetch horoscope history" });
    }
  });

  // Tarot routes
  app.get('/api/tarot/cards', async (req: Request, res: Response) => {
    try {
      const cards = await storage.getAllTarotCards();
      res.json(cards);
    } catch (error) {
      console.error("Error fetching tarot cards:", error);
      res.status(500).json({ message: "Failed to fetch tarot cards" });
    }
  });

  app.get('/api/tarot/reading/:count', authenticateUser, async (req: Request, res: Response) => {
    try {
      const count = parseInt(req.params.count) || 3;
      const cards = await storage.getRandomTarotCards(count);
      res.json(cards);
    } catch (error) {
      console.error("Error generating tarot reading:", error);
      res.status(500).json({ message: "Failed to generate tarot reading" });
    }
  });

  app.post('/api/tarot/readings', authenticateUser, async (req: Request, res: Response) => {
    try {
      const readingData = insertTarotReadingSchema.parse(req.body);
      const reading = await storage.createTarotReading(readingData);
      res.status(201).json(reading);
    } catch (error) {
      console.error("Error saving tarot reading:", error);
      res.status(400).json({ message: "Failed to save tarot reading" });
    }
  });

  app.get('/api/tarot/readings/:userId', authenticateUser, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const limit = parseInt(req.query.limit as string) || 10;
      
      const readings = await storage.getUserTarotReadings(userId, limit);
      res.json(readings);
    } catch (error) {
      console.error("Error fetching tarot readings:", error);
      res.status(500).json({ message: "Failed to fetch tarot readings" });
    }
  });

  // Orixa routes
  app.get('/api/orixas', async (req: Request, res: Response) => {
    try {
      const orixas = await storage.getAllOrixas();
      res.json(orixas);
    } catch (error) {
      console.error("Error fetching orixas:", error);
      res.status(500).json({ message: "Failed to fetch orixas" });
    }
  });

  app.get('/api/orixas/:name', async (req: Request, res: Response) => {
    try {
      const name = req.params.name;
      const orixa = await storage.getOrixaByName(name);
      
      if (!orixa) {
        return res.status(404).json({ message: "Orixa not found" });
      }
      
      res.json(orixa);
    } catch (error) {
      console.error("Error fetching orixa:", error);
      res.status(500).json({ message: "Failed to fetch orixa" });
    }
  });

  // Subscription routes
  app.get('/api/subscription', authenticateUser, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).user.id;
      const subscription = await storage.getUserSubscription(userId);
      res.json(subscription || { planType: 'free', status: 'active' });
    } catch (error) {
      console.error("Error fetching subscription:", error);
      res.status(500).json({ message: "Failed to fetch subscription" });
    }
  });

  app.post('/api/subscription', authenticateUser, async (req: Request, res: Response) => {
    try {
      const subscriptionData = req.body;
      const subscription = await storage.createSubscription(subscriptionData);
      res.status(201).json(subscription);
    } catch (error) {
      console.error("Error creating subscription:", error);
      res.status(400).json({ message: "Failed to create subscription" });
    }
  });

  // User interactions
  app.post('/api/interactions', authenticateUser, async (req: Request, res: Response) => {
    try {
      const interactionData = insertUserInteractionSchema.parse(req.body);
      const interaction = await storage.logUserInteraction(interactionData);
      res.status(201).json(interaction);
    } catch (error) {
      console.error("Error logging interaction:", error);
      res.status(400).json({ message: "Failed to log interaction" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}