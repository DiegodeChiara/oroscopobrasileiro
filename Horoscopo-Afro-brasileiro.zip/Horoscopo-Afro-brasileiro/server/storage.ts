import {
  users,
  astralCharts,
  horoscopes,
  tarotCards,
  tarotReadings,
  orixas,
  subscriptions,
  userInteractions,
  type User,
  type InsertUser,
  type AstralChart,
  type InsertAstralChart,
  type Horoscope,
  type InsertHoroscope,
  type TarotCard,
  type TarotReading,
  type InsertTarotReading,
  type Orixa,
  type Subscription,
  type UserInteraction,
  type InsertUserInteraction,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;

  // Astral Charts
  getAstralChart(userId: number): Promise<AstralChart | undefined>;
  createAstralChart(chart: InsertAstralChart): Promise<AstralChart>;
  updateAstralChart(userId: number, updates: Partial<AstralChart>): Promise<AstralChart | undefined>;

  // Horoscopes
  getDailyHoroscope(zodiacSign: string, date: Date): Promise<Horoscope | undefined>;
  getUserHoroscope(userId: number, date: Date): Promise<Horoscope | undefined>;
  createHoroscope(horoscope: InsertHoroscope): Promise<Horoscope>;
  getHoroscopeHistory(userId: number, limit?: number): Promise<Horoscope[]>;

  // Tarot
  getAllTarotCards(): Promise<TarotCard[]>;
  getTarotCard(id: number): Promise<TarotCard | undefined>;
  getRandomTarotCards(count: number): Promise<TarotCard[]>;
  createTarotCard(card: Omit<TarotCard, 'id'>): Promise<TarotCard>;
  createTarotReading(reading: InsertTarotReading): Promise<TarotReading>;
  getUserTarotReadings(userId: number, limit?: number): Promise<TarotReading[]>;

  // Orixás
  getAllOrixas(): Promise<Orixa[]>;
  getOrixaByName(name: string): Promise<Orixa | undefined>;
  getOrixasByZodiacSign(zodiacSign: string): Promise<Orixa[]>;
  createOrixa(orixa: Omit<Orixa, 'id'>): Promise<Orixa>;

  // Subscriptions
  getUserSubscription(userId: number): Promise<Subscription | undefined>;
  createSubscription(subscription: Omit<Subscription, 'id' | 'createdAt'>): Promise<Subscription>;
  updateSubscription(userId: number, updates: Partial<Subscription>): Promise<Subscription | undefined>;

  // User Interactions
  logUserInteraction(interaction: InsertUserInteraction): Promise<UserInteraction>;
  getUserInteractions(userId: number, limit?: number): Promise<UserInteraction[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  // Astral Charts
  async getAstralChart(userId: number): Promise<AstralChart | undefined> {
    const [chart] = await db
      .select()
      .from(astralCharts)
      .where(eq(astralCharts.userId, userId));
    return chart || undefined;
  }

  async createAstralChart(chart: InsertAstralChart): Promise<AstralChart> {
    const [newChart] = await db
      .insert(astralCharts)
      .values(chart)
      .returning();
    return newChart;
  }

  async updateAstralChart(userId: number, updates: Partial<AstralChart>): Promise<AstralChart | undefined> {
    const [chart] = await db
      .update(astralCharts)
      .set(updates)
      .where(eq(astralCharts.userId, userId))
      .returning();
    return chart || undefined;
  }

  // Horoscopes
  async getDailyHoroscope(zodiacSign: string, date: Date): Promise<Horoscope | undefined> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    const [horoscope] = await db
      .select()
      .from(horoscopes)
      .where(
        and(
          eq(horoscopes.zodiacSign, zodiacSign),
          eq(horoscopes.date, startOfDay)
        )
      );
    return horoscope || undefined;
  }

  async getUserHoroscope(userId: number, date: Date): Promise<Horoscope | undefined> {
    const user = await this.getUser(userId);
    if (!user?.zodiacSign) return undefined;
    return this.getDailyHoroscope(user.zodiacSign, date);
  }

  async createHoroscope(horoscope: InsertHoroscope): Promise<Horoscope> {
    const [newHoroscope] = await db
      .insert(horoscopes)
      .values(horoscope)
      .returning();
    return newHoroscope;
  }

  async getHoroscopeHistory(userId: number, limit: number = 10): Promise<Horoscope[]> {
    return await db
      .select()
      .from(horoscopes)
      .where(eq(horoscopes.userId, userId))
      .orderBy(desc(horoscopes.date))
      .limit(limit);
  }

  // Tarot
  async getAllTarotCards(): Promise<TarotCard[]> {
    return await db.select().from(tarotCards);
  }

  async getTarotCard(id: number): Promise<TarotCard | undefined> {
    const [card] = await db.select().from(tarotCards).where(eq(tarotCards.id, id));
    return card || undefined;
  }

  async getRandomTarotCards(count: number): Promise<TarotCard[]> {
    return await db
      .select()
      .from(tarotCards)
      .orderBy(eq(tarotCards.id, Math.floor(Math.random() * 78) + 1))
      .limit(count);
  }

  async createTarotCard(card: Omit<TarotCard, 'id'>): Promise<TarotCard> {
    const [newCard] = await db
      .insert(tarotCards)
      .values(card)
      .returning();
    return newCard;
  }

  async createTarotReading(reading: InsertTarotReading): Promise<TarotReading> {
    const [newReading] = await db
      .insert(tarotReadings)
      .values(reading)
      .returning();
    return newReading;
  }

  async getUserTarotReadings(userId: number, limit: number = 10): Promise<TarotReading[]> {
    return await db
      .select()
      .from(tarotReadings)
      .where(eq(tarotReadings.userId, userId))
      .orderBy(desc(tarotReadings.createdAt))
      .limit(limit);
  }

  // Orixás
  async getAllOrixas(): Promise<Orixa[]> {
    return await db.select().from(orixas);
  }

  async getOrixaByName(name: string): Promise<Orixa | undefined> {
    const [orixa] = await db.select().from(orixas).where(eq(orixas.name, name));
    return orixa || undefined;
  }

  async getOrixasByZodiacSign(zodiacSign: string): Promise<Orixa[]> {
    return await db
      .select()
      .from(orixas);
  }

  async createOrixa(orixa: Omit<Orixa, 'id'>): Promise<Orixa> {
    const [newOrixa] = await db
      .insert(orixas)
      .values(orixa)
      .returning();
    return newOrixa;
  }

  // Subscriptions
  async getUserSubscription(userId: number): Promise<Subscription | undefined> {
    const [subscription] = await db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.userId, userId))
      .orderBy(desc(subscriptions.createdAt));
    return subscription || undefined;
  }

  async createSubscription(subscription: Omit<Subscription, 'id' | 'createdAt'>): Promise<Subscription> {
    const [newSubscription] = await db
      .insert(subscriptions)
      .values(subscription)
      .returning();
    return newSubscription;
  }

  async updateSubscription(userId: number, updates: Partial<Subscription>): Promise<Subscription | undefined> {
    const [subscription] = await db
      .update(subscriptions)
      .set(updates)
      .where(eq(subscriptions.userId, userId))
      .returning();
    return subscription || undefined;
  }

  // User Interactions
  async logUserInteraction(interaction: InsertUserInteraction): Promise<UserInteraction> {
    const [newInteraction] = await db
      .insert(userInteractions)
      .values(interaction)
      .returning();
    return newInteraction;
  }

  async getUserInteractions(userId: number, limit: number = 50): Promise<UserInteraction[]> {
    return await db
      .select()
      .from(userInteractions)
      .where(eq(userInteractions.userId, userId))
      .orderBy(desc(userInteractions.timestamp))
      .limit(limit);
  }
}

export const storage = new DatabaseStorage();