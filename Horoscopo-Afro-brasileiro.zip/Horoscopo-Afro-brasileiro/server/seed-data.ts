import { storage } from "./storage";
import { sql } from "drizzle-orm";
import { tarotCards, orixas } from "../shared/schema";

export async function seedDatabase() {
  console.log("Seeding database with initial data...");

  try {
    // Seed Tarot Cards
    const tarotCards = [
      {
        name: "O Louco",
        arcana: "major",
        number: 0,
        uprightMeaning: "Novos começos, espontaneidade, inocência, aventura",
        reversedMeaning: "Imprudência, tolice, falta de direção, irresponsabilidade",
        keywords: ["início", "aventura", "espontaneidade", "inocência"],
        culturalContext: "Representa o espírito livre dos brasileiros, a coragem de explorar novos caminhos",
        orixaConnection: "Exú",
      },
      {
        name: "O Mago",
        arcana: "major", 
        number: 1,
        uprightMeaning: "Manifestação, força de vontade, criatividade, poder pessoal",
        reversedMeaning: "Manipulação, falta de energia, objetivos confusos",
        keywords: ["poder", "criatividade", "manifestação", "habilidade"],
        culturalContext: "Como os curandeiros e benzedeiras, usa o conhecimento para transformar a realidade",
        orixaConnection: "Oxóssi",
      },
      {
        name: "A Sacerdotisa",
        arcana: "major",
        number: 2, 
        uprightMeaning: "Intuição, mistério, sabedoria interior, conhecimento oculto",
        reversedMeaning: "Segredos, intuição bloqueada, falta de percepção",
        keywords: ["intuição", "mistério", "sabedoria", "feminino"],
        culturalContext: "Representa as mães-de-santo e a sabedoria ancestral feminina",
        orixaConnection: "Iemanjá",
      },
      {
        name: "O Imperador",
        arcana: "major",
        number: 4,
        uprightMeaning: "Autoridade, estrutura, controle, liderança",
        reversedMeaning: "Tirania, rigidez, falta de disciplina, abuso de poder",
        keywords: ["autoridade", "liderança", "estrutura", "poder"],
        culturalContext: "A força e justiça dos líderes comunitários brasileiros",
        orixaConnection: "Xangô",
      },
      {
        name: "A Imperatriz",
        arcana: "major",
        number: 3,
        uprightMeaning: "Feminilidade, beleza, natureza, abundância, maternidade",
        reversedMeaning: "Dependência criativa, falta de crescimento, problemas maternais",
        keywords: ["feminilidade", "natureza", "abundância", "criatividade"],
        culturalContext: "A mãe terra brasileira, a fertilidade da nossa terra",
        orixaConnection: "Oxum",
      },
      {
        name: "O Sol",
        arcana: "major",
        number: 19,
        uprightMeaning: "Alegria, sucesso, vitalidade, otimismo",
        reversedMeaning: "Negatividade, falta de entusiasmo, pessimismo",
        keywords: ["alegria", "sucesso", "vitalidade", "positividade"],
        culturalContext: "O calor e energia do Brasil, a alegria do nosso povo",
        orixaConnection: "Oxalá",
      },
      {
        name: "A Lua",
        arcana: "major", 
        number: 18,
        uprightMeaning: "Ilusão, intuição, sonhos, subconsciente",
        reversedMeaning: "Confusão, medo, mal-entendidos, ansiedade",
        keywords: ["intuição", "sonhos", "mistério", "subconsciente"],
        culturalContext: "As noites místicas brasileiras, o poder da lua nas tradições",
        orixaConnection: "Iansã",
      },
      {
        name: "A Estrela",
        arcana: "major",
        number: 17,
        uprightMeaning: "Esperança, inspiração, espiritualidade, renovação",
        reversedMeaning: "Falta de fé, desespero, desconexão espiritual",
        keywords: ["esperança", "inspiração", "espiritualidade", "renovação"],
        culturalContext: "A fé e esperança do povo brasileiro nas adversidades",
        orixaConnection: "Iemanjá",
      }
    ];

    // Insert tarot cards using Drizzle
    for (const card of tarotCards) {
      try {
        await storage.createTarotCard({
          name: card.name,
          arcana: card.arcana,
          suit: null,
          number: card.number,
          uprightMeaning: card.uprightMeaning,
          reversedMeaning: card.reversedMeaning,
          keywords: card.keywords,
          culturalContext: card.culturalContext,
          orixaConnection: card.orixaConnection,
          imageUrl: null,
        });
      } catch (error: any) {
        // Card may already exist, continue
        console.log(`Card ${card.name} already exists or error:`, error?.message || 'Unknown error');
      }
    }

    // Seed Orixás
    const orixas = [
      {
        name: "Exú",
        domain: "Caminhos, comunicação, movimento",
        colors: ["vermelho", "preto"],
        elements: ["fogo", "terra"],
        attributes: ["comunicação", "movimento", "abertura de caminhos", "proteção"],
        description: "Orixá dos caminhos e da comunicação, abre portas e remove obstáculos",
        offerings: ["dendê", "farofa", "aguardente", "charuto"],
        correspondingPlanets: ["Mercúrio"],
        zodiacSigns: ["Gêmeos", "Virgem"],
      },
      {
        name: "Iemanjá", 
        domain: "Mar, maternidade, proteção",
        colors: ["azul", "branco", "prata"],
        elements: ["água"],
        attributes: ["maternidade", "proteção", "fertilidade", "amor incondicional"],
        description: "Mãe de todos os Orixás, rainha do mar e protetora das famílias",
        offerings: ["flores brancas", "perfume", "champagne", "frutas"],
        correspondingPlanets: ["Lua"],
        zodiacSigns: ["Câncer", "Peixes"],
      },
      {
        name: "Oxalá",
        domain: "Paz, criação, sabedoria",
        colors: ["branco"],
        elements: ["ar"],
        attributes: ["paz", "sabedoria", "criação", "purificação"],
        description: "Pai de todos os Orixás, criador da humanidade, símbolo de paz",
        offerings: ["canjica", "água", "velas brancas", "flores brancas"],
        correspondingPlanets: ["Sol"],
        zodiacSigns: ["Aquário", "Libra"],
      },
      {
        name: "Iansã",
        domain: "Ventos, tempestades, transformação",
        colors: ["amarelo", "vermelho", "marrom"],
        elements: ["ar", "fogo"],
        attributes: ["transformação", "coragem", "paixão", "mudança"],
        description: "Senhora dos ventos e tempestades, guerreira da transformação",
        offerings: ["vinho tinto", "frutas vermelhas", "acarajé", "flores amarelas"],
        correspondingPlanets: ["Júpiter"],
        zodiacSigns: ["Áries", "Sagitário"],
      },
      {
        name: "Xangô",
        domain: "Justiça, fogo, trovão",
        colors: ["vermelho", "branco"],
        elements: ["fogo"],
        attributes: ["justiça", "liderança", "força", "realeza"],
        description: "Rei da justiça, senhor do trovão, símbolo de liderança",
        offerings: ["quiabo", "amalá", "vinho tinto", "frutas vermelhas"],
        correspondingPlanets: ["Júpiter"],
        zodiacSigns: ["Leão", "Áries"],
      },
      {
        name: "Oxóssi",
        domain: "Caça, fartura, conhecimento",
        colors: ["verde", "azul"],
        elements: ["terra", "água"],
        attributes: ["abundância", "conhecimento", "provisão", "natureza"],
        description: "Caçador divino, provedor da fartura e conhecimento",
        offerings: ["frutas", "mel", "milho", "cerveja"],
        correspondingPlanets: ["Lua"],
        zodiacSigns: ["Touro", "Câncer"],
      },
      {
        name: "Ogum",
        domain: "Guerra, trabalho, tecnologia",
        colors: ["azul", "vermelho"],
        elements: ["ferro", "fogo"],
        attributes: ["trabalho", "determinação", "tecnologia", "guerra"],
        description: "Guerreiro do trabalho, senhor da tecnologia e determinação",
        offerings: ["feijoada", "cerveja", "inhame", "mel"],
        correspondingPlanets: ["Marte"],
        zodiacSigns: ["Áries", "Escorpião"],
      }
    ];

    // Insert orixás using Drizzle
    for (const orixa of orixas) {
      try {
        await storage.createOrixa({
          name: orixa.name,
          domain: orixa.domain,
          colors: orixa.colors,
          elements: orixa.elements,
          attributes: orixa.attributes,
          description: orixa.description,
          offerings: orixa.offerings,
          correspondingPlanets: orixa.correspondingPlanets,
          zodiacSigns: orixa.zodiacSigns,
        });
      } catch (error: any) {
        // Orixa may already exist, continue
        console.log(`Orixa ${orixa.name} already exists or error:`, error?.message || 'Unknown error');
      }
    }

    console.log("Database seeded successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}
