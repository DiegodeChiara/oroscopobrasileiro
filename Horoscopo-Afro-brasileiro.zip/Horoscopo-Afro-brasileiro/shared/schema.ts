import { pgTable, text, varchar, serial, integer, boolean, timestamp, json, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table for Firebase Auth
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email").unique().notNull(),
  name: varchar("name").notNull(),
  birthDate: timestamp("birth_date"),
  birthTime: varchar("birth_time"),
  birthLocation: varchar("birth_location"),
  zodiacSign: varchar("zodiac_sign"),
  premiumStatus: boolean("premium_status").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const astralCharts = pgTable("astral_charts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  birthDate: timestamp("birth_date").notNull(),
  birthTime: text("birth_time").notNull(),
  birthLocation: text("birth_location").notNull(),
  latitude: decimal("latitude"),
  longitude: decimal("longitude"),
  sunSign: text("sun_sign"),
  moonSign: text("moon_sign"),
  risingSign: text("rising_sign"),
  chartData: json("chart_data"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const horoscopes = pgTable("horoscopes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  zodiacSign: text("zodiac_sign").notNull(),
  date: timestamp("date").notNull(),
  content: text("content").notNull(),
  orixaInfluence: text("orixa_influence"),
  loveRating: integer("love_rating"),
  workRating: integer("work_rating"),
  healthRating: integer("health_rating"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tarotCards = pgTable("tarot_cards", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  suit: text("suit"),
  number: text("number"),
  meaningUpright: text("meaning_upright").notNull(),
  meaningReversed: text("meaning_reversed").notNull(),
  keywordsUpright: text("keywords_upright").array(),
  keywordsReversed: text("keywords_reversed").array(),
  description: text("description"),
  imageUrl: text("image_url"),
});

export const tarotReadings = pgTable("tarot_readings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  readingType: text("reading_type").notNull(),
  cards: json("cards").notNull(),
  interpretation: text("interpretation").notNull(),
  question: text("question"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const orixas = pgTable("orixas", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  domain: text("domain").array(),
  colors: text("colors").array(),
  symbols: text("symbols").array(),
  characteristics: text("characteristics"),
  zodiacSigns: text("zodiac_signs").array(),
  description: text("description"),
  imageUrl: text("image_url"),
});

export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  planType: text("plan_type").notNull(),
  status: text("status").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  paymentMethod: text("payment_method"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userInteractions = pgTable("user_interactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  action: text("action").notNull(),
  context: json("context"),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAstralChartSchema = createInsertSchema(astralCharts).omit({
  id: true,
  createdAt: true,
});

export const insertHoroscopeSchema = createInsertSchema(horoscopes).omit({
  id: true,
  createdAt: true,
});

export const insertTarotReadingSchema = createInsertSchema(tarotReadings).omit({
  id: true,
  createdAt: true,
});

export const insertUserInteractionSchema = createInsertSchema(userInteractions).omit({
  id: true,
  timestamp: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type AstralChart = typeof astralCharts.$inferSelect;
export type InsertAstralChart = z.infer<typeof insertAstralChartSchema>;
export type Horoscope = typeof horoscopes.$inferSelect;
export type InsertHoroscope = z.infer<typeof insertHoroscopeSchema>;
export type TarotCard = typeof tarotCards.$inferSelect;
export type TarotReading = typeof tarotReadings.$inferSelect;
export type InsertTarotReading = z.infer<typeof insertTarotReadingSchema>;
export type Orixa = typeof orixas.$inferSelect;
export type Subscription = typeof subscriptions.$inferSelect;
export type UserInteraction = typeof userInteractions.$inferSelect;
export type InsertUserInteraction = z.infer<typeof insertUserInteractionSchema>;