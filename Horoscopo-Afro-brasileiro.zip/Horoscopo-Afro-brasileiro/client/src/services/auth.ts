/**
 * Serviço de Autenticação
 * Centraliza toda a lógica de autenticação Firebase e integração com o backend
 */
import { User as FirebaseUser } from 'firebase/auth';
import { signInWithGoogle, signOutUser, auth } from '@/lib/firebase';
import { apiRequest } from '@/lib/queryClient';
import { User } from '@/lib/auth';

export interface AuthResponse {
  success: boolean;
  user?: User;
  token?: string;
  error?: string;
}

/**
 * Faz login com Google e sincroniza com o backend
 */
export const authenticateWithGoogle = async (): Promise<AuthResponse> => {
  try {
    const firebaseUser = await signInWithGoogle();
    
    if (!firebaseUser) {
      return {
        success: false,
        error: 'Falha na autenticação com Google'
      };
    }

    // Obter token Firebase para autenticação no backend
    const firebaseToken = await firebaseUser.getIdToken();
    
    // Sincronizar com o backend
    const backendResponse = await syncWithBackend(firebaseUser, firebaseToken);
    
    return {
      success: true,
      user: backendResponse.user,
      token: backendResponse.token
    };
    
  } catch (error) {
    console.error('Erro na autenticação:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido na autenticação'
    };
  }
};

/**
 * Sincroniza usuário Firebase com o backend
 */
export const syncWithBackend = async (firebaseUser: FirebaseUser, firebaseToken: string): Promise<{ user: User; token: string }> => {
  try {
    // Tentar fazer login no backend com token Firebase
    const loginResponse = await apiRequest('/api/auth/firebase-login', {
      method: 'POST',
      body: JSON.stringify({
        firebaseToken,
        email: firebaseUser.email,
        name: firebaseUser.displayName,
        photoURL: firebaseUser.photoURL
      })
    });

    return loginResponse;
  } catch (error) {
    // Se não existe no backend, criar conta
    if (error instanceof Error && error.message.includes('404')) {
      return await createBackendUser(firebaseUser, firebaseToken);
    }
    throw error;
  }
};

/**
 * Cria usuário no backend
 */
export const createBackendUser = async (firebaseUser: FirebaseUser, firebaseToken: string): Promise<{ user: User; token: string }> => {
  const userData = {
    email: firebaseUser.email!,
    name: firebaseUser.displayName || firebaseUser.email!.split('@')[0],
    password: 'firebase-auth', // Senha dummy para usuários Firebase
    firebaseToken
  };

  const response = await apiRequest('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify(userData)
  });

  return response;
};

/**
 * Faz logout completo (Firebase + backend)
 */
export const signOutComplete = async (): Promise<void> => {
  try {
    // Logout do Firebase
    await signOutUser();
    
    // Limpar dados locais
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user_data');
    
    // Logout do backend se necessário
    try {
      await apiRequest('/api/auth/logout', {
        method: 'POST'
      });
    } catch (error) {
      // Ignorar erros de logout do backend
      console.warn('Erro no logout do backend (ignorado):', error);
    }
  } catch (error) {
    console.error('Erro no logout:', error);
    throw error;
  }
};

/**
 * Verifica se o usuário está autenticado
 */
export const checkAuthStatus = async (): Promise<{ isAuthenticated: boolean; user?: User }> => {
  try {
    const firebaseUser = auth.currentUser;
    
    if (!firebaseUser) {
      return { isAuthenticated: false };
    }

    // Verificar se token ainda é válido
    const token = await firebaseUser.getIdToken(true);
    
    // Verificar com backend
    const response = await apiRequest('/api/auth/me', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    return {
      isAuthenticated: true,
      user: response.user
    };
  } catch (error) {
    console.error('Erro ao verificar status de autenticação:', error);
    return { isAuthenticated: false };
  }
};

/**
 * Obtém token de autenticação atual
 */
export const getCurrentAuthToken = async (): Promise<string | null> => {
  try {
    const firebaseUser = auth.currentUser;
    
    if (!firebaseUser) {
      return null;
    }

    return await firebaseUser.getIdToken();
  } catch (error) {
    console.error('Erro ao obter token:', error);
    return null;
  }
};

/**
 * Monitora mudanças no estado de autenticação
 */
export const onAuthStateChange = (callback: (user: FirebaseUser | null) => void) => {
  return auth.onAuthStateChanged(callback);
};

// Export as default service object for backward compatibility
export const authService = {
  login: authenticateWithGoogle,
  register: createBackendUser,
  logout: signOutComplete,
  updateProfile: async (updates: Partial<User>) => {
    // Implementation for profile updates
    throw new Error('Profile update not implemented yet');
  },
  isAuthenticated: () => !!auth.currentUser,
  getStoredUser: () => {
    const userData = localStorage.getItem('user_data');
    return userData ? JSON.parse(userData) : null;
  },
  getCurrentAuthToken,
  checkAuthStatus,
  onAuthStateChange
};