/**
 * Centralized API service for the astrology application
 * Handles all HTTP requests with proper error handling and type safety
 */

import { API_CONFIG, ERROR_MESSAGES } from "@/constants/app";
import type { ApiResponse } from "@/types";

/**
 * HTTP methods enum for type safety
 */
export enum HttpMethod {
  GET = 'GET',
  POST = 'POST',
  PUT = 'PUT',
  PATCH = 'PATCH',
  DELETE = 'DELETE',
}

/**
 * API request configuration interface
 */
interface ApiRequestConfig {
  method?: HttpMethod;
  headers?: HeadersInit;
  body?: any;
  timeout?: number;
}

/**
 * Custom error class for API errors
 */
export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public response?: any
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

/**
 * Base API service class with common functionality
 */
class ApiService {
  private baseUrl: string;
  private defaultTimeout: number;

  constructor(baseUrl: string = API_CONFIG.baseUrl, timeout: number = API_CONFIG.timeout) {
    this.baseUrl = baseUrl;
    this.defaultTimeout = timeout;
  }

  /**
   * Makes an HTTP request with proper error handling
   * @param endpoint - API endpoint
   * @param config - Request configuration
   * @returns Promise with response data
   */
  async request<T = any>(
    endpoint: string,
    config: ApiRequestConfig = {}
  ): Promise<ApiResponse<T>> {
    const {
      method = HttpMethod.GET,
      headers: customHeaders = {},
      body,
      timeout = this.defaultTimeout,
    } = config;

    const url = `${this.baseUrl}${endpoint}`;
    
    // Default headers
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      ...customHeaders,
    };

    // Get auth token if available
    const token = localStorage.getItem('auth_token');
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    // Create request config
    const requestConfig: RequestInit = {
      method,
      headers,
      ...(body && { body: JSON.stringify(body) }),
    };

    try {
      // Create abort controller for timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);

      const response = await fetch(url, {
        ...requestConfig,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      // Handle HTTP errors
      if (!response.ok) {
        const errorMessage = this.getErrorMessage(response.status);
        throw new ApiError(errorMessage, response.status, response);
      }

      // Parse response
      const data = await response.json();
      return { data };

    } catch (error) {
      if (error instanceof ApiError) {
        throw error;
      }

      // Handle network errors
      if (error instanceof TypeError) {
        throw new ApiError(ERROR_MESSAGES.NETWORK_ERROR, 0);
      }

      // Handle timeout errors
      if (error.name === 'AbortError') {
        throw new ApiError('Request timeout', 408);
      }

      // Generic error
      throw new ApiError(ERROR_MESSAGES.SERVER_ERROR, 500);
    }
  }

  /**
   * GET request helper
   */
  async get<T = any>(endpoint: string, headers?: HeadersInit): Promise<ApiResponse<T>> {
    return this.request<T>(endpoint, { method: HttpMethod.GET, headers });
  }

  /**
   * POST request helper
   */
  async post<T = any>(endpoint: string, body?: any, headers?: HeadersInit): Promise<ApiResponse<T>> {
    return this.request<T>(endpoint, { method: HttpMethod.POST, body, headers });
  }

  /**
   * PUT request helper
   */
  async put<T = any>(endpoint: string, body?: any, headers?: HeadersInit): Promise<ApiResponse<T>> {
    return this.request<T>(endpoint, { method: HttpMethod.PUT, body, headers });
  }

  /**
   * PATCH request helper
   */
  async patch<T = any>(endpoint: string, body?: any, headers?: HeadersInit): Promise<ApiResponse<T>> {
    return this.request<T>(endpoint, { method: HttpMethod.PATCH, body, headers });
  }

  /**
   * DELETE request helper
   */
  async delete<T = any>(endpoint: string, headers?: HeadersInit): Promise<ApiResponse<T>> {
    return this.request<T>(endpoint, { method: HttpMethod.DELETE, headers });
  }

  /**
   * Maps HTTP status codes to error messages
   * @param status - HTTP status code
   * @returns Error message
   */
  private getErrorMessage(status: number): string {
    switch (status) {
      case 400:
        return ERROR_MESSAGES.VALIDATION_ERROR;
      case 401:
        return ERROR_MESSAGES.UNAUTHORIZED;
      case 403:
        return ERROR_MESSAGES.FORBIDDEN;
      case 404:
        return ERROR_MESSAGES.NOT_FOUND;
      case 429:
        return ERROR_MESSAGES.RATE_LIMIT;
      case 500:
      case 502:
      case 503:
      case 504:
        return ERROR_MESSAGES.SERVER_ERROR;
      default:
        return ERROR_MESSAGES.SERVER_ERROR;
    }
  }
}

// Export singleton instance
export const apiService = new ApiService();

/**
 * Legacy API request function for backward compatibility
 * TODO: Migrate all usages to use apiService directly
 */
export async function apiRequest(
  method: string,
  endpoint: string,
  body?: any
): Promise<Response> {
  const response = await apiService.request(endpoint, {
    method: method as HttpMethod,
    body,
  });

  // Return a Response-like object for compatibility
  return {
    json: async () => response.data,
    ok: true,
    status: 200,
  } as Response;
}