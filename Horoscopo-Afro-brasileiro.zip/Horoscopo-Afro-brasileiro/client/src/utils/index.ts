/**
 * Utility functions for the astrology application
 * Centralized utility functions for better code reusability
 */

import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { ZODIAC_SIGNS, ZODIAC_DETAILS } from "@/constants/app";
import type { ZodiacSign } from "@/types";

/**
 * Merges Tailwind CSS classes with clsx
 * @param inputs - Class values to merge
 * @returns Merged class string
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Formats a date to Brazilian format (DD/MM/YYYY)
 * @param date - Date to format
 * @returns Formatted date string
 */
export function formatDateBR(date: Date | string): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return dateObj.toLocaleDateString('pt-BR');
}

/**
 * Formats a time to Brazilian format (HH:MM)
 * @param time - Time to format
 * @returns Formatted time string
 */
export function formatTimeBR(time: Date | string): string {
  const timeObj = typeof time === 'string' ? new Date(time) : time;
  return timeObj.toLocaleTimeString('pt-BR', { 
    hour: '2-digit', 
    minute: '2-digit' 
  });
}

/**
 * Gets the current greeting based on time of day
 * @returns Greeting string
 */
export function getTimeGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "Bom dia";
  if (hour < 18) return "Boa tarde";
  return "Boa noite";
}

/**
 * Calculates zodiac sign based on birth date
 * @param birthDate - Birth date string (YYYY-MM-DD)
 * @returns Zodiac sign
 */
export function calculateZodiacSign(birthDate: string): ZodiacSign {
  const date = new Date(birthDate);
  const month = date.getMonth() + 1; // 0-indexed
  const day = date.getDate();

  // Zodiac sign calculation logic
  if ((month === 3 && day >= 21) || (month === 4 && day <= 20)) return 'Áries';
  if ((month === 4 && day >= 21) || (month === 5 && day <= 21)) return 'Touro';
  if ((month === 5 && day >= 22) || (month === 6 && day <= 21)) return 'Gêmeos';
  if ((month === 6 && day >= 22) || (month === 7 && day <= 23)) return 'Câncer';
  if ((month === 7 && day >= 24) || (month === 8 && day <= 23)) return 'Leão';
  if ((month === 8 && day >= 24) || (month === 9 && day <= 23)) return 'Virgem';
  if ((month === 9 && day >= 24) || (month === 10 && day <= 23)) return 'Libra';
  if ((month === 10 && day >= 24) || (month === 11 && day <= 22)) return 'Escorpião';
  if ((month === 11 && day >= 23) || (month === 12 && day <= 21)) return 'Sagitário';
  if ((month === 12 && day >= 22) || (month === 1 && day <= 20)) return 'Capricórnio';
  if ((month === 1 && day >= 21) || (month === 2 && day <= 19)) return 'Aquário';
  return 'Peixes';
}

/**
 * Gets zodiac sign details
 * @param sign - Zodiac sign
 * @returns Zodiac sign details
 */
export function getZodiacDetails(sign: ZodiacSign) {
  return ZODIAC_DETAILS[sign];
}

/**
 * Validates email format
 * @param email - Email to validate
 * @returns True if valid email
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validates password strength
 * @param password - Password to validate
 * @returns Validation result with strength and errors
 */
export function validatePassword(password: string): {
  isValid: boolean;
  strength: 'weak' | 'medium' | 'strong';
  errors: string[];
} {
  const errors: string[] = [];
  let strength: 'weak' | 'medium' | 'strong' = 'weak';

  if (password.length < 8) {
    errors.push('Senha deve ter pelo menos 8 caracteres');
  }
  if (!/[A-Z]/.test(password)) {
    errors.push('Senha deve ter pelo menos uma letra maiúscula');
  }
  if (!/[a-z]/.test(password)) {
    errors.push('Senha deve ter pelo menos uma letra minúscula');
  }
  if (!/\d/.test(password)) {
    errors.push('Senha deve ter pelo menos um número');
  }

  // Determine strength
  if (errors.length === 0) {
    if (password.length >= 12 && /[!@#$%^&*(),.?":{}|<>]/.test(password)) {
      strength = 'strong';
    } else {
      strength = 'medium';
    }
  }

  return {
    isValid: errors.length === 0,
    strength,
    errors
  };
}

/**
 * Formats currency to Brazilian Real
 * @param amount - Amount to format
 * @returns Formatted currency string
 */
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(amount);
}

/**
 * Debounce function for performance optimization
 * @param func - Function to debounce
 * @param wait - Wait time in milliseconds
 * @returns Debounced function
 */
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

/**
 * Throttle function for performance optimization
 * @param func - Function to throttle
 * @param limit - Time limit in milliseconds
 * @returns Throttled function
 */
export function throttle<T extends (...args: any[]) => any>(
  func: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle: boolean;
  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
}

/**
 * Capitalizes first letter of each word
 * @param str - String to capitalize
 * @returns Capitalized string
 */
export function capitalizeWords(str: string): string {
  return str.replace(/\w\S*/g, (txt) => 
    txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
  );
}

/**
 * Truncates text to specified length
 * @param text - Text to truncate
 * @param maxLength - Maximum length
 * @returns Truncated text
 */
export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
}

/**
 * Generates a random ID
 * @param length - Length of the ID
 * @returns Random ID string
 */
export function generateId(length: number = 8): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

/**
 * Checks if device is mobile
 * @returns True if mobile device
 */
export function isMobile(): boolean {
  return window.innerWidth < 768;
}

/**
 * Formats relative time (e.g., "2 hours ago")
 * @param date - Date to format
 * @returns Relative time string
 */
export function formatRelativeTime(date: Date | string): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - dateObj.getTime()) / 1000);

  const intervals = [
    { label: 'ano', seconds: 31536000 },
    { label: 'mês', seconds: 2592000 },
    { label: 'semana', seconds: 604800 },
    { label: 'dia', seconds: 86400 },
    { label: 'hora', seconds: 3600 },
    { label: 'minuto', seconds: 60 },
  ];

  for (const interval of intervals) {
    const count = Math.floor(diffInSeconds / interval.seconds);
    if (count > 0) {
      return `${count} ${interval.label}${count > 1 ? 's' : ''} atrás`;
    }
  }

  return 'agora mesmo';
}

/**
 * Calculate Orixá based on birth date using traditional Afro-Brazilian methods
 * @param birthDate - Date in YYYY-MM-DD format
 * @returns Orixá name
 */
export function calculateOrixaByBirthDate(birthDate: string): string {
  const date = new Date(birthDate);
  const day = date.getDate();
  const month = date.getMonth() + 1;
  
  // Traditional calculation: day + month, then modulo 7 for the 7 main Orixás
  const sum = day + month;
  const orixaIndex = sum % 7;
  
  const orixas = ['Exú', 'Iemanjá', 'Oxalá', 'Iansã', 'Xangô', 'Oxóssi', 'Ogum'];
  return orixas[orixaIndex];
}