import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User as FirebaseUser, onAuthStateChanged } from 'firebase/auth';
import { auth, handleRedirectResult, signOutUser } from './firebase';
import { useToast } from '@/hooks/use-toast';

interface FirebaseAuthContextType {
  user: FirebaseUser | null;
  loading: boolean;
  isAuthenticated: boolean;
  error: string | null;
  signOut: () => Promise<void>;
  clearError: () => void;
}

const FirebaseAuthContext = createContext<FirebaseAuthContextType>({
  user: null,
  loading: true,
  isAuthenticated: false,
  error: null,
  signOut: async () => {},
  clearError: () => {},
});

export function FirebaseAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    let mounted = true;

    // Handle redirect result on app load
    const handleRedirect = async () => {
      try {
        const redirectUser = await handleRedirectResult();
        if (mounted && redirectUser) {
          setUser(redirectUser);
          toast({
            title: "Login realizado com sucesso!",
            description: `Bem-vindo, ${redirectUser.displayName || redirectUser.email}`,
          });
        }
      } catch (error) {
        if (mounted) {
          const errorMessage = error instanceof Error ? error.message : 'Erro no login';
          setError(errorMessage);
          toast({
            title: "Erro no login",
            description: errorMessage,
            variant: "destructive",
          });
        }
      }
    };

    handleRedirect();

    // Listen for auth state changes
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      if (mounted) {
        setUser(firebaseUser);
        setLoading(false);
        
        // Clear any previous errors when auth state changes
        if (firebaseUser) {
          setError(null);
        }
      }
    });

    return () => {
      mounted = false;
      unsubscribe();
    };
  }, [toast]);

  const handleSignOut = async () => {
    try {
      setLoading(true);
      await signOutUser();
      setUser(null);
      setError(null);
      toast({
        title: "Logout realizado",
        description: "Você foi desconectado com sucesso.",
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Erro no logout';
      setError(errorMessage);
      toast({
        title: "Erro no logout",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const clearError = () => {
    setError(null);
  };

  const value = {
    user,
    loading,
    isAuthenticated: !!user,
    error,
    signOut: handleSignOut,
    clearError,
  };

  return (
    <FirebaseAuthContext.Provider value={value}>
      {children}
    </FirebaseAuthContext.Provider>
  );
}

export function useFirebaseAuth() {
  const context = useContext(FirebaseAuthContext);
  if (!context) {
    throw new Error('useFirebaseAuth must be used within a FirebaseAuthProvider');
  }
  return context;
}