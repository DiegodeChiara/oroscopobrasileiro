import { initializeApp, getApps, getApp } from "firebase/app";
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup,
  signOut,
  User as FirebaseUser,
  AuthError,
  onAuthStateChanged
} from "firebase/auth";

// Simple Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCSZvOxQrpQOWoaQ_L8pL_Y8Qr8QWoaQWo", // Replace with actual
  authDomain: "oraculo-brasileiro.firebaseapp.com",
  projectId: "oraculo-brasileiro",
  storageBucket: "oraculo-brasileiro.appspot.com",
  messagingSenderId: "158420217558",
  appId: "1:158420217558:web:3f7ef53efa2f737ec76377",
  measurementId: "G-FJ5CDNFZDC"
};

// Initialize Firebase
let app;
try {
  app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
} catch (error) {
  console.error("Firebase initialization error:", error);
  // Fallback configuration
  app = initializeApp({
    apiKey: "demo-key",
    authDomain: "demo.firebaseapp.com",
    projectId: "demo-project"
  });
}

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Configure Google provider
googleProvider.addScope('email');
googleProvider.addScope('profile');

// Simple Google sign-in
export const signInWithGoogle = async (): Promise<FirebaseUser> => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error) {
    const authError = error as AuthError;
    console.error("Google sign-in error:", authError);
    
    let message = "Erro no login com Google";
    if (authError.code === 'auth/popup-closed-by-user') {
      message = "Login cancelado pelo usuário";
    } else if (authError.code === 'auth/popup-blocked') {
      message = "Pop-up bloqueado. Permita pop-ups e tente novamente.";
    }
    
    throw new Error(message);
  }
};

// Simple sign out
export const signOutUser = async (): Promise<void> => {
  try {
    await signOut(auth);
  } catch (error) {
    console.error("Sign out error:", error);
    throw new Error("Erro ao fazer logout");
  }
};

// Auth state observer
export const onAuthStateChange = (callback: (user: FirebaseUser | null) => void) => {
  return onAuthStateChanged(auth, callback);
};

export default {
  signInWithGoogle,
  signOutUser,
  onAuthStateChange,
  auth
};