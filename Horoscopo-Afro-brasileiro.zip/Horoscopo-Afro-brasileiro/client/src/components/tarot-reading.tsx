import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Star, Moon, Sun, Eye, RotateCcw, Sparkles } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";

interface TarotReadingProps {
  isPremium: boolean;
}

export default function TarotReading({ isPremium }: TarotReadingProps) {
  const [currentReading, setCurrentReading] = useState(null);
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const createReadingMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/tarot/reading", {});
      return response.json();
    },
    onSuccess: (data) => {
      setCurrentReading(data);
      queryClient.invalidateQueries({ queryKey: ["/api/tarot/readings"] });
      toast({
        title: "Leitura realizada!",
        description: "As cartas revelaram seus segredos.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro na leitura",
        description: error.message || "Não foi possível realizar a leitura",
        variant: "destructive",
      });
    },
  });

  const handleNewReading = () => {
    createReadingMutation.mutate();
  };

  const cardIcons = [Sun, Moon, Star];

  return (
    <div className="card-mystical">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Sparkles className="h-6 w-6 text-purple-500 float" />
            <Star className="h-3 w-3 text-yellow-400 absolute -top-1 -right-1 pulse-soft" />
          </div>
          <h3 className="text-xl font-spiritual font-semibold text-purple-700">
            Leitura de Tarô
          </h3>
        </div>
        <div className="px-3 py-1 rounded-full text-xs font-spiritual font-medium mystical-gradient text-white">
          {isPremium ? "Ilimitado" : "Tiragem Grátis"}
        </div>
      </div>
      
      {/* Tarot Cards Display */}
      <div className="flex justify-center gap-4 mb-6">
        {[0, 1, 2].map((index) => {
          const IconComponent = cardIcons[index];
          return (
            <div key={index} className="relative transform hover:scale-105 transition-all duration-300 group">
              <div className="w-18 h-28 rounded-2xl mystical-gradient flex items-center justify-center shadow-lg celestial-glow group-hover:shadow-xl transition-all duration-300">
                <IconComponent className="text-white text-2xl pulse-soft" />
              </div>
              <div className="absolute -bottom-3 left-1/2 transform -translate-x-1/2 px-3 py-1 rounded-full text-xs font-spiritual font-medium"
                style={{
                  background: 'hsla(0, 0%, 100%, 0.9)',
                  backdropFilter: 'blur(10px)',
                  border: '1px solid hsla(265, 35%, 70%, 0.2)'
                }}>
                <span className="text-purple-700">
                  {index === 0 ? "Passado" : index === 1 ? "Presente" : "Futuro"}
                </span>
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="text-center space-y-6">
        {currentReading ? (
          <p className="text-purple-700 leading-relaxed font-spiritual">
            {currentReading.interpretation}
          </p>
        ) : (
          <p className="text-purple-700 leading-relaxed font-spiritual">
            Clique em "Nova Tiragem" para consultar as cartas e descobrir o que o universo tem a dizer sobre seu caminho.
          </p>
        )}
        
        <div className="flex gap-3 justify-center">
          <Button 
            onClick={() => setLocation('/tarot')}
            className="btn-mystical"
          >
            <Eye className="w-4 h-4 mr-2" />
            Ver Interpretação Completa
          </Button>
          <Button 
            onClick={handleNewReading}
            disabled={createReadingMutation.isPending}
            className="btn-secondary-mystical"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            {createReadingMutation.isPending ? "Consultando..." : "Nova Tiragem"}
          </Button>
        </div>
      </div>
    </div>
  );
}
