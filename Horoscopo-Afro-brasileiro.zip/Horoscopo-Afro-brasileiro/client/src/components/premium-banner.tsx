import { Button } from "@/components/ui/button";
import { Crown, Check, Sparkles, Star } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

export default function PremiumBanner() {
  const { toast } = useToast();

  const upgradeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/subscription/upgrade", {
        planType: "premium",
        paymentMethod: "credit_card"
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscription"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/profile"] });
      toast({
        title: "Upgrade realizado!",
        description: "Bem-vindo ao Premium! Aproveite todos os benefícios.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro no upgrade",
        description: error.message || "Não foi possível processar o upgrade",
        variant: "destructive",
      });
    },
  });

  const handleUpgrade = () => {
    upgradeMutation.mutate();
  };

  return (
    <div className="card-mystical relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-24 h-24 rounded-full bg-gradient-to-br from-yellow-200/20 to-orange-200/10 -translate-y-12 translate-x-12 float"></div>
      <div className="absolute bottom-0 left-0 w-16 h-16 rounded-full bg-gradient-to-tr from-purple-200/20 to-indigo-200/10 translate-y-8 -translate-x-8 pulse-soft"></div>
      
      <div className="flex items-center justify-between relative z-10">
        <div>
          <div className="flex items-center space-x-3 mb-3">
            <div className="w-12 h-12 rounded-full mystical-gradient flex items-center justify-center celestial-glow">
              <Crown className="w-6 h-6 text-white pulse-soft" />
            </div>
            <div>
              <h3 className="font-spiritual text-lg font-semibold text-purple-700">
                Torne-se Premium
              </h3>
              <p className="text-sm text-purple-600/70 font-mystic">
                Desbloqueie todo o potencial espiritual
              </p>
            </div>
          </div>
          
          <ul className="text-sm space-y-2 font-spiritual">
            <li className="flex items-center text-purple-700">
              <Check className="w-4 h-4 mr-3 text-green-500" />
              Horóscopos detalhados
            </li>
            <li className="flex items-center text-purple-700">
              <Check className="w-4 h-4 mr-3 text-green-500" />
              Leituras ilimitadas
            </li>
            <li className="flex items-center text-purple-700">
              <Check className="w-4 h-4 mr-3 text-green-500" />
              Mapa astral completo
            </li>
          </ul>
        </div>
        
        <div className="text-center space-y-3">
          <div>
            <div className="text-2xl font-spiritual font-bold text-purple-700">R$9,90</div>
            <div className="text-xs text-purple-600/70 font-mystic">/mês</div>
          </div>
          <Button 
            onClick={handleUpgrade}
            disabled={upgradeMutation.isPending}
            className="btn-mystical group"
          >
            <Star className="w-4 h-4 mr-2 group-hover:rotate-12 transition-transform duration-300" />
            {upgradeMutation.isPending ? "Processando..." : "Assinar"}
          </Button>
        </div>
      </div>
      
      {/* Floating sparkles */}
      <Sparkles className="absolute top-3 right-8 w-3 h-3 text-yellow-400 glow-fade" />
      <Star className="absolute bottom-4 left-12 w-2 h-2 text-purple-400 pulse-soft" />
      <div className="absolute top-1/2 right-4 w-1 h-1 rounded-full bg-pink-400/60 float"></div>
    </div>
  );
}
