import { Button } from "@/components/ui/button";
import { Star, Sparkles, Heart, Calendar, Moon } from "lucide-react";
import { useLocation } from "wouter";

export default function QuickActions() {
  const [, setLocation] = useLocation();

  const actions = [
    {
      title: "Mapa Astral",
      description: "Descubra sua personalidade",
      icon: Star,
      gradient: "from-purple-400 to-indigo-500",
      path: "/astral-chart"
    },
    {
      title: "Leitura de Tarô", 
      description: "Consulte as cartas",
      icon: Sparkles,
      gradient: "from-indigo-400 to-purple-500",
      path: "/tarot"
    },
    {
      title: "Compatibilidade",
      description: "Analise relacionamentos", 
      icon: Heart,
      gradient: "from-pink-400 to-rose-500",
      path: "/compatibility"
    },
    {
      title: "Fases Lunares",
      description: "Energia cósmica",
      icon: Moon,
      gradient: "from-blue-400 to-cyan-500", 
      path: "/lunar"
    }
  ];

  return (
    <div className="card-mystical">
      <div className="flex items-center space-x-3 mb-6">
        <div className="relative">
          <Moon className="h-6 w-6 text-purple-500 float" />
          <Sparkles className="h-3 w-3 text-yellow-400 absolute -top-1 -right-1 pulse-soft" />
        </div>
        <h3 className="text-xl font-spiritual font-semibold text-purple-700">
          Ações Rápidas
        </h3>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        {actions.map((action) => (
          <Button
            key={action.title}
            onClick={() => setLocation(action.path)}
            variant="ghost"
            className="h-auto p-5 flex flex-col items-center text-center rounded-2xl transition-all duration-300 ease-out hover:scale-105 group"
            style={{
              background: 'hsla(0, 0%, 100%, 0.6)',
              backdropFilter: 'blur(15px)',
              border: '1px solid hsla(265, 35%, 70%, 0.15)'
            }}
          >
            <div className={`w-14 h-14 rounded-full bg-gradient-to-br ${action.gradient} flex items-center justify-center mb-4 group-hover:shadow-lg transition-all duration-300 celestial-glow`}>
              <action.icon className="w-7 h-7 text-white" />
            </div>
            <h4 className="font-spiritual font-semibold text-purple-700 text-sm mb-2">
              {action.title}
            </h4>
            <p className="text-xs text-purple-600/70 font-mystic leading-relaxed">
              {action.description}
            </p>
          </Button>
        ))}
      </div>
    </div>
  );
}
