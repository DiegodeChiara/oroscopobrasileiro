import { Button } from "@/components/ui/button";
import { Home, BookOpen, Star, User, Sparkles, Crown } from "lucide-react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

interface BottomNavigationProps {
  currentTab: string;
}

export default function BottomNavigation({ currentTab }: BottomNavigationProps) {
  const [, setLocation] = useLocation();

  const navItems = [
    {
      id: "home",
      label: "Início",
      icon: Home,
      path: "/"
    },
    {
      id: "spiritual",
      label: "Espiritual",
      icon: Crown,
      path: "/spiritual-profile"
    },
    {
      id: "tarot", 
      label: "Tarô",
      icon: Sparkles,
      path: "/tarot"
    },
    {
      id: "astral",
      label: "Mapa", 
      icon: Star,
      path: "/astral-chart"
    },
    {
      id: "profile",
      label: "Perfil",
      icon: User,
      path: "/profile"
    }
  ];

  return (
    <nav className="nav-mystical px-6 py-4 fixed bottom-0 left-0 right-0 z-40">
      <div className="flex justify-around items-center max-w-lg mx-auto">
        {navItems.map((item) => {
          const isActive = currentTab === item.id;
          return (
            <Button
              key={item.id}
              variant="ghost"
              onClick={() => setLocation(item.path)}
              className={cn(
                "flex flex-col items-center gap-1 p-3 h-auto rounded-2xl transition-all duration-300 ease-out relative",
                isActive
                  ? "text-purple-700 scale-110"
                  : "text-purple-500/70 hover:text-purple-600 hover:scale-105"
              )}
            >
              {isActive && (
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-purple-200/40 to-indigo-200/20 backdrop-blur-sm celestial-glow"></div>
              )}
              <div className="relative z-10 flex flex-col items-center">
                <item.icon className={cn("w-5 h-5 transition-all duration-300", isActive && "pulse-soft")} />
                <span className={cn("text-xs font-spiritual", isActive ? "font-semibold" : "font-medium")}>
                  {item.label}
                </span>
              </div>
              {isActive && (
                <div className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-yellow-400 pulse-soft"></div>
              )}
            </Button>
          );
        })}
      </div>
    </nav>
  );
}
