import type { User } from "@shared/schema";
import { Bell, Crown, Sparkles, Moon, LogOut, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface AppHeaderProps {
  user: User | null;
  isPremium: boolean;
}

export default function AppHeader({ user, isPremium }: AppHeaderProps) {
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  
  const handleLogout = async () => {
    if (isLoggingOut) return;
    
    try {
      setIsLoggingOut(true);
      window.location.href = "/api/logout";
    } catch (error) {
      console.error('Erro ao fazer logout:', error);
      setIsLoggingOut(false);
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Bom dia";
    if (hour < 18) return "Boa tarde";
    return "Boa noite";
  };

  return (
    <header className="glass-header px-6 py-8 relative overflow-hidden">
      <div className="flex justify-between items-start relative z-10">
        <div className="space-y-2">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Moon className="h-6 w-6 text-purple-500 float" />
              <Sparkles className="h-3 w-3 text-yellow-400 absolute -top-1 -right-1 pulse-soft" />
            </div>
            <h1 className="font-spiritual text-2xl font-semibold text-purple-700">
              {getGreeting()}, {user?.firstName || user?.email?.split('@')[0] || 'Visitante'}
            </h1>
          </div>
          <p className="text-purple-600/70 text-sm font-mystic ml-9">
            {user?.zodiacSign ? `${user.zodiacSign} • Energia Espiritual` : 'Bem-vindo ao mundo místico'}
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="relative">
            <Button variant="ghost" size="sm" className="glass-button rounded-xl text-purple-600 hover:text-purple-700 p-2">
              <Bell className="w-5 h-5" />
            </Button>
            <span className="absolute -top-1 -right-1 bg-gradient-to-r from-yellow-400 to-orange-400 text-xs w-4 h-4 rounded-full flex items-center justify-center text-white font-medium glow-fade">
              2
            </span>
          </div>
          {isPremium && (
            <div className="px-4 py-2 rounded-2xl text-xs font-semibold flex items-center gap-2 mystical-gradient text-white celestial-glow">
              <Crown className="w-4 h-4" />
              Premium
            </div>
          )}
          {user && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleLogout}
              disabled={isLoggingOut}
              className="glass-button rounded-xl text-purple-600 hover:text-purple-700 p-2 disabled:opacity-50"
              title={isLoggingOut ? "Saindo..." : "Sair"}
            >
              {isLoggingOut ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <LogOut className="w-5 h-5" />
              )}
            </Button>
          )}
        </div>
      </div>
      
      {/* Decorative mystical elements */}
      <div className="absolute -right-16 -top-16 w-40 h-40 rounded-full bg-gradient-to-br from-purple-200/20 to-indigo-200/10 float"></div>
      <div className="absolute -left-8 -bottom-8 w-24 h-24 rounded-full bg-gradient-to-tr from-yellow-200/15 to-orange-200/10 pulse-soft"></div>
      <div className="absolute top-1/2 right-1/4 w-2 h-2 rounded-full bg-yellow-400/60 pulse-soft"></div>
      <div className="absolute top-1/4 left-1/3 w-1 h-1 rounded-full bg-purple-400/60 glow-fade"></div>
    </header>
  );
}
