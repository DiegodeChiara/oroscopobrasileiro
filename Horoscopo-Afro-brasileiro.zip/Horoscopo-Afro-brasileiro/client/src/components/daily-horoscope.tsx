import { Button } from "@/components/ui/button";
import { Sun, Eye, Star, Sparkles, Heart, Briefcase } from "lucide-react";
import { useLocation } from "wouter";

interface Horoscope {
  id: number;
  zodiacSign: string;
  content: string;
  orixaInfluence?: string;
  loveRating?: number;
  workRating?: number;
  healthRating?: number;
  date: string;
}

interface DailyHoroscopeProps {
  horoscope?: Horoscope;
}

export default function DailyHoroscope({ horoscope }: DailyHoroscopeProps) {
  const [, setLocation] = useLocation();

  const renderStars = (rating?: number) => {
    if (!rating) return Array.from({ length: 3 }, (_, i) => (
      <Star key={i} className="w-3 h-3 text-yellow-400 fill-current" />
    ));
    return Array.from({ length: rating }, (_, i) => (
      <Star key={i} className="w-3 h-3 text-yellow-400 fill-current glow-fade" />
    ));
  };

  if (!horoscope) {
    return (
      <div className="card-mystical text-center">
        <div className="relative mb-6">
          <Sun className="w-16 h-16 text-purple-400 mx-auto float" />
          <Sparkles className="w-6 h-6 text-yellow-400 absolute -top-2 -right-2 pulse-soft" />
        </div>
        <h3 className="text-lg font-spiritual font-semibold text-purple-700 mb-3">
          Carregando horóscopo...
        </h3>
        <p className="text-purple-600/70 font-mystic">
          Consultando as energias cósmicas para você
        </p>
      </div>
    );
  }

  return (
    <div className="card-mystical">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Sun className="w-6 h-6 text-purple-500 float" />
            <Sparkles className="w-3 h-3 text-yellow-400 absolute -top-1 -right-1 pulse-soft" />
          </div>
          <h2 className="text-xl font-spiritual font-semibold text-purple-700">
            Seu Horóscopo Hoje
          </h2>
        </div>
        <div className="px-3 py-1 rounded-full text-xs font-spiritual font-medium mystical-gradient text-white">
          {new Date(horoscope.date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}
        </div>
      </div>
      
      <div className="space-y-5">
        {horoscope.orixaInfluence && (
          <div className="flex items-center gap-4 p-4 rounded-2xl bg-gradient-to-r from-purple-100/40 to-indigo-100/20 backdrop-blur-sm">
            <div className="w-12 h-12 rounded-full mystical-gradient flex items-center justify-center celestial-glow">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="font-spiritual font-semibold text-purple-700">
                Influência de {horoscope.orixaInfluence}
              </p>
              <p className="text-sm text-purple-600/70 font-mystic">
                Energia de transformação e sabedoria
              </p>
            </div>
          </div>
        )}
        
        <p className="text-purple-700 leading-relaxed font-spiritual">
          {horoscope.content}
        </p>
        
        <div className="flex justify-between items-center pt-4">
          <div className="flex gap-3 flex-wrap">
            {horoscope.loveRating && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-pink-100/40 backdrop-blur-sm">
                <Heart className="w-4 h-4 text-pink-500" />
                <span className="text-xs font-spiritual font-medium text-pink-700">Amor:</span>
                <div className="flex space-x-1">{renderStars(horoscope.loveRating)}</div>
              </div>
            )}
            {horoscope.workRating && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-blue-100/40 backdrop-blur-sm">
                <Briefcase className="w-4 h-4 text-blue-500" />
                <span className="text-xs font-spiritual font-medium text-blue-700">Trabalho:</span>
                <div className="flex space-x-1">{renderStars(horoscope.workRating)}</div>
              </div>
            )}
          </div>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setLocation('/astral-chart')}
            className="btn-secondary-mystical"
          >
            <Eye className="w-4 h-4 mr-2" />
            Ver detalhes
          </Button>
        </div>
      </div>
    </div>
  );
}
