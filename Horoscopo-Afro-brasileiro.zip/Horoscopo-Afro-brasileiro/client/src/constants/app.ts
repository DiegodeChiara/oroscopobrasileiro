/**
 * Application constants and configuration
 * Centralized constants for better maintainability and consistency
 */

// App Configuration
export const APP_CONFIG = {
  name: 'Universo Místico',
  version: '1.0.0',
  description: 'Aplicativo de astrologia e oráculo brasileiro',
  author: 'Universo Místico Team',
} as const;

// API Configuration
export const API_CONFIG = {
  baseUrl: '/api',
  timeout: 30000, // 30 seconds
  retryAttempts: 3,
} as const;

// Routes
export const ROUTES = {
  HOME: '/',
  LOGIN: '/login',
  REGISTER: '/register',
  GOOGLE_LOGIN: '/google-login',
  PROFILE: '/profile',
  ASTRAL_CHART: '/astral-chart',
  TAROT: '/tarot',
  NOT_FOUND: '/404',
} as const;

// Navigation Tabs
export const NAVIGATION_TABS = [
  { id: 'home', label: 'Início', path: ROUTES.HOME },
  { id: 'tarot', label: 'Tarô', path: ROUTES.TAROT },
  { id: 'astral-chart', label: 'Mapa Astral', path: ROUTES.ASTRAL_CHART },
  { id: 'profile', label: 'Perfil', path: ROUTES.PROFILE },
] as const;

// Zodiac Signs
export const ZODIAC_SIGNS = [
  'Áries', 'Touro', 'Gêmeos', 'Câncer',
  'Leão', 'Virgem', 'Libra', 'Escorpião',
  'Sagitário', 'Capricórnio', 'Aquário', 'Peixes'
] as const;

// Zodiac Sign Details
export const ZODIAC_DETAILS = {
  'Áries': { element: 'Fogo', period: '21/03 - 20/04', ruling: 'Marte' },
  'Touro': { element: 'Terra', period: '21/04 - 21/05', ruling: 'Vênus' },
  'Gêmeos': { element: 'Ar', period: '22/05 - 21/06', ruling: 'Mercúrio' },
  'Câncer': { element: 'Água', period: '22/06 - 23/07', ruling: 'Lua' },
  'Leão': { element: 'Fogo', period: '24/07 - 23/08', ruling: 'Sol' },
  'Virgem': { element: 'Terra', period: '24/08 - 23/09', ruling: 'Mercúrio' },
  'Libra': { element: 'Ar', period: '24/09 - 23/10', ruling: 'Vênus' },
  'Escorpião': { element: 'Água', period: '24/10 - 22/11', ruling: 'Plutão' },
  'Sagitário': { element: 'Fogo', period: '23/11 - 21/12', ruling: 'Júpiter' },
  'Capricórnio': { element: 'Terra', period: '22/12 - 20/01', ruling: 'Saturno' },
  'Aquário': { element: 'Ar', period: '21/01 - 19/02', ruling: 'Urano' },
  'Peixes': { element: 'Água', period: '20/02 - 20/03', ruling: 'Netuno' },
} as const;

// Orixás
export const ORIXAS = [
  'Exú', 'Iemanjá', 'Oxalá', 'Iansã', 
  'Xangô', 'Oxóssi', 'Ogum'
] as const;

// Detailed Orixá information for Spiritual Profile
export const ORIXAS_DETAILS = {
  'Exú': {
    id: 1,
    name: 'Exú',
    description: 'Guardião dos caminhos e comunicação',
    symbol: '🔱',
    day: 'Segunda-feira',
    colors: ['vermelho', 'preto'],
    element: 'Terra',
    domain: ['Caminhos', 'Comunicação', 'Proteção', 'Movimento'],
    characteristics: ['Determinado', 'Protetor', 'Comunicativo', 'Líder'],
    offerings: ['Farofa', 'Cachaça', 'Charuto', 'Velas vermelhas'],
    prayer: 'Salve Exú, guardião dos meus caminhos, abra as portas da prosperidade.',
    compatibility: ['Ogum', 'Iansã'],
    spiritualMessage: 'Seus caminhos estão se abrindo. Mantenha a determinação e proteja suas conquistas.'
  },
  'Iemanjá': {
    id: 2,
    name: 'Iemanjá',
    description: 'Mãe das águas e protetora maternal',
    symbol: '🌊',
    day: 'Sábado',
    colors: ['azul', 'branco'],
    element: 'Água',
    domain: ['Maternidade', 'Proteção', 'Fertilidade', 'Amor'],
    characteristics: ['Maternal', 'Protetora', 'Amorosa', 'Sábia'],
    offerings: ['Flores brancas', 'Perfume', 'Espelho', 'Melão'],
    prayer: 'Salve Iemanjá, mãe querida, proteja minha família com seu amor infinito.',
    compatibility: ['Oxalá', 'Oxóssi'],
    spiritualMessage: 'O amor maternal do universo a protege. Confie na sua intuição e cuide dos que ama.'
  },
  'Oxalá': {
    id: 3,
    name: 'Oxalá',
    description: 'Pai supremo, criador da humanidade',
    symbol: '☀️',
    day: 'Sexta-feira',
    colors: ['branco'],
    element: 'Ar',
    domain: ['Criação', 'Paz', 'Sabedoria', 'Purificação'],
    characteristics: ['Sábio', 'Pacífico', 'Criativo', 'Espiritual'],
    offerings: ['Canjica branca', 'Velas brancas', 'Flores brancas', 'Água'],
    prayer: 'Salve Oxalá, pai criador, ilumine meu caminho com sua sabedoria divina.',
    compatibility: ['Iemanjá', 'Xangô'],
    spiritualMessage: 'A paz interior é sua força. Busque a harmonia e compartilhe sua sabedoria.'
  },
  'Iansã': {
    id: 4,
    name: 'Iansã',
    description: 'Senhora dos ventos e das tempestades',
    symbol: '🌪️',
    day: 'Quarta-feira',
    colors: ['amarelo', 'coral'],
    element: 'Ar',
    domain: ['Ventos', 'Mudanças', 'Justiça', 'Liberdade'],
    characteristics: ['Independente', 'Corajosa', 'Justa', 'Transformadora'],
    offerings: ['Acarajé', 'Vinho tinto', 'Flores amarelas', 'Perfume'],
    prayer: 'Salve Iansã, senhora dos ventos, traga as mudanças que preciso em minha vida.',
    compatibility: ['Exú', 'Ogum'],
    spiritualMessage: 'Ventos de mudança sopram a seu favor. Tenha coragem para aceitar as transformações.'
  },
  'Xangô': {
    id: 5,
    name: 'Xangô',
    description: 'Rei da justiça e do fogo',
    symbol: '⚡',
    day: 'Quarta-feira',
    colors: ['vermelho', 'branco'],
    element: 'Fogo',
    domain: ['Justiça', 'Poder', 'Liderança', 'Conhecimento'],
    characteristics: ['Justo', 'Poderoso', 'Inteligente', 'Carismático'],
    offerings: ['Quiabo', 'Amalá', 'Cerveja branca', 'Velas vermelhas'],
    prayer: 'Salve Xangô, rei da justiça, que sua força me guie nas decisões importantes.',
    compatibility: ['Oxalá', 'Iansã'],
    spiritualMessage: 'A justiça está do seu lado. Use seu poder com sabedoria e lidere pelo exemplo.'
  },
  'Oxóssi': {
    id: 6,
    name: 'Oxóssi',
    description: 'Caçador divino, senhor das matas',
    symbol: '🏹',
    day: 'Quinta-feira',
    colors: ['verde', 'azul'],
    element: 'Terra',
    domain: ['Caça', 'Fartura', 'Conhecimento', 'Proteção'],
    characteristics: ['Focado', 'Habilidoso', 'Provedor', 'Conhecedor'],
    offerings: ['Frutas', 'Mel', 'Cerveja', 'Flores do campo'],
    prayer: 'Salve Oxóssi, grande caçador, guie minha busca pelo sucesso e abundância.',
    compatibility: ['Iemanjá', 'Ogum'],
    spiritualMessage: 'Sua pontaria está certeira. Foque em seus objetivos e a abundância virá.'
  },
  'Ogum': {
    id: 7,
    name: 'Ogum',
    description: 'Guerreiro divino, senhor do ferro',
    symbol: '⚔️',
    day: 'Terça-feira',
    colors: ['azul', 'vermelho'],
    element: 'Ferro',
    domain: ['Guerra', 'Trabalho', 'Tecnologia', 'Caminhos'],
    characteristics: ['Guerreiro', 'Trabalhador', 'Corajoso', 'Determinado'],
    offerings: ['Feijão fradinho', 'Cerveja', 'Charuto', 'Azeite de dendê'],
    prayer: 'Salve Ogum, guerreiro divino, me dê força para vencer todos os obstáculos.',
    compatibility: ['Exú', 'Oxóssi'],
    spiritualMessage: 'Sua força interior é invencível. Trabalhe com determinação e vença suas batalhas.'
  }
} as const;

// Subscription Plans
export const SUBSCRIPTION_PLANS = {
  BASIC: {
    id: 'basic',
    name: 'Básico',
    price: 0,
    features: ['3 leituras de tarô gratuitas', 'Horóscopo diário básico'],
  },
  PREMIUM: {
    id: 'premium',
    name: 'Premium',
    price: 9.90,
    features: [
      'Leituras ilimitadas de tarô',
      'Horóscopo detalhado',
      'Mapa astral completo',
      'Consultas com orixás',
      'Suporte prioritário'
    ],
  },
} as const;

// Theme Colors (CSS Custom Properties)
export const THEME_COLORS = {
  // Primary Colors
  primary: {
    purple: 'hsl(265, 35%, 60%)',
    indigo: 'hsl(240, 35%, 55%)',
    blue: 'hsl(220, 35%, 50%)',
  },
  // Secondary Colors
  secondary: {
    green: 'hsl(80, 25%, 45%)',
    beige: 'hsl(45, 20%, 85%)',
    gold: 'hsl(45, 60%, 70%)',
  },
  // Semantic Colors
  semantic: {
    success: 'hsl(120, 50%, 50%)',
    warning: 'hsl(40, 80%, 60%)',
    error: 'hsl(0, 65%, 55%)',
    info: 'hsl(200, 70%, 60%)',
  },
} as const;

// Animation Durations
export const ANIMATIONS = {
  fast: 200,
  normal: 300,
  slow: 500,
  slower: 800,
} as const;

// Breakpoints (for responsive design)
export const BREAKPOINTS = {
  sm: 640,
  md: 768,
  lg: 1024,
  xl: 1280,
  '2xl': 1536,
} as const;

// Storage Keys
export const STORAGE_KEYS = {
  AUTH_TOKEN: 'auth_token',
  USER_DATA: 'user_data',
  THEME: 'theme_preference',
  LANGUAGE: 'language_preference',
  SPIRITUAL_PROFILE: 'spiritual_profile',
  CUSTOM_ORIXA: 'custom_orixa',
} as const;

// Error Messages
export const ERROR_MESSAGES = {
  NETWORK_ERROR: 'Erro de conexão. Verifique sua internet.',
  UNAUTHORIZED: 'Acesso não autorizado. Faça login novamente.',
  FORBIDDEN: 'Você não tem permissão para esta ação.',
  NOT_FOUND: 'Recurso não encontrado.',
  SERVER_ERROR: 'Erro interno do servidor. Tente novamente.',
  VALIDATION_ERROR: 'Dados inválidos. Verifique os campos.',
  RATE_LIMIT: 'Muitas tentativas. Aguarde um momento.',
} as const;

// Success Messages
export const SUCCESS_MESSAGES = {
  LOGIN_SUCCESS: 'Login realizado com sucesso!',
  LOGOUT_SUCCESS: 'Logout realizado com sucesso!',
  REGISTER_SUCCESS: 'Cadastro realizado com sucesso!',
  PROFILE_UPDATED: 'Perfil atualizado com sucesso!',
  READING_COMPLETE: 'Leitura realizada com sucesso!',
  SUBSCRIPTION_UPDATED: 'Assinatura atualizada com sucesso!',
} as const;