import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User as FirebaseUser } from 'firebase/auth';
import { signInWithGoogle, signOutUser, onAuthStateChange } from '@/lib/firebase';
import { User } from '@shared/schema';
import { apiRequest } from '@/lib/api';

interface FirebaseAuthContextType {
  firebaseUser: FirebaseUser | null;
  user: User | null;
  loading: boolean;
  isAuthenticated: boolean;
  error: string | null;
  signIn: () => Promise<void>;
  signOut: () => Promise<void>;
  clearError: () => void;
}

const FirebaseAuthContext = createContext<FirebaseAuthContextType | undefined>(undefined);

export function FirebaseAuthProvider({ children }: { children: ReactNode }) {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Create or get user from database
  const syncUserWithDatabase = async (firebaseUser: FirebaseUser) => {
    try {
      const userData = {
        email: firebaseUser.email || '',
        name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Usuário',
      };

      const response = await fetch('/api/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      });

      const dbUser = await response.json();
      setUser(dbUser);
    } catch (error) {
      console.error('Erro ao sincronizar usuário:', error);
      setError('Erro ao sincronizar dados do usuário');
    }
  };

  const signIn = async () => {
    try {
      setLoading(true);
      setError(null);
      const firebaseUser = await signInWithGoogle();
      setFirebaseUser(firebaseUser);
      await syncUserWithDatabase(firebaseUser);
    } catch (error: any) {
      console.error('Erro no login:', error);
      setError(error.message || 'Erro no login');
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    try {
      setError(null);
      await signOutUser();
      setFirebaseUser(null);
      setUser(null);
    } catch (error: any) {
      console.error('Erro no logout:', error);
      setError(error.message || 'Erro no logout');
    }
  };

  const clearError = () => {
    setError(null);
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChange(async (firebaseUser) => {
      setLoading(true);
      setFirebaseUser(firebaseUser);
      
      if (firebaseUser) {
        await syncUserWithDatabase(firebaseUser);
      } else {
        setUser(null);
      }
      
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const value: FirebaseAuthContextType = {
    firebaseUser,
    user,
    loading,
    isAuthenticated: !!firebaseUser && !!user,
    error,
    signIn,
    signOut,
    clearError,
  };

  return (
    <FirebaseAuthContext.Provider value={value}>
      {children}
    </FirebaseAuthContext.Provider>
  );
}

export function useFirebaseAuth() {
  const context = useContext(FirebaseAuthContext);
  if (context === undefined) {
    throw new Error('useFirebaseAuth deve ser usado dentro de um FirebaseAuthProvider');
  }
  return context;
}