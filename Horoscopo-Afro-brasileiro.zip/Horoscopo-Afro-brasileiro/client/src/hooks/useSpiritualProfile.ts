/**
 * Hook for managing spiritual profile data and Orixá selection
 * Handles localStorage persistence and automatic calculations
 */

import { useState, useEffect, useCallback } from 'react';
import { useAuth } from './useAuth';
import { STORAGE_KEYS, ORIXAS_DETAILS } from '@/constants/app';
import { calculateZodiacSign, calculateOrixaByBirthDate } from '@/utils';
import type { OrixaDetails, SpiritualProfile } from '@/types';

interface UseSpiritualProfileReturn {
  spiritualProfile: SpiritualProfile | null;
  currentOrixa: OrixaDetails | null;
  isCalculatedOrixa: boolean;
  setCustomOrixa: (orixaName: string) => void;
  clearCustomOrixa: () => void;
  refreshProfile: () => void;
  isLoading: boolean;
}

/**
 * Hook for managing user's spiritual profile and Orixá selection
 */
export function useSpiritualProfile(): UseSpiritualProfileReturn {
  const { user } = useAuth();
  const [spiritualProfile, setSpiritualProfile] = useState<SpiritualProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  /**
   * Load spiritual profile from localStorage or create new one
   */
  const loadSpiritualProfile = useCallback(() => {
    if (!user || !user.birthDate) {
      setSpiritualProfile(null);
      setIsLoading(false);
      return;
    }

    try {
      // Try to load from localStorage first
      const storedProfile = localStorage.getItem(`${STORAGE_KEYS.SPIRITUAL_PROFILE}_${user.id}`);
      
      if (storedProfile) {
        const parsed = JSON.parse(storedProfile) as SpiritualProfile;
        setSpiritualProfile(parsed);
      } else {
        // Create new profile based on user data
        const zodiacSign = calculateZodiacSign(user.birthDate);
        const calculatedOrixa = calculateOrixaByBirthDate(user.birthDate);
        
        const newProfile: SpiritualProfile = {
          userId: user.id,
          zodiacSign,
          calculatedOrixa,
          selectedOrixa: user.customOrixa || undefined,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        setSpiritualProfile(newProfile);
        saveToLocalStorage(newProfile);
      }
    } catch (error) {
      console.error('Error loading spiritual profile:', error);
      setSpiritualProfile(null);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  /**
   * Save profile to localStorage
   */
  const saveToLocalStorage = useCallback((profile: SpiritualProfile) => {
    if (!user) return;
    
    try {
      localStorage.setItem(
        `${STORAGE_KEYS.SPIRITUAL_PROFILE}_${user.id}`,
        JSON.stringify(profile)
      );
    } catch (error) {
      console.error('Error saving spiritual profile:', error);
    }
  }, [user]);

  /**
   * Set custom Orixá selection
   */
  const setCustomOrixa = useCallback((orixaName: string) => {
    if (!spiritualProfile) return;

    const updatedProfile = {
      ...spiritualProfile,
      selectedOrixa: orixaName,
      updatedAt: new Date().toISOString(),
    };

    setSpiritualProfile(updatedProfile);
    saveToLocalStorage(updatedProfile);

    // Also save to user's custom orixa field if auth is available
    // This will be synced with the server on next profile update
    if (user) {
      const updatedUser = { ...user, customOrixa: orixaName };
      // Note: This will be handled by the auth service in actual implementation
    }
  }, [spiritualProfile, saveToLocalStorage, user]);

  /**
   * Clear custom Orixá selection (revert to calculated)
   */
  const clearCustomOrixa = useCallback(() => {
    if (!spiritualProfile) return;

    const updatedProfile = {
      ...spiritualProfile,
      selectedOrixa: undefined,
      updatedAt: new Date().toISOString(),
    };

    setSpiritualProfile(updatedProfile);
    saveToLocalStorage(updatedProfile);
  }, [spiritualProfile, saveToLocalStorage]);

  /**
   * Refresh profile data
   */
  const refreshProfile = useCallback(() => {
    loadSpiritualProfile();
  }, [loadSpiritualProfile]);

  /**
   * Get current active Orixá (custom selection or calculated)
   */
  const getCurrentOrixa = useCallback((): OrixaDetails | null => {
    if (!spiritualProfile) return null;

    const activeOrixaName = spiritualProfile.selectedOrixa || spiritualProfile.calculatedOrixa;
    return ORIXAS_DETAILS[activeOrixaName as keyof typeof ORIXAS_DETAILS] || null;
  }, [spiritualProfile]);

  /**
   * Check if current Orixá is the calculated one (not custom)
   */
  const getIsCalculatedOrixa = useCallback((): boolean => {
    if (!spiritualProfile) return true;
    return !spiritualProfile.selectedOrixa;
  }, [spiritualProfile]);

  // Load profile on mount and when user changes
  useEffect(() => {
    loadSpiritualProfile();
  }, [loadSpiritualProfile]);

  return {
    spiritualProfile,
    currentOrixa: getCurrentOrixa(),
    isCalculatedOrixa: getIsCalculatedOrixa(),
    setCustomOrixa,
    clearCustomOrixa,
    refreshProfile,
    isLoading,
  };
}

/**
 * Helper hook to get current Orixá name for use in other components
 */
export function useCurrentOrixa(): string | null {
  const { currentOrixa } = useSpiritualProfile();
  return currentOrixa?.name || null;
}

/**
 * Helper hook to get current Orixá details for use in other components
 */
export function useCurrentOrixaDetails(): OrixaDetails | null {
  const { currentOrixa } = useSpiritualProfile();
  return currentOrixa;
}