import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/api";
import { Eye, EyeOff, Star, Moon, Sun, ArrowLeft } from "lucide-react";

const registerSchema = z.object({
  name: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  email: z.string().email("Email inválido"),
  password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
  confirmPassword: z.string(),
  birthDate: z.string().optional(),
  birthTime: z.string().optional(),
  birthLocation: z.string().optional(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Senhas não coincidem",
  path: ["confirmPassword"],
});

type RegisterForm = z.infer<typeof registerSchema>;

export default function Register() {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const { login } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const form = useForm<RegisterForm>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
      birthDate: "",
      birthTime: "",
      birthLocation: "",
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: RegisterForm) => {
      const { confirmPassword, ...registerData } = data;
      const response = await apiRequest("POST", "/api/auth/register", registerData);
      return response.json();
    },
    onSuccess: (data) => {
      login(data.user, data.token);
      toast({
        title: "Conta criada com sucesso!",
        description: "Bem-vindo ao mundo místico do Oráculo Brasileiro.",
      });
      setLocation("/");
    },
    onError: (error: any) => {
      toast({
        title: "Erro no cadastro",
        description: error.message || "Não foi possível criar sua conta",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: RegisterForm) => {
    registerMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-mystical-purple via-purple-600 to-nature-teal flex items-center justify-center p-4">
      {/* Mystical Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-4 h-4 bg-wisdom-gold rounded-full opacity-60 animate-pulse"></div>
        <div className="absolute top-40 right-20 w-6 h-6 bg-white rounded-full opacity-40 animate-pulse delay-1000"></div>
        <div className="absolute bottom-40 left-20 w-3 h-3 bg-wisdom-gold rounded-full opacity-50 animate-pulse delay-500"></div>
        <div className="absolute bottom-60 right-10 w-5 h-5 bg-white rounded-full opacity-30 animate-pulse delay-700"></div>
        
        <Star className="absolute top-32 right-32 w-8 h-8 text-wisdom-gold opacity-60 animate-pulse" />
        <Moon className="absolute bottom-32 left-32 w-6 h-6 text-white opacity-50 animate-pulse delay-300" />
        <Sun className="absolute top-52 left-16 w-7 h-7 text-wisdom-gold opacity-40 animate-pulse delay-600" />
      </div>

      <Card className="w-full max-w-md relative z-10 bg-white/95 backdrop-blur-sm border-0 shadow-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="text-center space-y-4">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation("/login")}
              className="text-gray-600 hover:text-mystical-purple"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
            <div className="w-16 h-16 bg-gradient-to-br from-mystical-purple to-purple-600 rounded-full flex items-center justify-center">
              <Star className="w-8 h-8 text-white" />
            </div>
            <div className="w-16"></div>
          </div>
          <CardTitle className="text-2xl font-playfair text-mystical-purple">
            Criar Conta
          </CardTitle>
          <CardDescription className="text-gray-600">
            Junte-se à nossa comunidade espiritual e descubra os segredos do universo
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-gray-700 font-medium">Nome completo</Label>
              <Input
                id="name"
                type="text"
                placeholder="Seu nome"
                className="border-gray-200 focus:border-mystical-purple focus:ring-mystical-purple"
                {...form.register("name")}
              />
              {form.formState.errors.name && (
                <p className="text-sm text-red-600">{form.formState.errors.name.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="text-gray-700 font-medium">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="seu@email.com"
                className="border-gray-200 focus:border-mystical-purple focus:ring-mystical-purple"
                {...form.register("email")}
              />
              {form.formState.errors.email && (
                <p className="text-sm text-red-600">{form.formState.errors.email.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-gray-700 font-medium">Senha</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  className="border-gray-200 focus:border-mystical-purple focus:ring-mystical-purple pr-10"
                  {...form.register("password")}
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {form.formState.errors.password && (
                <p className="text-sm text-red-600">{form.formState.errors.password.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-gray-700 font-medium">Confirmar senha</Label>
              <div className="relative">
                <Input
                  id="confirmPassword"
                  type={showConfirmPassword ? "text" : "password"}
                  placeholder="••••••••"
                  className="border-gray-200 focus:border-mystical-purple focus:ring-mystical-purple pr-10"
                  {...form.register("confirmPassword")}
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {form.formState.errors.confirmPassword && (
                <p className="text-sm text-red-600">{form.formState.errors.confirmPassword.message}</p>
              )}
            </div>

            <div className="pt-4 border-t border-gray-200">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">
                Dados para seu mapa astral (opcional)
              </h3>
              
              <div className="space-y-3">
                <div className="space-y-2">
                  <Label htmlFor="birthDate" className="text-gray-700 text-sm">Data de nascimento</Label>
                  <Input
                    id="birthDate"
                    type="date"
                    className="border-gray-200 focus:border-mystical-purple focus:ring-mystical-purple text-sm"
                    {...form.register("birthDate")}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="birthTime" className="text-gray-700 text-sm">Horário de nascimento</Label>
                  <Input
                    id="birthTime"
                    type="time"
                    className="border-gray-200 focus:border-mystical-purple focus:ring-mystical-purple text-sm"
                    {...form.register("birthTime")}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="birthLocation" className="text-gray-700 text-sm">Local de nascimento</Label>
                  <Input
                    id="birthLocation"
                    type="text"
                    placeholder="Cidade, Estado"
                    className="border-gray-200 focus:border-mystical-purple focus:ring-mystical-purple text-sm"
                    {...form.register("birthLocation")}
                  />
                </div>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-mystical-purple to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white font-semibold py-3 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 mt-6"
              disabled={registerMutation.isPending}
            >
              {registerMutation.isPending ? "Criando conta..." : "Iniciar Jornada Espiritual"}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600 text-sm">
              Já tem uma conta?{" "}
              <button
                onClick={() => setLocation("/login")}
                className="text-mystical-purple hover:text-purple-600 font-semibold transition-colors"
              >
                Fazer login
              </button>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
