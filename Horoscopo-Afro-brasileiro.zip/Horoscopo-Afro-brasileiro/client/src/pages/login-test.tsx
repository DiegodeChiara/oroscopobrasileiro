import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, LogIn, AlertCircle, Star, CheckCircle } from 'lucide-react';
import { useLocation } from 'wouter';

export default function LoginTest() {
  const [, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleMockLogin = async () => {
    setIsLoading(true);
    setError(null);
    setSuccess(null);

    try {
      // Simulate authentication process
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Create mock user data
      const userData = {
        id: 'test-user-123',
        email: 'usuario@exemplo.com',
        name: 'Usuário Teste',
        photoURL: null,
        isPremium: false
      };
      
      // Store in localStorage
      localStorage.setItem('user_data', JSON.stringify(userData));
      localStorage.setItem('auth_token', 'mock-token-123');
      
      setSuccess('Login realizado com sucesso!');
      
      // Redirect after success message
      setTimeout(() => {
        setLocation('/');
      }, 1000);
      
    } catch (error) {
      console.error('Erro no login:', error);
      setError('Erro simulado no login');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('user_data');
    localStorage.removeItem('auth_token');
    setSuccess('Logout realizado com sucesso!');
  };

  const getCurrentUser = () => {
    const userData = localStorage.getItem('user_data');
    return userData ? JSON.parse(userData) : null;
  };

  const currentUser = getCurrentUser();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4">
      <Card className="w-full max-w-md relative z-10 bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full flex items-center justify-center">
              <Star className="w-8 h-8 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-white">
            Sistema de Login - Teste
          </CardTitle>
          <p className="text-purple-200 mt-2">
            Página de teste para demonstrar autenticação
          </p>
        </CardHeader>

        <CardContent className="space-y-6">
          {error && (
            <Alert className="bg-red-500/20 border-red-400 text-red-200">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="bg-green-500/20 border-green-400 text-green-200">
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>{success}</AlertDescription>
            </Alert>
          )}

          {currentUser ? (
            <div className="space-y-4">
              <div className="bg-white/10 rounded-lg p-4">
                <h3 className="text-white font-medium mb-2">Usuário Logado:</h3>
                <p className="text-purple-200 text-sm">Nome: {currentUser.name}</p>
                <p className="text-purple-200 text-sm">Email: {currentUser.email}</p>
                <p className="text-purple-200 text-sm">ID: {currentUser.id}</p>
              </div>
              
              <Button
                onClick={handleLogout}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-medium py-3 rounded-xl"
              >
                Fazer Logout
              </Button>

              <Button
                onClick={() => setLocation('/')}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white font-medium py-3 rounded-xl"
              >
                Ir para Home
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <Button
                onClick={handleMockLogin}
                disabled={isLoading}
                className="w-full bg-white hover:bg-gray-100 text-gray-900 font-medium py-3 rounded-xl transition-all duration-200"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Fazendo Login...
                  </>
                ) : (
                  <>
                    <LogIn className="w-5 h-5 mr-2" />
                    Login de Teste (Mock)
                  </>
                )}
              </Button>

              <div className="text-center text-purple-200 text-sm">
                <p>
                  Esta é uma demonstração do sistema de autenticação.
                  O login criará um usuário temporário para teste.
                </p>
              </div>
            </div>
          )}

          <div className="bg-white/5 rounded-lg p-4 text-center">
            <p className="text-purple-200 text-xs">
              Página de teste - Sistema de autenticação funcional
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}