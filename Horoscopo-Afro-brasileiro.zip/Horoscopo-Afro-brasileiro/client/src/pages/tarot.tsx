import { useAuth } from "@/lib/auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/api";
import { queryClient } from "@/lib/queryClient";
import BottomNavigation from "@/components/bottom-navigation";
import { ArrowLeft, Star, Moon, Sun, Sparkles, History } from "lucide-react";

export default function Tarot() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("reading");
  const [question, setQuestion] = useState("");
  const [currentReading, setCurrentReading] = useState(null);

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);

  const { data: readings } = useQuery({
    queryKey: ["/api/tarot/readings"],
    enabled: isAuthenticated,
  });

  const { data: subscription } = useQuery({
    queryKey: ["/api/subscription"],
    enabled: isAuthenticated,
  });

  const createReadingMutation = useMutation({
    mutationFn: async (data: { question?: string }) => {
      const response = await apiRequest("POST", "/api/tarot/reading", data);
      return response.json();
    },
    onSuccess: (data) => {
      setCurrentReading(data);
      queryClient.invalidateQueries({ queryKey: ["/api/tarot/readings"] });
      toast({
        title: "Leitura realizada!",
        description: "As cartas revelaram seus segredos.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro na leitura",
        description: error.message || "Não foi possível realizar a leitura",
        variant: "destructive",
      });
    },
  });

  const isPremium = subscription?.planType === 'premium' && subscription?.status === 'active';

  const handleNewReading = () => {
    createReadingMutation.mutate({ question: question.trim() || undefined });
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-warm-cream">
      <div className="mobile-app-container bg-white relative overflow-hidden">
        {/* Status Bar */}
        <div className="bg-mystical-purple text-white px-4 py-1 flex justify-between items-center text-xs">
          <span>{new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span>
          <span>Tarô Brasileiro</span>
          <div className="flex gap-1">
            <span>📶</span>
            <span>📶</span>
            <span>🔋</span>
          </div>
        </div>

        {/* Header */}
        <header className="bg-gradient-to-r from-nature-teal to-teal-700 text-white px-6 py-6 relative">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation("/")}
              className="text-white hover:bg-white/20 p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-playfair text-xl font-bold">Leitura de Tarô</h1>
              <p className="text-teal-200 text-sm">Conecte-se com a sabedoria ancestral</p>
            </div>
          </div>
          
          {/* Decorative Elements */}
          <div className="absolute -right-10 -top-10 w-32 h-32 bg-white bg-opacity-10 rounded-full"></div>
          <div className="absolute -left-5 -bottom-5 w-20 h-20 bg-white bg-opacity-5 rounded-full"></div>
        </header>

        {/* Main Content */}
        <main className="px-6 py-6 pb-24 custom-scrollbar overflow-y-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="reading">Nova Leitura</TabsTrigger>
              <TabsTrigger value="history">Histórico</TabsTrigger>
            </TabsList>

            <TabsContent value="reading" className="space-y-6">
              {/* Question Input */}
              <Card className="bg-gradient-to-br from-teal-50 to-teal-100 border-teal-200">
                <CardHeader>
                  <CardTitle className="text-nature-teal font-playfair">Faça sua pergunta</CardTitle>
                  <CardDescription>
                    Concentre-se em uma pergunta específica ou deixe em branco para uma leitura geral
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="question">Sua pergunta (opcional)</Label>
                    <Input
                      id="question"
                      type="text"
                      placeholder="Ex: O que preciso saber sobre minha vida amorosa?"
                      value={question}
                      onChange={(e) => setQuestion(e.target.value)}
                      className="focus:border-nature-teal focus:ring-nature-teal"
                    />
                  </div>
                  
                  <Button
                    onClick={handleNewReading}
                    disabled={createReadingMutation.isPending}
                    className="w-full bg-gradient-to-r from-nature-teal to-teal-600 hover:from-teal-600 hover:to-teal-700"
                  >
                    {createReadingMutation.isPending ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Consultando as cartas...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 mr-2" />
                        Realizar Leitura
                      </>
                    )}
                  </Button>
                  
                  {!isPremium && (
                    <div className="bg-wisdom-gold/20 border border-wisdom-gold/30 rounded-lg p-3">
                      <p className="text-sm text-wisdom-gold font-medium">
                        🎯 Usuários gratuitos: 1 leitura por dia
                      </p>
                      <p className="text-xs text-gray-600 mt-1">
                        Assine o Premium para leituras ilimitadas
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Current Reading */}
              {currentReading && (
                <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
                  <CardHeader>
                    <CardTitle className="text-mystical-purple font-playfair">Sua Leitura</CardTitle>
                    {currentReading.question && (
                      <CardDescription className="font-medium">
                        "{currentReading.question}"
                      </CardDescription>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Cards Display */}
                    <div className="flex justify-center gap-3">
                      {currentReading.cards.map((card, index) => (
                        <div key={index} className="relative transform hover:scale-105 transition-transform duration-300">
                          <div className="w-16 h-24 bg-gradient-to-b from-purple-900 to-purple-800 rounded-lg shadow-lg flex items-center justify-center border-2 border-wisdom-gold">
                            {index === 0 && <Star className="text-wisdom-gold text-xl" />}
                            {index === 1 && <Moon className="text-wisdom-gold text-xl" />}
                            {index === 2 && <Sun className="text-wisdom-gold text-xl" />}
                          </div>
                          <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 bg-white px-2 py-1 rounded-full shadow-md">
                            <span className="text-xs font-semibold text-gray-700">{card.position}</span>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Cards Details */}
                    <div className="space-y-4">
                      {currentReading.cards.map((card, index) => (
                        <div key={index} className="bg-white rounded-lg p-4 shadow-sm">
                          <div className="flex items-start gap-3">
                            <div className="w-10 h-10 bg-mystical-purple rounded-full flex items-center justify-center text-white font-bold">
                              {index + 1}
                            </div>
                            <div className="flex-1">
                              <h4 className="font-semibold text-gray-800">{card.name}</h4>
                              <p className="text-sm text-gray-600 mb-2">{card.position}</p>
                              <p className="text-sm text-gray-700 leading-relaxed">
                                {card.reversed ? card.reversedMeaning : card.uprightMeaning}
                              </p>
                              {card.culturalContext && (
                                <div className="mt-2 p-2 bg-green-50 rounded text-sm text-forest-green">
                                  <strong>Sabedoria Ancestral:</strong> {card.culturalContext}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Interpretation */}
                    <div className="bg-white rounded-lg p-4 shadow-sm">
                      <h4 className="font-semibold text-gray-800 mb-2">Interpretação Geral</h4>
                      <p className="text-gray-700 leading-relaxed">{currentReading.interpretation}</p>
                    </div>

                    <div className="text-center text-xs text-gray-500">
                      {new Date(currentReading.createdAt).toLocaleString('pt-BR')}
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="history" className="space-y-6">
              {readings && readings.length > 0 ? (
                <div className="space-y-4">
                  {readings.map((reading) => (
                    <Card key={reading.id} className="bg-gradient-to-br from-gray-50 to-gray-100 border-gray-200">
                      <CardHeader className="pb-3">
                        <div className="flex items-center gap-2">
                          <History className="w-5 h-5 text-gray-600" />
                          <CardTitle className="text-sm font-medium text-gray-700">
                            {reading.question || "Leitura Geral"}
                          </CardTitle>
                        </div>
                        <CardDescription className="text-xs">
                          {new Date(reading.createdAt).toLocaleString('pt-BR')}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <p className="text-sm text-gray-600 line-clamp-2">
                              {reading.interpretation}
                            </p>
                            <div className="flex gap-1 mt-2">
                              {reading.cards.map((card, index) => (
                                <div key={index} className="w-6 h-8 bg-mystical-purple rounded text-xs text-white flex items-center justify-center">
                                  {index + 1}
                                </div>
                              ))}
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setCurrentReading(reading)}
                            className="text-mystical-purple hover:text-purple-600"
                          >
                            Ver detalhes
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="p-6 text-center">
                    <History className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-700 mb-2">Nenhuma leitura encontrada</h3>
                    <p className="text-gray-600 mb-4">
                      Faça sua primeira leitura de tarô para começar sua jornada espiritual
                    </p>
                    <Button onClick={() => setActiveTab("reading")} className="bg-nature-teal hover:bg-teal-600">
                      Nova Leitura
                    </Button>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </main>

        <BottomNavigation currentTab="readings" />
      </div>
    </div>
  );
}
