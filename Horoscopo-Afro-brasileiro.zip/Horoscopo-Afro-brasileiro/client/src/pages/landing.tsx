import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useFirebaseAuth } from "@/contexts/FirebaseAuthContext";
import { Sparkles, Star, Moon, Sun } from "lucide-react";

export default function Landing() {
  const { signIn, loading, error, clearError } = useFirebaseAuth();

  const handleLogin = async () => {
    if (error) clearError();
    await signIn();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <div className="flex justify-center mb-6">
            <Sparkles className="h-16 w-16 text-yellow-400" />
          </div>
          <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-yellow-400 to-purple-400 bg-clip-text text-transparent">
            Universo Místico
          </h1>
          <p className="text-xl text-purple-200 max-w-2xl mx-auto">
            Descubra os segredos do universo através da astrologia, tarot e espiritualidade afro-brasileira.
            Conecte-se com as energias cósmicas e encontre seu caminho espiritual.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <Card className="bg-white/10 backdrop-blur border-white/20">
            <CardHeader className="text-center">
              <Sun className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
              <CardTitle className="text-white">Horóscopo Diário</CardTitle>
              <CardDescription className="text-purple-200">
                Previsões personalizadas baseadas em seu signo e influências dos orixás
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-white/10 backdrop-blur border-white/20">
            <CardHeader className="text-center">
              <Star className="h-12 w-12 text-purple-400 mx-auto mb-4" />
              <CardTitle className="text-white">Leitura de Tarot</CardTitle>
              <CardDescription className="text-purple-200">
                Consulte as cartas para obter insights sobre amor, trabalho e espiritualidade
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-white/10 backdrop-blur border-white/20">
            <CardHeader className="text-center">
              <Moon className="h-12 w-12 text-blue-400 mx-auto mb-4" />
              <CardTitle className="text-white">Orixás e Espiritualidade</CardTitle>
              <CardDescription className="text-purple-200">
                Descubra seu orixá protetor e aprenda sobre a rica tradição afro-brasileira
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        <div className="text-center">
          <Card className="bg-white/10 backdrop-blur border-white/20 max-w-md mx-auto">
            <CardHeader>
              <CardTitle className="text-white">Entre agora</CardTitle>
              <CardDescription className="text-purple-200">
                Faça login com sua conta Google para começar sua jornada espiritual
              </CardDescription>
            </CardHeader>
            <CardContent>
              {error && (
                <div className="mb-4 p-3 bg-red-500/20 border border-red-500/30 rounded-md text-red-200 text-sm">
                  {error}
                </div>
              )}
              <Button 
                onClick={handleLogin} 
                disabled={loading}
                size="lg"
                className="w-full bg-white text-purple-900 hover:bg-purple-50"
              >
                {loading ? 'Conectando...' : 'Entrar com Google'}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}