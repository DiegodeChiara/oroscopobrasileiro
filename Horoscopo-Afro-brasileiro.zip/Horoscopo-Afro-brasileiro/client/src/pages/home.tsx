import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useEffect } from "react";
import AppHeader from "@/components/app-header";
import DailyHoroscope from "@/components/daily-horoscope";
import TarotReading from "@/components/tarot-reading";
import QuickActions from "@/components/quick-actions";
import PremiumBanner from "@/components/premium-banner";
import BottomNavigation from "@/components/bottom-navigation";
import { useCurrentOrixaDetails } from "@/hooks/useSpiritualProfile";
import { Button } from "@/components/ui/button";
import { Sparkles, Crown } from "lucide-react";
import type { User, Subscription, Horoscope } from "@shared/schema";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  const { data: horoscope } = useQuery<Horoscope>({
    queryKey: ["/api/horoscope/daily"],
    enabled: isAuthenticated,
  });

  const { data: subscription } = useQuery<Subscription>({
    queryKey: ["/api/subscription"],
    enabled: isAuthenticated,
  });

  if (!isAuthenticated || !user) {
    return null;
  }

  const isPremium = subscription?.planType === 'premium' && subscription?.status === 'active';

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Mystical background elements */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-20 left-10 w-32 h-32 rounded-full bg-gradient-to-br from-purple-200/20 to-indigo-200/10 float"></div>
        <div className="absolute top-1/3 right-5 w-20 h-20 rounded-full bg-gradient-to-tr from-yellow-200/15 to-orange-200/10 pulse-soft"></div>
        <div className="absolute bottom-1/3 left-5 w-24 h-24 rounded-full bg-gradient-to-bl from-blue-200/20 to-cyan-200/10 glow-fade"></div>
        <div className="absolute top-1/2 left-1/2 w-2 h-2 rounded-full bg-yellow-400/60 pulse-soft"></div>
        <div className="absolute top-1/4 right-1/4 w-1 h-1 rounded-full bg-purple-400/60 glow-fade"></div>
        <div className="absolute bottom-1/4 left-1/3 w-1.5 h-1.5 rounded-full bg-pink-400/50 float"></div>
      </div>

      <AppHeader user={user} isPremium={isPremium} />

      {/* Main Content */}
      <main className="px-6 py-8 space-y-8 relative z-10 pb-28 max-w-lg mx-auto">
        <DailyHoroscope horoscope={horoscope} />
        <TarotReading isPremium={isPremium} />
        <QuickActions />
        {!isPremium && <PremiumBanner />}
      </main>

      <BottomNavigation currentTab="home" />

      {/* Floating Action Button for Quick Reading */}
      <Button
        className="fixed bottom-28 right-6 w-16 h-16 rounded-full shadow-lg transition-all duration-300 ease-out hover:scale-110 celestial-glow mystical-gradient"
        onClick={() => setLocation('/tarot')}
      >
        <Sparkles className="w-6 h-6 text-white pulse-soft" />
      </Button>
    </div>
  );
}
