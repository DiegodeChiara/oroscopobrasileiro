import { useAuth } from "@/lib/auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/api";
import { queryClient } from "@/lib/queryClient";
import BottomNavigation from "@/components/bottom-navigation";
import { ArrowLeft, User, Crown, Calendar, LogOut, Settings } from "lucide-react";

const profileSchema = z.object({
  name: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  email: z.string().email("Email inválido"),
  birthDate: z.string().optional(),
  birthTime: z.string().optional(),
  birthLocation: z.string().optional(),
});

type ProfileForm = z.infer<typeof profileSchema>;

export default function Profile() {
  const { user, isAuthenticated, logout, updateUser } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);

  const { data: profile } = useQuery({
    queryKey: ["/api/user/profile"],
    enabled: isAuthenticated,
  });

  const { data: subscription } = useQuery({
    queryKey: ["/api/subscription"],
    enabled: isAuthenticated,
  });

  const { data: interactions } = useQuery({
    queryKey: ["/api/user/interactions"],
    enabled: isAuthenticated,
  });

  const form = useForm<ProfileForm>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: user?.name || "",
      email: user?.email || "",
      birthDate: user?.birthDate ? new Date(user.birthDate).toISOString().split('T')[0] : "",
      birthTime: user?.birthTime || "",
      birthLocation: user?.birthLocation || "",
    },
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileForm) => {
      const response = await apiRequest("PUT", "/api/user/profile", data);
      return response.json();
    },
    onSuccess: (data) => {
      updateUser(data.user);
      queryClient.invalidateQueries({ queryKey: ["/api/user/profile"] });
      toast({
        title: "Perfil atualizado!",
        description: "Suas informações foram salvas com sucesso.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao atualizar perfil",
        description: error.message || "Não foi possível salvar as alterações",
        variant: "destructive",
      });
    },
  });

  const handleLogout = () => {
    logout();
    toast({
      title: "Logout realizado",
      description: "Até logo! Volte sempre ao mundo místico.",
    });
    setLocation("/login");
  };

  const onSubmit = (data: ProfileForm) => {
    updateProfileMutation.mutate(data);
  };

  if (!isAuthenticated) {
    return null;
  }

  const isPremium = subscription?.planType === 'premium' && subscription?.status === 'active';

  return (
    <div className="min-h-screen bg-warm-cream">
      <div className="mobile-app-container bg-white relative overflow-hidden">
        {/* Status Bar */}
        <div className="bg-mystical-purple text-white px-4 py-1 flex justify-between items-center text-xs">
          <span>{new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span>
          <span>Perfil</span>
          <div className="flex gap-1">
            <span>📶</span>
            <span>📶</span>
            <span>🔋</span>
          </div>
        </div>

        {/* Header */}
        <header className="bg-gradient-to-r from-mystical-purple to-purple-700 text-white px-6 py-6 relative">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation("/")}
              className="text-white hover:bg-white/20 p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-playfair text-xl font-bold">Meu Perfil</h1>
              <p className="text-purple-200 text-sm">Gerencie suas informações pessoais</p>
            </div>
          </div>
          
          {/* Decorative Elements */}
          <div className="absolute -right-10 -top-10 w-32 h-32 bg-white bg-opacity-10 rounded-full"></div>
          <div className="absolute -left-5 -bottom-5 w-20 h-20 bg-white bg-opacity-5 rounded-full"></div>
        </header>

        {/* Main Content */}
        <main className="px-6 py-6 pb-24 custom-scrollbar overflow-y-auto">
          <Tabs defaultValue="profile" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="profile">Perfil</TabsTrigger>
              <TabsTrigger value="subscription">Assinatura</TabsTrigger>
              <TabsTrigger value="settings">Configurações</TabsTrigger>
            </TabsList>

            <TabsContent value="profile" className="space-y-6">
              {/* User Info Card */}
              <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
                <CardHeader className="text-center">
                  <div className="w-20 h-20 bg-gradient-to-br from-mystical-purple to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <User className="w-10 h-10 text-white" />
                  </div>
                  <CardTitle className="text-mystical-purple font-playfair">{user?.name}</CardTitle>
                  <CardDescription className="flex items-center justify-center gap-2">
                    {user?.zodiacSign && (
                      <>
                        <span>{user.zodiacSign}</span>
                        <span>•</span>
                      </>
                    )}
                    <span>Membro desde {new Date(user?.createdAt || '').toLocaleDateString('pt-BR')}</span>
                  </CardDescription>
                </CardHeader>
              </Card>

              {/* Edit Profile Form */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-mystical-purple font-playfair">Editar Informações</CardTitle>
                  <CardDescription>
                    Mantenha seus dados atualizados para melhor experiência personalizada
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Nome completo</Label>
                      <Input
                        id="name"
                        {...form.register("name")}
                        className="focus:border-mystical-purple focus:ring-mystical-purple"
                      />
                      {form.formState.errors.name && (
                        <p className="text-sm text-red-600">{form.formState.errors.name.message}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        {...form.register("email")}
                        className="focus:border-mystical-purple focus:ring-mystical-purple"
                      />
                      {form.formState.errors.email && (
                        <p className="text-sm text-red-600">{form.formState.errors.email.message}</p>
                      )}
                    </div>

                    <div className="pt-4 border-t border-gray-200">
                      <h3 className="text-sm font-semibold text-gray-700 mb-3">
                        Dados Astrológicos
                      </h3>
                      
                      <div className="space-y-3">
                        <div className="space-y-2">
                          <Label htmlFor="birthDate" className="text-sm">Data de nascimento</Label>
                          <Input
                            id="birthDate"
                            type="date"
                            {...form.register("birthDate")}
                            className="focus:border-mystical-purple focus:ring-mystical-purple"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="birthTime" className="text-sm">Horário de nascimento</Label>
                          <Input
                            id="birthTime"
                            type="time"
                            {...form.register("birthTime")}
                            className="focus:border-mystical-purple focus:ring-mystical-purple"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="birthLocation" className="text-sm">Local de nascimento</Label>
                          <Input
                            id="birthLocation"
                            placeholder="Cidade, Estado"
                            {...form.register("birthLocation")}
                            className="focus:border-mystical-purple focus:ring-mystical-purple"
                          />
                        </div>
                      </div>
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-mystical-purple to-purple-600 hover:from-purple-600 hover:to-purple-700"
                      disabled={updateProfileMutation.isPending}
                    >
                      {updateProfileMutation.isPending ? "Salvando..." : "Salvar Alterações"}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="subscription" className="space-y-6">
              <Card className={`${isPremium ? 'bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200' : 'bg-gradient-to-br from-gray-50 to-gray-100 border-gray-200'}`}>
                <CardHeader>
                  <CardTitle className={`font-playfair flex items-center gap-2 ${isPremium ? 'text-wisdom-gold' : 'text-gray-700'}`}>
                    {isPremium && <Crown className="w-5 h-5" />}
                    Plano {isPremium ? 'Premium' : 'Gratuito'}
                  </CardTitle>
                  <CardDescription>
                    {isPremium 
                      ? "Você tem acesso completo a todos os recursos"
                      : "Atualize para Premium e desbloqueie funcionalidades exclusivas"
                    }
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isPremium ? (
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Status:</span>
                        <span className="text-green-600 font-semibold">Ativo</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Renovação:</span>
                        <span>{subscription?.endDate ? new Date(subscription.endDate).toLocaleDateString('pt-BR') : 'N/A'}</span>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-semibold">Benefícios inclusos:</h4>
                        <ul className="text-sm space-y-1 text-gray-600">
                          <li>✅ Horóscopos detalhados ilimitados</li>
                          <li>✅ Leituras de tarô sem limite</li>
                          <li>✅ Mapa astral completo</li>
                          <li>✅ Análises de compatibilidade</li>
                          <li>✅ Suporte prioritário</li>
                        </ul>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center space-y-4">
                      <p className="text-gray-600">
                        Upgrade para Premium e tenha acesso completo ao mundo místico
                      </p>
                      <Button className="bg-wisdom-gold hover:bg-yellow-500 text-white">
                        Assinar Premium - R$ 9,90/mês
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Usage Stats */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-mystical-purple font-playfair">Estatísticas de Uso</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div className="bg-purple-50 rounded-lg p-4">
                      <div className="text-2xl font-bold text-mystical-purple">
                        {interactions?.filter(i => i.action === 'tarot_reading').length || 0}
                      </div>
                      <div className="text-sm text-gray-600">Leituras de Tarô</div>
                    </div>
                    <div className="bg-teal-50 rounded-lg p-4">
                      <div className="text-2xl font-bold text-nature-teal">
                        {interactions?.filter(i => i.action === 'view_horoscope').length || 0}
                      </div>
                      <div className="text-sm text-gray-600">Horóscopos Lidos</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-mystical-purple font-playfair flex items-center gap-2">
                    <Settings className="w-5 h-5" />
                    Configurações da Conta
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <h4 className="font-semibold">Notificações</h4>
                        <p className="text-sm text-gray-600">Receber lembretes sobre horóscopo diário</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Gerenciar
                      </Button>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <h4 className="font-semibold">Privacidade</h4>
                        <p className="text-sm text-gray-600">Configurações de dados e privacidade</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Editar
                      </Button>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <h4 className="font-semibold">Dados de Backup</h4>
                        <p className="text-sm text-gray-600">Exportar seus dados pessoais</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Exportar
                      </Button>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-gray-200">
                    <Button
                      onClick={handleLogout}
                      variant="destructive"
                      className="w-full flex items-center gap-2"
                    >
                      <LogOut className="w-4 h-4" />
                      Sair da Conta
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>

        <BottomNavigation currentTab="profile" />
      </div>
    </div>
  );
}
