/**
 * Spiritual Profile Page
 * Complete spiritual profile with zodiac, Orixá, daily messages, and oracle readings
 */

import { useState } from 'react';
import { Sparkles, Star, Heart, Moon, Sun, Crown } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useSpiritualProfile } from '@/hooks/useSpiritualProfile';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ORIXAS_DETAILS, ZODIAC_DETAILS } from '@/constants/app';
import { formatDateBR, getTimeGreeting } from '@/utils';
import type { OrixaDetails } from '@/types';

/**
 * Orixá Selection Modal Component
 */
function OrixaSelectionModal({ 
  currentOrixa, 
  onSelect, 
  isOpen, 
  onClose 
}: {
  currentOrixa: OrixaDetails | null;
  onSelect: (orixaName: string) => void;
  isOpen: boolean;
  onClose: () => void;
}) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-center text-2xl font-spiritual text-gradient">
            Escolha seu Orixá
          </DialogTitle>
          <p className="text-center text-muted-foreground">
            Selecione o Orixá que mais ressoa com sua energia espiritual
          </p>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
          {Object.values(ORIXAS_DETAILS).map((orixa) => (
            <div
              key={orixa.id}
              className={`card-mystical cursor-pointer transition-all hover:scale-105 ${
                currentOrixa?.name === orixa.name ? 'ring-2 ring-purple-500' : ''
              }`}
              onClick={() => {
                onSelect(orixa.name);
                onClose();
              }}
            >
              <div className="text-center space-y-3">
                <div className="text-4xl">{orixa.symbol}</div>
                <h3 className="font-spiritual font-semibold text-lg">{orixa.name}</h3>
                <p className="text-sm text-muted-foreground">{orixa.description}</p>
                
                <div className="flex flex-wrap gap-1 justify-center">
                  {orixa.colors.map((color, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {color}
                    </Badge>
                  ))}
                </div>
                
                <div className="text-xs text-muted-foreground">
                  <div>{orixa.element} • {orixa.day}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}

/**
 * Daily Spiritual Message Component
 */
function DailySpiritualMessage({ orixa }: { orixa: OrixaDetails | null }) {
  if (!orixa) return null;

  return (
    <Card className="card-mystical">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Sparkles className="w-5 h-5 text-purple-600" />
          Mensagem Espiritual de {orixa.name}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center p-4 bg-purple-50 rounded-xl">
          <div className="text-3xl mb-2">{orixa.symbol}</div>
          <p className="text-purple-800 font-spiritual italic">
            "{orixa.spiritualMessage}"
          </p>
        </div>
        <div className="text-sm text-muted-foreground text-center">
          {orixa.prayer}
        </div>
      </CardContent>
    </Card>
  );
}

/**
 * Zodiac and Orixá Info Component
 */
function SpiritualInfo({ 
  zodiacSign, 
  orixa, 
  isCalculatedOrixa, 
  onChangeOrixa 
}: {
  zodiacSign: string;
  orixa: OrixaDetails | null;
  isCalculatedOrixa: boolean;
  onChangeOrixa: () => void;
}) {
  const zodiacDetails = ZODIAC_DETAILS[zodiacSign as keyof typeof ZODIAC_DETAILS];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {/* Zodiac Sign Card */}
      <Card className="card-mystical">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-600" />
            Seu Signo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-gradient">{zodiacSign}</h3>
            <p className="text-sm text-muted-foreground">
              {zodiacDetails?.period}
            </p>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="font-medium">Elemento:</span>
              <span>{zodiacDetails?.element}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-medium">Regente:</span>
              <span>{zodiacDetails?.ruling}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Orixá Card */}
      <Card className="card-mystical">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 justify-between">
            <div className="flex items-center gap-2">
              <Crown className="w-5 h-5 text-purple-600" />
              Seu Orixá
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={onChangeOrixa}
              className="glass-element"
            >
              Alterar
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {orixa ? (
            <>
              <div className="text-center">
                <div className="text-4xl mb-2">{orixa.symbol}</div>
                <h3 className="text-2xl font-bold text-gradient">{orixa.name}</h3>
                <p className="text-sm text-muted-foreground">
                  {orixa.description}
                </p>
                {!isCalculatedOrixa && (
                  <Badge variant="secondary" className="mt-2">
                    Personalizado
                  </Badge>
                )}
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="font-medium">Elemento:</span>
                  <span>{orixa.element}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Dia:</span>
                  <span>{orixa.day}</span>
                </div>
              </div>
              <div className="flex flex-wrap gap-1">
                {orixa.colors.map((color, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    {color}
                  </Badge>
                ))}
              </div>
            </>
          ) : (
            <div className="text-center text-muted-foreground">
              Complete seu perfil para descobrir seu Orixá
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

/**
 * Oracle Readings Section
 */
function OracleReadings({ isPremium }: { isPremium: boolean }) {
  const [selectedReading, setSelectedReading] = useState<string | null>(null);

  const readings = [
    {
      id: 'tarot',
      name: 'Tarô dos Orixás',
      description: 'Consulta com as cartas dos Orixás',
      icon: Moon,
      premium: false,
    },
    {
      id: 'runas',
      name: 'Runas Sagradas',
      description: 'Sabedoria ancestral nórdica',
      icon: Crown,
      premium: true,
    },
    {
      id: 'buzios',
      name: 'Jogo de Búzios',
      description: 'Oráculo tradicional afro-brasileiro',
      icon: Sun,
      premium: true,
    },
    {
      id: 'numerology',
      name: 'Numerologia Mística',
      description: 'Revelações através dos números',
      icon: Star,
      premium: false,
    },
  ];

  return (
    <Card className="card-mystical">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Heart className="w-5 h-5 text-red-500" />
          Consultas Espirituais
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {readings.map((reading) => {
            const Icon = reading.icon;
            const isLocked = reading.premium && !isPremium;
            
            return (
              <div
                key={reading.id}
                className={`glass-element p-4 rounded-xl cursor-pointer transition-all ${
                  isLocked ? 'opacity-60' : 'hover:scale-105'
                }`}
                onClick={() => !isLocked && setSelectedReading(reading.id)}
              >
                <div className="text-center space-y-2">
                  <Icon className="w-8 h-8 mx-auto text-purple-600" />
                  <h4 className="font-medium">{reading.name}</h4>
                  <p className="text-xs text-muted-foreground">
                    {reading.description}
                  </p>
                  {isLocked && (
                    <Badge variant="secondary" className="text-xs">
                      Premium
                    </Badge>
                  )}
                </div>
              </div>
            );
          })}
        </div>
        
        {selectedReading && (
          <div className="mt-4 p-4 bg-purple-50 rounded-xl text-center">
            <p className="text-purple-800">
              Consulta "{readings.find(r => r.id === selectedReading)?.name}" selecionada!
            </p>
            <Button className="btn-mystical mt-2" size="sm">
              Iniciar Consulta
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/**
 * Main Spiritual Profile Page Component
 */
export default function SpiritualProfile() {
  const { user } = useAuth();
  const { 
    spiritualProfile, 
    currentOrixa, 
    isCalculatedOrixa, 
    setCustomOrixa, 
    isLoading 
  } = useSpiritualProfile();
  
  const [showOrixaModal, setShowOrixaModal] = useState(false);

  if (isLoading) {
    return (
      <div className="p-6 space-y-6 animate-fade-in">
        <div className="text-center">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-purple-200 rounded w-1/2 mx-auto"></div>
            <div className="h-4 bg-purple-100 rounded w-3/4 mx-auto"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!user || !user.birthDate) {
    return (
      <div className="p-6 text-center space-y-4">
        <div className="text-6xl opacity-60">🔮</div>
        <h2 className="text-2xl font-spiritual text-gradient">
          Complete seu Perfil
        </h2>
        <p className="text-muted-foreground max-w-md mx-auto">
          Para acessar seu perfil espiritual, complete suas informações de nascimento na página de perfil.
        </p>
        <Button className="btn-mystical">
          Ir para Perfil
        </Button>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-spiritual text-gradient">
          {getTimeGreeting()}, {user.name}
        </h1>
        <p className="text-muted-foreground">
          Seu perfil espiritual para {formatDateBR(new Date())}
        </p>
      </div>

      <Separator />

      {/* Spiritual Info Cards */}
      {spiritualProfile && (
        <SpiritualInfo
          zodiacSign={spiritualProfile.zodiacSign}
          orixa={currentOrixa}
          isCalculatedOrixa={isCalculatedOrixa}
          onChangeOrixa={() => setShowOrixaModal(true)}
        />
      )}

      {/* Daily Spiritual Message */}
      <DailySpiritualMessage orixa={currentOrixa} />

      {/* Oracle Readings */}
      <OracleReadings isPremium={user.premiumStatus || false} />

      {/* Orixá Selection Modal */}
      <OrixaSelectionModal
        currentOrixa={currentOrixa}
        onSelect={setCustomOrixa}
        isOpen={showOrixaModal}
        onClose={() => setShowOrixaModal(false)}
      />
    </div>
  );
}