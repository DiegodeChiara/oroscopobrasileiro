import { useAuth } from "@/lib/auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/api";
import { queryClient } from "@/lib/queryClient";
import BottomNavigation from "@/components/bottom-navigation";
import { ArrowLeft, Star, Moon, Sun, MapPin } from "lucide-react";

const astralChartSchema = z.object({
  birthDate: z.string().min(1, "Data de nascimento é obrigatória"),
  birthTime: z.string().min(1, "Horário de nascimento é obrigatório"),
  birthLocation: z.string().min(1, "Local de nascimento é obrigatório"),
  latitude: z.string().optional(),
  longitude: z.string().optional(),
});

type AstralChartForm = z.infer<typeof astralChartSchema>;

export default function AstralChart() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("chart");

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);

  const { data: astralChart, isLoading } = useQuery({
    queryKey: ["/api/astral-chart"],
    enabled: isAuthenticated,
  });

  const form = useForm<AstralChartForm>({
    resolver: zodResolver(astralChartSchema),
    defaultValues: {
      birthDate: "",
      birthTime: "",
      birthLocation: "",
      latitude: "",
      longitude: "",
    },
  });

  const createChartMutation = useMutation({
    mutationFn: async (data: AstralChartForm) => {
      const response = await apiRequest("POST", "/api/astral-chart", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/astral-chart"] });
      toast({
        title: "Mapa astral criado!",
        description: "Seu mapa astral foi calculado com sucesso.",
      });
      setActiveTab("chart");
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao criar mapa astral",
        description: error.message || "Não foi possível criar seu mapa astral",
        variant: "destructive",
      });
    },
  });

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          form.setValue("latitude", position.coords.latitude.toString());
          form.setValue("longitude", position.coords.longitude.toString());
          toast({
            title: "Localização obtida!",
            description: "Coordenadas capturadas com sucesso.",
          });
        },
        (error) => {
          toast({
            title: "Erro de localização",
            description: "Não foi possível obter sua localização.",
            variant: "destructive",
          });
        }
      );
    } else {
      toast({
        title: "Geolocalização não suportada",
        description: "Seu navegador não suporta geolocalização.",
        variant: "destructive",
      });
    }
  };

  const onSubmit = (data: AstralChartForm) => {
    createChartMutation.mutate(data);
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-warm-cream">
      <div className="mobile-app-container bg-white relative overflow-hidden">
        {/* Status Bar */}
        <div className="bg-mystical-purple text-white px-4 py-1 flex justify-between items-center text-xs">
          <span>{new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span>
          <span>Mapa Astral</span>
          <div className="flex gap-1">
            <span>📶</span>
            <span>📶</span>
            <span>🔋</span>
          </div>
        </div>

        {/* Header */}
        <header className="bg-gradient-to-r from-mystical-purple to-purple-700 text-white px-6 py-6 relative">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation("/")}
              className="text-white hover:bg-white/20 p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-playfair text-xl font-bold">Mapa Astral</h1>
              <p className="text-purple-200 text-sm">Descubra os segredos do seu nascimento</p>
            </div>
          </div>
          
          {/* Decorative Elements */}
          <div className="absolute -right-10 -top-10 w-32 h-32 bg-white bg-opacity-10 rounded-full"></div>
          <div className="absolute -left-5 -bottom-5 w-20 h-20 bg-white bg-opacity-5 rounded-full"></div>
        </header>

        {/* Main Content */}
        <main className="px-6 py-6 pb-24 custom-scrollbar overflow-y-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="chart">Meu Mapa</TabsTrigger>
              <TabsTrigger value="create">Criar/Editar</TabsTrigger>
            </TabsList>

            <TabsContent value="chart" className="space-y-6">
              {isLoading ? (
                <Card>
                  <CardContent className="p-6">
                    <div className="text-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-mystical-purple mx-auto"></div>
                      <p className="mt-2 text-gray-600">Carregando mapa astral...</p>
                    </div>
                  </CardContent>
                </Card>
              ) : astralChart ? (
                <div className="space-y-6">
                  {/* Birth Info Card */}
                  <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
                    <CardHeader>
                      <CardTitle className="text-mystical-purple font-playfair">Dados de Nascimento</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-mystical-purple rounded-full flex items-center justify-center">
                          <Star className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <p className="font-semibold">Data: {new Date(astralChart.birthDate).toLocaleDateString('pt-BR')}</p>
                          <p className="text-sm text-gray-600">Horário: {astralChart.birthTime}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-nature-teal rounded-full flex items-center justify-center">
                          <MapPin className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <p className="font-semibold">{astralChart.birthLocation}</p>
                          {astralChart.latitude && astralChart.longitude && (
                            <p className="text-sm text-gray-600">
                              {parseFloat(astralChart.latitude).toFixed(2)}°, {parseFloat(astralChart.longitude).toFixed(2)}°
                            </p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Astrological Signs */}
                  <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
                    <CardHeader>
                      <CardTitle className="text-earth-terra font-playfair">Seus Signos</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 gap-4">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 bg-gradient-to-br from-wisdom-gold to-orange-400 rounded-full flex items-center justify-center">
                            <Sun className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <p className="font-semibold">Sol</p>
                            <p className="text-sm text-gray-600">{astralChart.sunSign || "Calculando..."}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 bg-gradient-to-br from-mystical-purple to-purple-600 rounded-full flex items-center justify-center">
                            <Moon className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <p className="font-semibold">Lua</p>
                            <p className="text-sm text-gray-600">{astralChart.moonSign || "Calculando..."}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 bg-gradient-to-br from-nature-teal to-teal-600 rounded-full flex items-center justify-center">
                            <Star className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <p className="font-semibold">Ascendente</p>
                            <p className="text-sm text-gray-600">{astralChart.risingSign || "Calculando..."}</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Interpretation */}
                  <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
                    <CardHeader>
                      <CardTitle className="text-forest-green font-playfair">Interpretação</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 leading-relaxed">
                        Seu mapa astral revela uma personalidade única, moldada pelas energias cósmicas no momento do seu nascimento. 
                        As posições planetárias influenciam diferentes aspectos da sua vida, desde sua essência interior até como você 
                        se relaciona com o mundo exterior. Esta é uma interpretação básica - para análises mais profundas, 
                        considere uma consulta personalizada.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <Card>
                  <CardContent className="p-6 text-center">
                    <Star className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-700 mb-2">Mapa Astral não encontrado</h3>
                    <p className="text-gray-600 mb-4">
                      Crie seu mapa astral para descobrir os segredos do seu nascimento
                    </p>
                    <Button onClick={() => setActiveTab("create")} className="bg-mystical-purple hover:bg-purple-600">
                      Criar Mapa Astral
                    </Button>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="create" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-mystical-purple font-playfair">
                    {astralChart ? "Editar Mapa Astral" : "Criar Mapa Astral"}
                  </CardTitle>
                  <CardDescription>
                    Forneça seus dados de nascimento para calcular seu mapa astral personalizado
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="birthDate">Data de nascimento</Label>
                      <Input
                        id="birthDate"
                        type="date"
                        {...form.register("birthDate")}
                        className="focus:border-mystical-purple focus:ring-mystical-purple"
                      />
                      {form.formState.errors.birthDate && (
                        <p className="text-sm text-red-600">{form.formState.errors.birthDate.message}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="birthTime">Horário de nascimento</Label>
                      <Input
                        id="birthTime"
                        type="time"
                        {...form.register("birthTime")}
                        className="focus:border-mystical-purple focus:ring-mystical-purple"
                      />
                      {form.formState.errors.birthTime && (
                        <p className="text-sm text-red-600">{form.formState.errors.birthTime.message}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="birthLocation">Local de nascimento</Label>
                      <Input
                        id="birthLocation"
                        type="text"
                        placeholder="Cidade, Estado, País"
                        {...form.register("birthLocation")}
                        className="focus:border-mystical-purple focus:ring-mystical-purple"
                      />
                      {form.formState.errors.birthLocation && (
                        <p className="text-sm text-red-600">{form.formState.errors.birthLocation.message}</p>
                      )}
                    </div>

                    <div className="space-y-4 pt-4 border-t">
                      <div className="flex justify-between items-center">
                        <Label className="text-sm font-medium">Coordenadas (opcional)</Label>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={getCurrentLocation}
                          className="text-mystical-purple border-mystical-purple hover:bg-mystical-purple hover:text-white"
                        >
                          <MapPin className="w-4 h-4 mr-2" />
                          Usar localização atual
                        </Button>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="latitude" className="text-sm">Latitude</Label>
                          <Input
                            id="latitude"
                            type="text"
                            placeholder="Ex: -23.5505"
                            {...form.register("latitude")}
                            className="focus:border-mystical-purple focus:ring-mystical-purple text-sm"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="longitude" className="text-sm">Longitude</Label>
                          <Input
                            id="longitude"
                            type="text"
                            placeholder="Ex: -46.6333"
                            {...form.register("longitude")}
                            className="focus:border-mystical-purple focus:ring-mystical-purple text-sm"
                          />
                        </div>
                      </div>
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-mystical-purple to-purple-600 hover:from-purple-600 hover:to-purple-700"
                      disabled={createChartMutation.isPending}
                    >
                      {createChartMutation.isPending 
                        ? "Calculando mapa astral..." 
                        : astralChart 
                          ? "Atualizar Mapa Astral" 
                          : "Criar Mapa Astral"
                      }
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>

        <BottomNavigation currentTab="astrology" />
      </div>
    </div>
  );
}
