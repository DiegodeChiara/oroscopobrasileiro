import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/api";
import { Eye, EyeOff, Star, Moon, Sun } from "lucide-react";

const loginSchema = z.object({
  email: z.string().email("Email inválido"),
  password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function Login() {
  const [showPassword, setShowPassword] = useState(false);
  const { login } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const form = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const loginMutation = useMutation({
    mutationFn: async (data: LoginForm) => {
      const response = await apiRequest("POST", "/api/auth/login", data);
      return response.json();
    },
    onSuccess: (data) => {
      login(data.user, data.token);
      toast({
        title: "Login realizado com sucesso!",
        description: "Bem-vindo de volta ao mundo místico.",
      });
      setLocation("/");
    },
    onError: (error: any) => {
      toast({
        title: "Erro no login",
        description: error.message || "Credenciais inválidas",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: LoginForm) => {
    loginMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-mystical-purple via-purple-600 to-nature-teal flex items-center justify-center p-4">
      {/* Mystical Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-4 h-4 bg-wisdom-gold rounded-full opacity-60 animate-pulse"></div>
        <div className="absolute top-40 right-20 w-6 h-6 bg-white rounded-full opacity-40 animate-pulse delay-1000"></div>
        <div className="absolute bottom-40 left-20 w-3 h-3 bg-wisdom-gold rounded-full opacity-50 animate-pulse delay-500"></div>
        <div className="absolute bottom-60 right-10 w-5 h-5 bg-white rounded-full opacity-30 animate-pulse delay-700"></div>
        
        <Star className="absolute top-32 right-32 w-8 h-8 text-wisdom-gold opacity-60 animate-pulse" />
        <Moon className="absolute bottom-32 left-32 w-6 h-6 text-white opacity-50 animate-pulse delay-300" />
        <Sun className="absolute top-52 left-16 w-7 h-7 text-wisdom-gold opacity-40 animate-pulse delay-600" />
      </div>

      <Card className="w-full max-w-md relative z-10 bg-white/95 backdrop-blur-sm border-0 shadow-2xl">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto w-20 h-20 bg-gradient-to-br from-mystical-purple to-purple-600 rounded-full flex items-center justify-center mb-4">
            <Star className="w-10 h-10 text-white" />
          </div>
          <CardTitle className="text-2xl font-playfair text-mystical-purple">
            Oráculo Brasileiro
          </CardTitle>
          <CardDescription className="text-gray-600">
            Conecte-se com sua sabedoria interior e descubra os mistérios do seu destino
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-gray-700 font-medium">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="seu@email.com"
                className="border-gray-200 focus:border-mystical-purple focus:ring-mystical-purple"
                {...form.register("email")}
              />
              {form.formState.errors.email && (
                <p className="text-sm text-red-600">{form.formState.errors.email.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-gray-700 font-medium">Senha</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  className="border-gray-200 focus:border-mystical-purple focus:ring-mystical-purple pr-10"
                  {...form.register("password")}
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {form.formState.errors.password && (
                <p className="text-sm text-red-600">{form.formState.errors.password.message}</p>
              )}
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-mystical-purple to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white font-semibold py-3 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
              disabled={loginMutation.isPending}
            >
              {loginMutation.isPending ? "Entrando..." : "Entrar no Mundo Místico"}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600 text-sm">
              Novo por aqui?{" "}
              <button
                onClick={() => setLocation("/register")}
                className="text-mystical-purple hover:text-purple-600 font-semibold transition-colors"
              >
                Criar conta
              </button>
            </p>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="flex items-center justify-center space-x-4 text-sm text-gray-500">
              <div className="flex items-center space-x-1">
                <Star className="w-4 h-4 text-wisdom-gold" />
                <span>Astrologia</span>
              </div>
              <div className="flex items-center space-x-1">
                <Moon className="w-4 h-4 text-mystical-purple" />
                <span>Tarô</span>
              </div>
              <div className="flex items-center space-x-1">
                <Sun className="w-4 h-4 text-nature-teal" />
                <span>Orixás</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
