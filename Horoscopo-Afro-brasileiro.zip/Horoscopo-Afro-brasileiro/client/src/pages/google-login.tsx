import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useFirebaseAuth } from '@/lib/firebase-auth';
import { signInWithGoogle } from '@/lib/firebase';
import { Loader2, LogIn, AlertCircle, Star, Moon, Sun } from 'lucide-react';
import { useLocation } from 'wouter';

export default function GoogleLogin() {
  const [, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { user, loading } = useFirebaseAuth();

  // Redirect if already authenticated
  React.useEffect(() => {
    if (!loading && user) {
      setLocation('/');
    }
  }, [user, loading, setLocation]);

  const handleGoogleLogin = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const firebaseUser = await signInWithGoogle();
      
      if (firebaseUser) {
        // Store user data in localStorage for immediate access
        const userData = {
          id: firebaseUser.uid,
          email: firebaseUser.email,
          name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Usuário',
          photoURL: firebaseUser.photoURL,
          isPremium: false // Default value
        };
        
        localStorage.setItem('user_data', JSON.stringify(userData));
        
        // Redirect to home
        setLocation('/');
      }
    } catch (error) {
      console.error('Erro no login:', error);
      setError(error instanceof Error ? error.message : 'Erro no login com Google');
    } finally {
      setIsLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        <div className="flex items-center space-x-2 text-white">
          <Loader2 className="w-6 h-6 animate-spin" />
          <span>Carregando...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <Star className="absolute top-20 left-20 w-4 h-4 text-yellow-300 animate-pulse" />
        <Moon className="absolute top-40 right-20 w-6 h-6 text-blue-200 animate-bounce" />
        <Sun className="absolute bottom-20 left-40 w-5 h-5 text-orange-300 animate-pulse" />
        <Star className="absolute bottom-40 right-40 w-3 h-3 text-purple-300 animate-ping" />
      </div>

      <Card className="w-full max-w-md relative z-10 bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full flex items-center justify-center">
              <Star className="w-8 h-8 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-white">
            Universo Místico
          </CardTitle>
          <p className="text-purple-200 mt-2">
            Conecte-se com o cosmos e descubra os mistérios do universo
          </p>
        </CardHeader>

        <CardContent className="space-y-6">
          {error && (
            <Alert className="bg-red-500/20 border-red-400 text-red-200">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-4">
            <Button
              onClick={handleGoogleLogin}
              disabled={isLoading}
              className="w-full bg-white hover:bg-gray-100 text-gray-900 font-medium py-3 rounded-xl transition-all duration-200"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Conectando...
                </>
              ) : (
                <>
                  <LogIn className="w-5 h-5 mr-2" />
                  Entrar com Google
                </>
              )}
            </Button>

            <div className="text-center text-purple-200 text-sm">
              <p>
                Faça login para acessar seu horóscopo personalizado,
                leituras de tarot e muito mais
              </p>
            </div>
          </div>

          <div className="bg-white/5 rounded-lg p-4 text-center">
            <p className="text-purple-200 text-xs">
              Ao fazer login, você concorda com nossos termos de uso
              e política de privacidade
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}