/**
 * Type definitions for the astrology application
 * Centralized type definitions for better maintainability
 */

// User and Authentication Types
export interface User {
  id: number;
  email: string;
  name: string;
  birthDate?: string;
  birthTime?: string;
  birthLocation?: string;
  zodiacSign?: string;
  customOrixa?: string; // User-selected Orixá override
  premiumStatus?: boolean;
  createdAt?: string;
}

export interface AuthUser {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
}

// Firebase Auth Types
export interface FirebaseAuthUser {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}

// Horoscope Types
export interface Horoscope {
  id: number;
  zodiacSign: string;
  content: string;
  orixaInfluence?: string;
  loveRating?: number;
  workRating?: number;
  healthRating?: number;
  date: string;
}

// Tarot Types
export interface TarotCard {
  id: number;
  name: string;
  description: string;
  imageUrl?: string;
  meaning: string;
  reversedMeaning?: string;
}

export interface TarotReading {
  id: number;
  userId: number;
  cards: TarotCard[];
  interpretation: string;
  createdAt: string;
}

// Orixa Types
export interface Orixa {
  id: number;
  name: string;
  description: string;
  day: string;
  color: string;
  element: string;
  characteristics: string[];
}

// Astral Chart Types
export interface AstralChart {
  id: number;
  userId: number;
  sunSign: string;
  moonSign: string;
  ascendant: string;
  houses: Record<string, string>;
  aspects: string[];
  interpretation: string;
  createdAt: string;
}

// Subscription Types
export interface Subscription {
  id: number;
  userId: number;
  planType: 'basic' | 'premium';
  status: 'active' | 'inactive' | 'cancelled';
  startDate: string;
  endDate?: string;
  paymentMethod?: string;
}

// API Response Types
export interface ApiResponse<T = any> {
  data?: T;
  error?: string;
  message?: string;
}

// Component Props Types
export interface ComponentProps {
  className?: string;
  children?: React.ReactNode;
}

// Form Types
export interface LoginFormData {
  email: string;
  password: string;
}

export interface RegisterFormData {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
}

export interface ProfileFormData {
  name: string;
  birthDate: string;
  birthTime: string;
  birthLocation: string;
}

export interface AstralChartFormData {
  birthDate: string;
  birthTime: string;
  birthLocation: string;
}

// Utility Types
export type LoadingState = 'idle' | 'loading' | 'success' | 'error';

export type Theme = 'light' | 'dark';

export type ZodiacSign = 
  | 'Áries' | 'Touro' | 'Gêmeos' | 'Câncer' 
  | 'Leão' | 'Virgem' | 'Libra' | 'Escorpião' 
  | 'Sagitário' | 'Capricórnio' | 'Aquário' | 'Peixes';

export type NavigationTab = 'home' | 'tarot' | 'astral-chart' | 'profile' | 'spiritual-profile';

// Spiritual Profile Types
export interface SpiritualProfile {
  userId: number;
  zodiacSign: string;
  calculatedOrixa: string;
  selectedOrixa?: string; // User's manual choice
  createdAt: string;
  updatedAt: string;
}

export interface SpiritualMessage {
  id: number;
  userId: number;
  content: string;
  orixaName: string;
  type: 'daily' | 'weekly' | 'guidance';
  date: string;
  isPersonalized: boolean;
}

export interface OracleReading {
  id: number;
  userId: number;
  type: 'tarot' | 'runas' | 'buzios' | 'numerology';
  question?: string;
  cards?: TarotCard[];
  interpretation: string;
  orixaGuidance?: string;
  createdAt: string;
}

export interface OrixaDetails {
  id: number;
  name: string;
  description: string;
  symbol: string;
  day: string;
  colors: readonly string[];
  element: string;
  domain: readonly string[];
  characteristics: readonly string[];
  offerings: readonly string[];
  prayer: string;
  compatibility: readonly string[];
  spiritualMessage: string;
}